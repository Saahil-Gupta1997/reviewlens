# ReviewLens API

FastAPI service for ReviewLens customer-review intelligence. It supports dataset ingestion, exploration, RAG retrieval, routed grounded answers, theme discovery, evaluations, productization metadata, and dataset deletion.

## Run Locally

```bash
python -m pip install -e ".[dev]"
uvicorn app.main:app --reload
```

For local runs without Docker, set `DATABASE_URL` to a reachable Postgres database with pgvector enabled, or set it to a SQLite URL for development smoke tests. `AUTO_CREATE_TABLES=true` creates tables on startup for local/demo use.

## RAG Provider Configuration

The backend defaults to deterministic local providers for development and tests. To enable real
RAG, configure OpenAI providers through environment variables:

```bash
EMBEDDING_PROVIDER=openai
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
ANSWER_PROVIDER=openai
OPENAI_ANSWER_MODEL=gpt-4.1-mini
OPENAI_API_KEY=...
```

`OPENAI_BASE_URL` and `OPENAI_REQUEST_TIMEOUT_SECONDS` are optional. Changing the model names only
requires configuration changes; the retrieval and answer endpoints use the configured providers.

## Endpoints

- `GET /api/healthz`: process-level health.
- `GET /api/readyz`: readiness check, including database connectivity when configured.
- `POST /api/datasets`: upload a CSV or JSON review dataset.
- `GET /api/datasets`: list onboarded datasets.
- `GET /api/datasets/{dataset_id}`: fetch dataset status and row counts.
- `DELETE /api/datasets/{dataset_id}`: delete a dataset and related reviews, embeddings, themes, answers, feedback, import errors, and ingestion jobs.
- `GET /api/datasets/{dataset_id}/explore`: fetch filtered metrics, facets, trend data, and review rows.
- `GET /api/datasets/{dataset_id}/retrieval/status`: fetch embedding/index readiness.
- `POST /api/datasets/{dataset_id}/retrieval/index`: build review embeddings with the configured provider.
- `GET /api/datasets/{dataset_id}/retrieval/search`: run keyword, semantic, or hybrid evidence search.
- `POST /api/datasets/{dataset_id}/answers`: route a business question through retrieval, deterministic analytics, or both, then generate a grounded answer with citations.
- `GET /api/datasets/{dataset_id}/answers`: list recent answer runs.
- `GET /api/datasets/{dataset_id}/answers/{answer_id}`: replay one answer run.
- `POST /api/datasets/{dataset_id}/answers/{answer_id}/feedback`: collect answer feedback.
- `GET /api/datasets/{dataset_id}/observability/metrics`: fetch answer quality metrics.
- `GET /api/datasets/{dataset_id}/themes`: discover dataset-specific themes and fetch deterministic theme drivers plus period comparison metrics.
- `POST /api/datasets/{dataset_id}/themes/compare`: compare deterministic theme assignments across two segments.
- `POST /api/datasets/{dataset_id}/reports/insight-brief`: generate a structured Markdown insight brief.
- `POST /api/datasets/{dataset_id}/actions/plan`: generate prioritized deterministic product/support actions.
- `POST /api/evaluations/run`: run the reproducible golden evaluation set.
- `GET /api/productization/release-readiness`: fetch safe model, cost, privacy, security, limit, limitation, and release-checklist metadata.

## Ask ReviewLens Routing

The answer endpoint classifies each question automatically:

- `retrieval`: qualitative review evidence plus LLM/local answer synthesis.
- `analytics`: deterministic calculations such as one-star share or average rating.
- `retrieval_analytics`: before/after comparisons that combine calculations, semantic evidence, and answer synthesis.

Comparison questions such as `Why did ratings decline after version 4.2?` return quantified
before/after cohorts, average rating delta, theme-share movement, and citations from the source
reviews used to explain the change. Supported comparison forms include after-version,
version-versus-version, this-month-versus-previous-month, and region-versus-region.

The answer endpoint also gates evidence before synthesis:

- `none`: no retrieved reviews clear the relevance threshold, so ReviewLens refuses to answer.
- `low`: one or two relevant reviews are available, so ReviewLens says the evidence is limited.
- `medium` or `high`: enough relevant evidence is available for normal grounded synthesis.

Insufficient retrieval evidence is handled before calling the answer provider, so unsupported
questions do not get passed to the LLM with weak citations.

Retrieved reviews are marked as untrusted customer-authored data in the answer prompt. This protects against prompt-injection text embedded inside customer reviews.

## Theme Discovery

Theme discovery uses the local adaptive provider by default:

```text
reviewlens-local-adaptive-themes-v1
```

The provider proposes dataset-specific labels from recurring review language, keeps seeded fallback
themes for common software datasets, and stores deterministic catalog/assignment rows:

- `dataset_themes`: stable theme key, label, description, keywords, source, and discovery model.
- `review_theme_assignments`: review-to-theme assignment, confidence, and matched evidence text.

Analytics continue to count database-backed assignments rather than asking an LLM to estimate
percentages. This allows non-software datasets, such as hotel reviews, to surface themes like
`Room cleanliness`, `Breakfast quality`, `Check-in delays`, `Room noise`, `Staff behavior`, and
`Wi-Fi reliability`.

## Migrations

```bash
alembic revision -m "create review foundation"
alembic upgrade head
```

## Privacy And Secrets

`OPENAI_API_KEY` is read from backend environment variables only. The release-readiness endpoint returns `openai_configured: true/false`, never the key value. Uploaded data remains in the configured database unless OpenAI providers are enabled, in which case selected review text/questions are sent to the configured OpenAI-compatible endpoint.
