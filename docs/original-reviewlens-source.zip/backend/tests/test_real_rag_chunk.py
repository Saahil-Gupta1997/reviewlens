from collections.abc import Sequence

from fastapi.testclient import TestClient

from app.core.config import get_settings
from app.db.session import get_engine
from app.main import create_app
from app.schemas.answers import (
    AnswerAnalytic,
    AnswerCitation,
    AnswerComparison,
    AnswerConfidence,
    AnswerStyle,
    AnswerTheme,
)


def make_client(monkeypatch, tmp_path) -> TestClient:
    monkeypatch.setenv("DATABASE_URL", f"sqlite+aiosqlite:///{tmp_path / 'reviewlens.db'}")
    monkeypatch.setenv("AUTO_CREATE_TABLES", "true")
    get_settings.cache_clear()
    get_engine.cache_clear()
    return TestClient(create_app())


class AuthenticationEmbeddingProvider:
    model_name = "fake-semantic-auth-v1"
    dimensions = 3

    async def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        return [self._embed(text) for text in texts]

    def _embed(self, text: str) -> list[float]:
        text = text.lower()
        auth_terms = [
            "auth",
            "authentication",
            "log in",
            "login",
            "password",
            "rejecting",
            "sign-in",
            "sign in",
        ]
        if any(term in text for term in auth_terms):
            return [1.0, 0.0, 0.0]
        if any(term in text for term in ["export", "download", "report"]):
            return [0.0, 1.0, 0.0]
        return [0.0, 0.0, 1.0]


class RecordingAnswerProvider:
    model_name = "fake-llm-v1"
    inputs: list[dict[str, object]] = []

    async def generate_answer(
        self,
        *,
        question: str,
        answer_style: AnswerStyle,
        citations: list[AnswerCitation],
        themes: list[AnswerTheme],
        analytics: list[AnswerAnalytic],
        comparison: AnswerComparison | None,
        filtered_review_count: int,
        confidence: AnswerConfidence,
    ) -> str:
        self.inputs.append(
            {
                "question": question,
                "answer_style": answer_style,
                "citations": citations,
                "themes": themes,
                "analytics": analytics,
                "comparison": comparison,
                "filtered_review_count": filtered_review_count,
                "confidence": confidence,
            }
        )
        return (
            "Customers are describing authentication problems across the cited reviews "
            "[1] [2] [99]."
        )


def test_semantic_retrieval_finds_authentication_variants_without_keyword_overlap(
    monkeypatch,
    tmp_path,
):
    from app.services import retrieval

    monkeypatch.setattr(retrieval, "get_embedding_provider", AuthenticationEmbeddingProvider)
    csv_payload = (
        "review_id,review_text,rating,review_date\n"
        "r1,I cannot log in anymore,1,2026-08-01\n"
        "r2,The app keeps rejecting my password,1,2026-08-02\n"
        "r3,Authentication stopped working after the update,2,2026-08-03\n"
        "r4,Export downloads are confusing,2,2026-08-04\n"
    )

    with make_client(monkeypatch, tmp_path) as client:
        upload = client.post(
            "/api/datasets",
            files={"file": ("auth.csv", csv_payload, "text/csv")},
        )
        dataset_id = upload.json()["dataset_id"]

        response = client.get(
            f"/api/datasets/{dataset_id}/retrieval/search",
            params={"q": "Are customers having sign-in problems?", "mode": "semantic", "top_k": 4},
        )

    assert response.status_code == 200
    body = response.json()
    assert body["index_status"] == "ready"
    assert [item["row_number"] for item in body["results"][:3]] == [2, 3, 4]
    assert "Export downloads are confusing" not in {
        item["review_text"] for item in body["results"][:3]
    }
    result_by_row = {item["row_number"]: item for item in body["results"]}
    assert result_by_row[3]["keyword_score"] == 0
    assert result_by_row[4]["keyword_score"] == 0


def test_llm_answer_uses_only_retrieved_evidence_and_normalizes_citation_markers(
    monkeypatch,
    tmp_path,
):
    from app.services import answers, retrieval

    fake_answer_provider = RecordingAnswerProvider()
    monkeypatch.setattr(retrieval, "get_embedding_provider", AuthenticationEmbeddingProvider)
    monkeypatch.setattr(
        answers,
        "get_answer_generation_provider",
        lambda settings=None: fake_answer_provider,
    )
    csv_payload = (
        "review_id,review_text,rating,review_date\n"
        "r1,I cannot log in anymore,1,2026-08-01\n"
        "r2,The app keeps rejecting my password,1,2026-08-02\n"
        "r3,Authentication stopped working after the update,2,2026-08-03\n"
        "r4,Export downloads are confusing,2,2026-08-04\n"
    )

    with make_client(monkeypatch, tmp_path) as client:
        upload = client.post(
            "/api/datasets",
            files={"file": ("auth.csv", csv_payload, "text/csv")},
        )
        dataset_id = upload.json()["dataset_id"]
        response = client.post(
            f"/api/datasets/{dataset_id}/answers",
            json={
                "question": (
                    "Summarize the main authentication problems customers are experiencing."
                ),
                "mode": "semantic",
                "top_k": 3,
            },
        )

    assert response.status_code == 200
    body = response.json()
    assert body["generation_model"] == "fake-llm-v1"
    assert "[99]" not in body["answer"]
    assert {citation["row_number"] for citation in body["citations"]} == {2, 3, 4}
    assert len(fake_answer_provider.inputs) == 1
    sent_citations = fake_answer_provider.inputs[0]["citations"]
    assert [citation.row_number for citation in sent_citations] == [2, 3, 4]
    assert all("Export downloads" not in citation.quote for citation in sent_citations)
