# Database Migrations

Alembic migration scaffold for ReviewLens. Chunk 2 should add the first schema migration for datasets, reviews, ingestion jobs, and review metadata.
