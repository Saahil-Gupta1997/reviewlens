"""create dataset onboarding tables

Revision ID: 20260803_0001
Revises:
Create Date: 2026-08-03
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260803_0001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "datasets",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("source_filename", sa.String(length=255), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("total_rows", sa.Integer(), nullable=False),
        sa.Column("accepted_rows", sa.Integer(), nullable=False),
        sa.Column("rejected_rows", sa.Integer(), nullable=False),
        sa.Column("duplicate_rows", sa.Integer(), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "ingestion_jobs",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("dataset_id", sa.String(length=36), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("file_type", sa.String(length=16), nullable=False),
        sa.Column("field_mapping_json", sa.Text(), nullable=False),
        sa.Column("total_rows", sa.Integer(), nullable=False),
        sa.Column("accepted_rows", sa.Integer(), nullable=False),
        sa.Column("rejected_rows", sa.Integer(), nullable=False),
        sa.Column("duplicate_rows", sa.Integer(), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "completed_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.ForeignKeyConstraint(["dataset_id"], ["datasets.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "review_import_errors",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("dataset_id", sa.String(length=36), nullable=False),
        sa.Column("row_number", sa.Integer(), nullable=False),
        sa.Column("error_code", sa.String(length=80), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("raw_payload_json", sa.Text(), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.ForeignKeyConstraint(["dataset_id"], ["datasets.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "reviews",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("dataset_id", sa.String(length=36), nullable=False),
        sa.Column("external_review_id", sa.String(length=255), nullable=True),
        sa.Column("review_text", sa.Text(), nullable=False),
        sa.Column("normalized_text", sa.Text(), nullable=False),
        sa.Column("review_title", sa.String(length=500), nullable=True),
        sa.Column("rating", sa.Float(), nullable=True),
        sa.Column("review_date", sa.Date(), nullable=True),
        sa.Column("source", sa.String(length=120), nullable=True),
        sa.Column("product_name", sa.String(length=255), nullable=True),
        sa.Column("product_version", sa.String(length=120), nullable=True),
        sa.Column("region", sa.String(length=120), nullable=True),
        sa.Column("country", sa.String(length=120), nullable=True),
        sa.Column("language", sa.String(length=32), nullable=True),
        sa.Column("customer_segment", sa.String(length=120), nullable=True),
        sa.Column("platform", sa.String(length=120), nullable=True),
        sa.Column("channel", sa.String(length=120), nullable=True),
        sa.Column("verified_purchase", sa.Boolean(), nullable=True),
        sa.Column("metadata_json", sa.Text(), nullable=False),
        sa.Column("text_hash", sa.String(length=64), nullable=False),
        sa.Column("metadata_hash", sa.String(length=64), nullable=False),
        sa.Column("dedupe_key", sa.String(length=64), nullable=False),
        sa.Column("embedding_status", sa.String(length=32), nullable=False),
        sa.Column("indexed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("is_deleted", sa.Boolean(), nullable=False),
        sa.Column("row_number", sa.Integer(), nullable=False),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.ForeignKeyConstraint(["dataset_id"], ["datasets.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("dataset_id", "dedupe_key", name="uq_reviews_dataset_dedupe_key"),
    )
    op.create_index("ix_reviews_dataset_review_date", "reviews", ["dataset_id", "review_date"])
    op.create_index("ix_reviews_dataset_rating", "reviews", ["dataset_id", "rating"])
    op.create_index("ix_reviews_dataset_source", "reviews", ["dataset_id", "source"])
    op.create_index("ix_reviews_dataset_product_name", "reviews", ["dataset_id", "product_name"])
    op.create_index(
        "ix_reviews_dataset_product_version",
        "reviews",
        ["dataset_id", "product_version"],
    )
    op.create_index("ix_reviews_dataset_region", "reviews", ["dataset_id", "region"])
    op.create_index(
        "ix_reviews_dataset_embedding_status",
        "reviews",
        ["dataset_id", "embedding_status"],
    )
    op.create_table(
        "review_embeddings",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("dataset_id", sa.String(length=36), nullable=False),
        sa.Column("review_id", sa.String(length=36), nullable=False),
        sa.Column("chunk_index", sa.Integer(), nullable=False),
        sa.Column("chunk_text", sa.Text(), nullable=False),
        sa.Column("chunk_hash", sa.String(length=64), nullable=False),
        sa.Column("embedding_model", sa.String(length=120), nullable=False),
        sa.Column("dimensions", sa.Integer(), nullable=False),
        sa.Column("vector_json", sa.Text(), nullable=False),
        sa.Column("vector_hash", sa.String(length=64), nullable=False),
        sa.Column("embedding_status", sa.String(length=32), nullable=False),
        sa.Column("embedding_error", sa.Text(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.ForeignKeyConstraint(["dataset_id"], ["datasets.id"]),
        sa.ForeignKeyConstraint(["review_id"], ["reviews.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("review_id", "embedding_model", name="uq_review_embedding_model"),
    )
    op.create_index(
        "ix_review_embeddings_dataset_status",
        "review_embeddings",
        ["dataset_id", "embedding_status"],
    )
    op.create_index(
        "ix_review_embeddings_dataset_review",
        "review_embeddings",
        ["dataset_id", "review_id"],
    )
    op.create_index(
        "ix_review_embeddings_dataset_chunk_hash",
        "review_embeddings",
        ["dataset_id", "chunk_hash"],
    )
    op.create_index("ix_review_embeddings_review_id", "review_embeddings", ["review_id"])
    op.create_table(
        "answer_interactions",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("dataset_id", sa.String(length=36), nullable=False),
        sa.Column("question", sa.Text(), nullable=False),
        sa.Column("mode", sa.String(length=32), nullable=False),
        sa.Column("top_k", sa.Integer(), nullable=False),
        sa.Column("answer_style", sa.String(length=32), nullable=False),
        sa.Column("filters_json", sa.Text(), nullable=False),
        sa.Column("answer_text", sa.Text(), nullable=False),
        sa.Column("confidence", sa.String(length=32), nullable=False),
        sa.Column("confidence_score", sa.Integer(), nullable=False),
        sa.Column("index_status", sa.String(length=32), nullable=False),
        sa.Column("evidence_count", sa.Integer(), nullable=False),
        sa.Column("filtered_review_count", sa.Integer(), nullable=False),
        sa.Column("themes_json", sa.Text(), nullable=False),
        sa.Column("citations_json", sa.Text(), nullable=False),
        sa.Column("limitations_json", sa.Text(), nullable=False),
        sa.Column("generation_model", sa.String(length=120), nullable=False),
        sa.Column("latency_ms", sa.Float(), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.ForeignKeyConstraint(["dataset_id"], ["datasets.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_answer_interactions_dataset_created",
        "answer_interactions",
        ["dataset_id", "created_at"],
    )
    op.create_index(
        "ix_answer_interactions_dataset_confidence",
        "answer_interactions",
        ["dataset_id", "confidence"],
    )
    op.create_index(
        "ix_answer_interactions_dataset_index_status",
        "answer_interactions",
        ["dataset_id", "index_status"],
    )
    op.create_table(
        "answer_feedback",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("dataset_id", sa.String(length=36), nullable=False),
        sa.Column("answer_id", sa.String(length=36), nullable=False),
        sa.Column("rating", sa.String(length=32), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column(
            "created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False
        ),
        sa.ForeignKeyConstraint(["dataset_id"], ["datasets.id"]),
        sa.ForeignKeyConstraint(["answer_id"], ["answer_interactions.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_answer_feedback_dataset_rating",
        "answer_feedback",
        ["dataset_id", "rating"],
    )
    op.create_index("ix_answer_feedback_answer_id", "answer_feedback", ["answer_id"])


def downgrade() -> None:
    op.drop_index("ix_answer_feedback_answer_id", table_name="answer_feedback")
    op.drop_index("ix_answer_feedback_dataset_rating", table_name="answer_feedback")
    op.drop_table("answer_feedback")
    op.drop_index(
        "ix_answer_interactions_dataset_index_status",
        table_name="answer_interactions",
    )
    op.drop_index(
        "ix_answer_interactions_dataset_confidence",
        table_name="answer_interactions",
    )
    op.drop_index("ix_answer_interactions_dataset_created", table_name="answer_interactions")
    op.drop_table("answer_interactions")
    op.drop_index("ix_review_embeddings_review_id", table_name="review_embeddings")
    op.drop_index("ix_review_embeddings_dataset_chunk_hash", table_name="review_embeddings")
    op.drop_index("ix_review_embeddings_dataset_review", table_name="review_embeddings")
    op.drop_index("ix_review_embeddings_dataset_status", table_name="review_embeddings")
    op.drop_table("review_embeddings")
    op.drop_index("ix_reviews_dataset_embedding_status", table_name="reviews")
    op.drop_index("ix_reviews_dataset_region", table_name="reviews")
    op.drop_index("ix_reviews_dataset_product_version", table_name="reviews")
    op.drop_index("ix_reviews_dataset_product_name", table_name="reviews")
    op.drop_index("ix_reviews_dataset_source", table_name="reviews")
    op.drop_index("ix_reviews_dataset_rating", table_name="reviews")
    op.drop_index("ix_reviews_dataset_review_date", table_name="reviews")
    op.drop_table("reviews")
    op.drop_table("review_import_errors")
    op.drop_table("ingestion_jobs")
    op.drop_table("datasets")
