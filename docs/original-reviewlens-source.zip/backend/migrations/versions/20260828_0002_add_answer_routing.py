"""add routed answer metadata

Revision ID: 20260828_0002
Revises: 20260803_0001
Create Date: 2026-08-28
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260828_0002"
down_revision: str | None = "20260803_0001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "answer_interactions",
        sa.Column("route", sa.String(length=32), nullable=False, server_default="retrieval"),
    )
    op.add_column(
        "answer_interactions",
        sa.Column("analytics_json", sa.Text(), nullable=False, server_default="[]"),
    )
    op.add_column(
        "answer_interactions",
        sa.Column("comparison_json", sa.Text(), nullable=False, server_default="null"),
    )
    if op.get_context().dialect.name != "sqlite":
        op.alter_column("answer_interactions", "route", server_default=None)
        op.alter_column("answer_interactions", "analytics_json", server_default=None)
        op.alter_column("answer_interactions", "comparison_json", server_default=None)


def downgrade() -> None:
    op.drop_column("answer_interactions", "comparison_json")
    op.drop_column("answer_interactions", "analytics_json")
    op.drop_column("answer_interactions", "route")
