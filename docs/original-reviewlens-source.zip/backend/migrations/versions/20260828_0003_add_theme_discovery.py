"""add theme discovery catalog

Revision ID: 20260828_0003
Revises: 20260828_0002
Create Date: 2026-08-28
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260828_0003"
down_revision: str | None = "20260828_0002"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "dataset_themes",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("dataset_id", sa.String(length=36), nullable=False),
        sa.Column("theme_key", sa.String(length=160), nullable=False),
        sa.Column("label", sa.String(length=160), nullable=False),
        sa.Column("description", sa.Text(), nullable=False),
        sa.Column("keywords_json", sa.Text(), nullable=False),
        sa.Column("source", sa.String(length=32), nullable=False),
        sa.Column("discovery_model", sa.String(length=120), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["dataset_id"], ["datasets.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("dataset_id", "theme_key", name="uq_dataset_themes_dataset_key"),
    )
    op.create_index(
        "ix_dataset_themes_dataset_source",
        "dataset_themes",
        ["dataset_id", "source"],
    )
    op.create_table(
        "review_theme_assignments",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("dataset_id", sa.String(length=36), nullable=False),
        sa.Column("review_id", sa.String(length=36), nullable=False),
        sa.Column("theme_id", sa.String(length=36), nullable=False),
        sa.Column("confidence", sa.Float(), nullable=False),
        sa.Column("evidence_text", sa.Text(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["dataset_id"], ["datasets.id"]),
        sa.ForeignKeyConstraint(["review_id"], ["reviews.id"]),
        sa.ForeignKeyConstraint(["theme_id"], ["dataset_themes.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "review_id",
            "theme_id",
            name="uq_review_theme_assignments_review_theme",
        ),
    )
    op.create_index(
        "ix_review_theme_assignments_dataset_theme",
        "review_theme_assignments",
        ["dataset_id", "theme_id"],
    )
    op.create_index(
        "ix_review_theme_assignments_dataset_review",
        "review_theme_assignments",
        ["dataset_id", "review_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_review_theme_assignments_dataset_review",
        table_name="review_theme_assignments",
    )
    op.drop_index(
        "ix_review_theme_assignments_dataset_theme",
        table_name="review_theme_assignments",
    )
    op.drop_table("review_theme_assignments")
    op.drop_index("ix_dataset_themes_dataset_source", table_name="dataset_themes")
    op.drop_table("dataset_themes")
