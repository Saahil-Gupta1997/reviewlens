from datetime import date, datetime
from uuid import uuid4

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


def new_uuid() -> str:
    return str(uuid4())


class Dataset(Base):
    __tablename__ = "datasets"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    source_filename: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="ready")
    total_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    accepted_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    rejected_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    duplicate_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    ingestion_jobs: Mapped[list["IngestionJob"]] = relationship(back_populates="dataset")
    reviews: Mapped[list["Review"]] = relationship(back_populates="dataset")
    import_errors: Mapped[list["ReviewImportError"]] = relationship(back_populates="dataset")
    answer_interactions: Mapped[list["AnswerInteraction"]] = relationship(back_populates="dataset")
    themes: Mapped[list["DatasetTheme"]] = relationship(back_populates="dataset")


class IngestionJob(Base):
    __tablename__ = "ingestion_jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="completed")
    file_type: Mapped[str] = mapped_column(String(16), nullable=False)
    field_mapping_json: Mapped[str] = mapped_column(Text, nullable=False)
    total_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    accepted_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    rejected_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    duplicate_rows: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    completed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    dataset: Mapped[Dataset] = relationship(back_populates="ingestion_jobs")


class Review(Base):
    __tablename__ = "reviews"
    __table_args__ = (
        UniqueConstraint("dataset_id", "dedupe_key", name="uq_reviews_dataset_dedupe_key"),
        Index("ix_reviews_dataset_review_date", "dataset_id", "review_date"),
        Index("ix_reviews_dataset_rating", "dataset_id", "rating"),
        Index("ix_reviews_dataset_source", "dataset_id", "source"),
        Index("ix_reviews_dataset_product_name", "dataset_id", "product_name"),
        Index("ix_reviews_dataset_product_version", "dataset_id", "product_version"),
        Index("ix_reviews_dataset_region", "dataset_id", "region"),
        Index("ix_reviews_dataset_embedding_status", "dataset_id", "embedding_status"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    external_review_id: Mapped[str | None] = mapped_column(String(255))
    review_text: Mapped[str] = mapped_column(Text, nullable=False)
    normalized_text: Mapped[str] = mapped_column(Text, nullable=False)
    review_title: Mapped[str | None] = mapped_column(String(500))
    rating: Mapped[float | None]
    review_date: Mapped[date | None] = mapped_column(Date)
    source: Mapped[str | None] = mapped_column(String(120))
    product_name: Mapped[str | None] = mapped_column(String(255))
    product_version: Mapped[str | None] = mapped_column(String(120))
    region: Mapped[str | None] = mapped_column(String(120))
    country: Mapped[str | None] = mapped_column(String(120))
    language: Mapped[str | None] = mapped_column(String(32))
    customer_segment: Mapped[str | None] = mapped_column(String(120))
    platform: Mapped[str | None] = mapped_column(String(120))
    channel: Mapped[str | None] = mapped_column(String(120))
    verified_purchase: Mapped[bool | None] = mapped_column(Boolean)
    metadata_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    text_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    metadata_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    dedupe_key: Mapped[str] = mapped_column(String(64), nullable=False)
    embedding_status: Mapped[str] = mapped_column(String(32), nullable=False, default="pending")
    indexed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    row_number: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    dataset: Mapped[Dataset] = relationship(back_populates="reviews")
    embedding: Mapped["ReviewEmbedding | None"] = relationship(
        back_populates="review",
        cascade="all, delete-orphan",
    )
    theme_assignments: Mapped[list["ReviewThemeAssignment"]] = relationship(
        back_populates="review",
        cascade="all, delete-orphan",
    )


class ReviewEmbedding(Base):
    __tablename__ = "review_embeddings"
    __table_args__ = (
        UniqueConstraint("review_id", "embedding_model", name="uq_review_embedding_model"),
        Index("ix_review_embeddings_dataset_status", "dataset_id", "embedding_status"),
        Index("ix_review_embeddings_dataset_review", "dataset_id", "review_id"),
        Index("ix_review_embeddings_dataset_chunk_hash", "dataset_id", "chunk_hash"),
        Index("ix_review_embeddings_review_id", "review_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    review_id: Mapped[str] = mapped_column(ForeignKey("reviews.id"), nullable=False)
    chunk_index: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    chunk_text: Mapped[str] = mapped_column(Text, nullable=False)
    chunk_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    embedding_model: Mapped[str] = mapped_column(String(120), nullable=False)
    dimensions: Mapped[int] = mapped_column(Integer, nullable=False)
    vector_json: Mapped[str] = mapped_column(Text, nullable=False)
    vector_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    embedding_status: Mapped[str] = mapped_column(String(32), nullable=False, default="embedded")
    embedding_error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    review: Mapped[Review] = relationship(back_populates="embedding")


class ReviewImportError(Base):
    __tablename__ = "review_import_errors"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    row_number: Mapped[int] = mapped_column(Integer, nullable=False)
    error_code: Mapped[str] = mapped_column(String(80), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    raw_payload_json: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    dataset: Mapped[Dataset] = relationship(back_populates="import_errors")


class DatasetTheme(Base):
    __tablename__ = "dataset_themes"
    __table_args__ = (
        UniqueConstraint("dataset_id", "theme_key", name="uq_dataset_themes_dataset_key"),
        Index("ix_dataset_themes_dataset_source", "dataset_id", "source"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    theme_key: Mapped[str] = mapped_column(String(160), nullable=False)
    label: Mapped[str] = mapped_column(String(160), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    keywords_json: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[str] = mapped_column(String(32), nullable=False, default="ai")
    discovery_model: Mapped[str] = mapped_column(String(120), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )

    dataset: Mapped[Dataset] = relationship(back_populates="themes")
    assignments: Mapped[list["ReviewThemeAssignment"]] = relationship(
        back_populates="theme",
        cascade="all, delete-orphan",
    )


class ReviewThemeAssignment(Base):
    __tablename__ = "review_theme_assignments"
    __table_args__ = (
        UniqueConstraint(
            "review_id",
            "theme_id",
            name="uq_review_theme_assignments_review_theme",
        ),
        Index("ix_review_theme_assignments_dataset_theme", "dataset_id", "theme_id"),
        Index("ix_review_theme_assignments_dataset_review", "dataset_id", "review_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    review_id: Mapped[str] = mapped_column(ForeignKey("reviews.id"), nullable=False)
    theme_id: Mapped[str] = mapped_column(ForeignKey("dataset_themes.id"), nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    evidence_text: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    review: Mapped[Review] = relationship(back_populates="theme_assignments")
    theme: Mapped[DatasetTheme] = relationship(back_populates="assignments")


class AnswerInteraction(Base):
    __tablename__ = "answer_interactions"
    __table_args__ = (
        Index("ix_answer_interactions_dataset_created", "dataset_id", "created_at"),
        Index("ix_answer_interactions_dataset_confidence", "dataset_id", "confidence"),
        Index("ix_answer_interactions_dataset_index_status", "dataset_id", "index_status"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    question: Mapped[str] = mapped_column(Text, nullable=False)
    mode: Mapped[str] = mapped_column(String(32), nullable=False)
    top_k: Mapped[int] = mapped_column(Integer, nullable=False)
    answer_style: Mapped[str] = mapped_column(String(32), nullable=False)
    route: Mapped[str] = mapped_column(String(32), nullable=False, default="retrieval")
    filters_json: Mapped[str] = mapped_column(Text, nullable=False)
    answer_text: Mapped[str] = mapped_column(Text, nullable=False)
    confidence: Mapped[str] = mapped_column(String(32), nullable=False)
    confidence_score: Mapped[int] = mapped_column(Integer, nullable=False)
    index_status: Mapped[str] = mapped_column(String(32), nullable=False)
    evidence_count: Mapped[int] = mapped_column(Integer, nullable=False)
    filtered_review_count: Mapped[int] = mapped_column(Integer, nullable=False)
    themes_json: Mapped[str] = mapped_column(Text, nullable=False)
    analytics_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    comparison_json: Mapped[str] = mapped_column(Text, nullable=False, default="null")
    citations_json: Mapped[str] = mapped_column(Text, nullable=False)
    limitations_json: Mapped[str] = mapped_column(Text, nullable=False)
    generation_model: Mapped[str] = mapped_column(String(120), nullable=False)
    latency_ms: Mapped[float] = mapped_column(Float, nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="completed")
    error_message: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    dataset: Mapped[Dataset] = relationship(back_populates="answer_interactions")
    feedback: Mapped[list["AnswerFeedback"]] = relationship(
        back_populates="answer",
        cascade="all, delete-orphan",
    )


class AnswerFeedback(Base):
    __tablename__ = "answer_feedback"
    __table_args__ = (
        Index("ix_answer_feedback_dataset_rating", "dataset_id", "rating"),
        Index("ix_answer_feedback_answer_id", "answer_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_uuid)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("datasets.id"), nullable=False)
    answer_id: Mapped[str] = mapped_column(ForeignKey("answer_interactions.id"), nullable=False)
    rating: Mapped[str] = mapped_column(String(32), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    answer: Mapped[AnswerInteraction] = relationship(back_populates="feedback")
