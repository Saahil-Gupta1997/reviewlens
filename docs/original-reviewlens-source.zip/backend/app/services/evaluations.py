from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from time import perf_counter
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dataset import Review
from app.schemas.answers import AnswerFilters, AnswerResponse
from app.schemas.evaluations import (
    EvaluationCaseResult,
    EvaluationCategory,
    EvaluationCategorySummary,
    EvaluationMetric,
    EvaluationRunResponse,
)
from app.schemas.ingestion import FieldMapping
from app.services.answers import generate_grounded_answer
from app.services.ingestion import ingest_dataset

EVAL_VERSION = "v1.3"


@dataclass(frozen=True)
class GoldenReview:
    external_id: str
    text: str
    rating: float
    review_date: date
    product_version: str
    region: str
    theme: str


@dataclass(frozen=True)
class GoldenCase:
    case_id: str
    category: EvaluationCategory
    question: str
    expected_theme: str | None = None
    expected_support_ids: set[str] = field(default_factory=set)
    expected_analytics: dict[str, float] = field(default_factory=dict)
    filters: AnswerFilters = field(default_factory=AnswerFilters)
    expected_filtered_count: int | None = None
    expected_abstain: bool = False
    expected_comparison_delta: float | None = None


async def run_golden_evaluation(session: AsyncSession) -> EvaluationRunResponse:
    reviews = build_golden_reviews()
    summary = await ingest_dataset(
        session,
        filename="reviewlens_golden_eval.csv",
        content=golden_reviews_csv(reviews).encode("utf-8"),
        dataset_name=f"ReviewLens Golden Evaluation {EVAL_VERSION}",
        mapping=FieldMapping(),
    )
    result = await session.execute(
        select(Review)
        .where(Review.dataset_id == summary.dataset_id, Review.is_deleted.is_(False))
        .order_by(Review.row_number.asc())
    )
    stored_reviews = list(result.scalars().all())
    row_by_external_id = {
        review.external_review_id: review.row_number
        for review in stored_reviews
        if review.external_review_id
    }
    cases = build_golden_cases(reviews=reviews)
    case_results = []
    for case in cases:
        case_reviews = filter_reviews(stored_reviews, case.filters)
        started_at = perf_counter()
        try:
            answer = await generate_grounded_answer(
                session,
                dataset_id=summary.dataset_id,
                question=case.question,
                reviews=case_reviews,
                mode="hybrid",
                top_k=8,
                answer_style="summary",
            )
            latency_ms = (perf_counter() - started_at) * 1000
            case_results.append(score_case(case, answer, row_by_external_id, latency_ms))
        except Exception as exc:  # pragma: no cover - surfaced through robustness metric
            latency_ms = (perf_counter() - started_at) * 1000
            case_results.append(
                EvaluationCaseResult(
                    case_id=case.case_id,
                    category=case.category,
                    question=case.question,
                    passed=False,
                    latency_ms=round(latency_ms, 2),
                    confidence="error",
                    evidence_count=0,
                    expected=case_expectation(case),
                    observed=str(exc),
                    failures=[f"Evaluation case raised {type(exc).__name__}: {exc}"],
                )
            )

    return build_evaluation_response(
        dataset_id=summary.dataset_id,
        cases=cases,
        case_results=case_results,
    )


def score_case(
    case: GoldenCase,
    answer: AnswerResponse,
    row_by_external_id: dict[str, int],
    latency_ms: float,
) -> EvaluationCaseResult:
    failures = []
    expected_rows = {
        row_by_external_id[external_id]
        for external_id in case.expected_support_ids
        if external_id in row_by_external_id
    }
    cited_rows = {citation.row_number for citation in answer.citations}

    if case.expected_abstain:
        if answer.confidence != "none" or answer.evidence_count != 0 or answer.citations:
            failures.append("Expected abstention with no citations.")
    elif expected_rows:
        if not cited_rows:
            failures.append("Expected supporting citations but none were returned.")
        elif not cited_rows <= expected_rows:
            failures.append("One or more citations were outside expected supporting reviews.")
        if not (cited_rows & expected_rows):
            failures.append("No expected supporting review was retrieved.")

    if case.expected_theme and case.expected_theme not in {theme.label for theme in answer.themes}:
        failures.append(f"Expected theme {case.expected_theme!r}.")

    if case.expected_filtered_count is not None:
        if answer.filtered_review_count != case.expected_filtered_count:
            failures.append(
                f"Expected {case.expected_filtered_count} filtered reviews, "
                f"got {answer.filtered_review_count}."
            )
        if not citations_match_filters(answer=answer, filters=case.filters):
            failures.append("Citations did not respect expected filters.")

    if case.expected_analytics and not analytics_match(answer, case.expected_analytics):
        failures.append("Expected deterministic calculation did not match.")

    if case.expected_comparison_delta is not None:
        if answer.comparison is None:
            failures.append("Expected comparison output.")
        elif answer.comparison.rating_delta != case.expected_comparison_delta:
            failures.append(
                f"Expected rating delta {case.expected_comparison_delta}, "
                f"got {answer.comparison.rating_delta}."
            )

    observed = (
        f"confidence={answer.confidence}; evidence={answer.evidence_count}; "
        f"themes={', '.join(theme.label for theme in answer.themes[:3]) or 'none'}"
    )
    return EvaluationCaseResult(
        case_id=case.case_id,
        category=case.category,
        question=case.question,
        passed=not failures,
        latency_ms=round(latency_ms, 2),
        confidence=answer.confidence,
        evidence_count=answer.evidence_count,
        expected=case_expectation(case),
        observed=observed,
        failures=failures,
    )


def build_evaluation_response(
    *,
    dataset_id: str,
    cases: list[GoldenCase],
    case_results: list[EvaluationCaseResult],
) -> EvaluationRunResponse:
    passed_questions = sum(1 for result in case_results if result.passed)
    latencies = sorted(result.latency_ms for result in case_results)
    p95_index = min(round(len(latencies) * 0.95) - 1, len(latencies) - 1)
    metrics = build_metrics(cases=cases, results=case_results)
    return EvaluationRunResponse(
        run_id=str(uuid4()),
        version=EVAL_VERSION,
        dataset_id=dataset_id,
        generated_at=datetime.now(UTC),
        total_questions=len(case_results),
        passed_questions=passed_questions,
        overall_score=round(passed_questions / len(case_results), 4),
        average_latency_ms=round(sum(latencies) / len(latencies), 2),
        p95_latency_ms=latencies[p95_index],
        metrics=metrics,
        category_breakdown=build_category_breakdown(case_results),
        cases=case_results,
    )


def build_metrics(
    *,
    cases: list[GoldenCase],
    results: list[EvaluationCaseResult],
) -> list[EvaluationMetric]:
    by_id = {case.case_id: case for case in cases}
    support_results = [
        result for result in results if by_id[result.case_id].expected_support_ids
    ]
    impossible_results = [
        result for result in results if by_id[result.case_id].expected_abstain
    ]
    calculation_results = [
        result
        for result in results
        if by_id[result.case_id].expected_analytics
        or by_id[result.case_id].expected_comparison_delta is not None
    ]
    filter_results = [
        result for result in results if by_id[result.case_id].expected_filtered_count is not None
    ]
    robust_total = len(results)
    robust_passed = sum(1 for result in results if result.confidence != "error")
    return [
        metric_from_results(
            "Retrieval relevance",
            support_results,
            "Expected supporting reviews were retrieved.",
        ),
        metric_from_results(
            "Citation support",
            support_results,
            "Citations stayed within the golden supporting review set.",
        ),
        metric_from_results(
            "Abstention accuracy",
            impossible_results,
            "Impossible questions were refused without citations.",
        ),
        metric_from_results(
            "Calculation accuracy",
            calculation_results,
            "Percentages, counts, and rating deltas matched golden values.",
        ),
        metric_from_results(
            "Filter correctness",
            filter_results,
            "Filtered questions used the expected denominator and citation scope.",
        ),
        EvaluationMetric(
            name="Robustness",
            score=round(robust_passed / robust_total, 4) if robust_total else 1,
            passed=robust_passed,
            total=robust_total,
            details="Evaluation cases completed without runtime errors.",
        ),
    ]


def metric_from_results(
    name: str,
    results: list[EvaluationCaseResult],
    details: str,
) -> EvaluationMetric:
    total = len(results)
    passed = sum(1 for result in results if result.passed)
    return EvaluationMetric(
        name=name,
        score=round(passed / total, 4) if total else 1,
        passed=passed,
        total=total,
        details=details,
    )


def build_category_breakdown(
    results: list[EvaluationCaseResult],
) -> list[EvaluationCategorySummary]:
    categories: list[EvaluationCategory] = [
        "factual",
        "theme",
        "quantitative",
        "filter",
        "comparison",
        "impossible",
    ]
    summaries = []
    for category in categories:
        category_results = [result for result in results if result.category == category]
        passed = sum(1 for result in category_results if result.passed)
        total = len(category_results)
        summaries.append(
            EvaluationCategorySummary(
                category=category,
                passed=passed,
                total=total,
                score=round(passed / total, 4) if total else 1,
            )
        )
    return summaries


def analytics_match(answer: AnswerResponse, expected: dict[str, float]) -> bool:
    for analytic in answer.analytics:
        if analytic.label != expected.get("label"):
            continue
        for key in ("numerator", "denominator", "percentage"):
            if key not in expected:
                continue
            observed = getattr(analytic, key)
            if observed != expected[key]:
                return False
        return True
    return False


def citations_match_filters(*, answer: AnswerResponse, filters: AnswerFilters) -> bool:
    for citation in answer.citations:
        if filters.product_version and citation.product_version != filters.product_version:
            return False
        if filters.region and citation.region != filters.region:
            return False
        if filters.rating_max is not None and (
            citation.rating is None or citation.rating > filters.rating_max
        ):
            return False
    return True


def case_expectation(case: GoldenCase) -> str:
    parts = []
    if case.expected_theme:
        parts.append(f"theme={case.expected_theme}")
    if case.expected_support_ids:
        parts.append(f"support={len(case.expected_support_ids)} reviews")
    if case.expected_analytics:
        parts.append(f"analytics={case.expected_analytics}")
    if case.expected_filtered_count is not None:
        parts.append(f"filtered={case.expected_filtered_count}")
    if case.expected_comparison_delta is not None:
        parts.append(f"delta={case.expected_comparison_delta:+.2f}")
    if case.expected_abstain:
        parts.append("abstain")
    return "; ".join(parts)


def build_golden_cases(*, reviews: list[GoldenReview]) -> list[GoldenCase]:
    cases: list[GoldenCase] = []
    support = support_ids_by_theme(reviews)
    login_filters = AnswerFilters(region="EU")
    version_filters = AnswerFilters(product_version="4.3")
    low_rating_filters = AnswerFilters(rating_max=2)
    question_groups: list[tuple[EvaluationCategory, int, list[tuple[str, str, str]]]] = [
        (
            "factual",
            20,
            [
                (
                    "Which reviews mention password reset problems?",
                    "Login / Authentication",
                    "login",
                ),
                (
                    "What are customers saying about export downloads?",
                    "Exports / Reporting",
                    "export",
                ),
                (
                    "Which customers describe checkout payment failures?",
                    "Checkout / Billing",
                    "billing",
                ),
                ("What feedback mentions slow loading?", "Performance", "performance"),
            ],
        ),
        (
            "theme",
            20,
            [
                ("What are the main login themes?", "Login / Authentication", "login"),
                ("What recurring performance issues appear?", "Performance", "performance"),
                ("Summarize checkout complaints.", "Checkout / Billing", "billing"),
                ("What export problems recur?", "Exports / Reporting", "export"),
            ],
        ),
    ]
    for category, count, questions in question_groups:
        for index in range(count):
            question, expected_theme, support_key = questions[index % len(questions)]
            cases.append(
                GoldenCase(
                    case_id=f"{category}-{index + 1:02d}",
                    category=category,
                    question=question,
                    expected_theme=expected_theme,
                    expected_support_ids=support[support_key],
                )
            )

    for index in range(20):
        cases.append(
            GoldenCase(
                case_id=f"quantitative-{index + 1:02d}",
                category="quantitative",
                question=(
                    "What percentage of reviews are one-star?"
                    if index % 2 == 0
                    else "What percent of reviews are one star?"
                ),
                expected_analytics={
                    "label": "One-star review share",
                    "numerator": 30,
                    "denominator": 80,
                    "percentage": 37.5,
                },
            )
        )

    for index in range(15):
        if index % 3 == 0:
            cases.append(
                GoldenCase(
                    case_id=f"filter-{index + 1:02d}",
                    category="filter",
                    question="What are EU customers saying about login?",
                    filters=login_filters,
                    expected_filtered_count=40,
                    expected_theme="Login / Authentication",
                    expected_support_ids={
                        review.external_id
                        for review in reviews
                        if review.region == "EU" and review.theme == "login"
                    },
                )
            )
        elif index % 3 == 1:
            cases.append(
                GoldenCase(
                    case_id=f"filter-{index + 1:02d}",
                    category="filter",
                    question="What login and performance problems are in version 4.3?",
                    filters=version_filters,
                    expected_filtered_count=30,
                    expected_support_ids={
                        review.external_id for review in reviews if review.product_version == "4.3"
                    },
                )
            )
        else:
            cases.append(
                GoldenCase(
                    case_id=f"filter-{index + 1:02d}",
                    category="filter",
                    question="What login checkout performance export issues are low rated?",
                    filters=low_rating_filters,
                    expected_filtered_count=60,
                    expected_support_ids={
                        review.external_id for review in reviews if review.rating <= 2
                    },
                )
            )

    for index in range(15):
        cases.append(
            GoldenCase(
                case_id=f"comparison-{index + 1:02d}",
                category="comparison",
                question=(
                    "Why did ratings decline after version 4.2?"
                    if index % 2 == 0
                    else "Why did ratings fall after v4.2?"
                ),
                expected_theme="Performance",
                expected_support_ids={
                    review.external_id
                    for review in reviews
                    if review.product_version in {"4.3", "4.4"} and review.rating <= 2
                },
                expected_comparison_delta=-3.5,
            )
        )

    impossible_questions = [
        "Are customers asking for cryptocurrency trading?",
        "Are users complaining about physical store parking?",
        "Are customers discussing Alexa integration?",
        "Are customers saying their phones are catching fire?",
        "Are customers upset about delivery drivers?",
        "Are users describing warranty repair delays?",
        "Are customers asking for airport lounge access?",
        "Are customers complaining about hotel breakfast?",
        "Are users having Bluetooth pairing problems?",
        "Are customers requesting gift cards?",
    ]
    for index, question in enumerate(impossible_questions, start=1):
        cases.append(
            GoldenCase(
                case_id=f"impossible-{index:02d}",
                category="impossible",
                question=question,
                expected_abstain=True,
            )
        )
    return cases


def support_ids_by_theme(reviews: list[GoldenReview]) -> dict[str, set[str]]:
    return {
        "login": {review.external_id for review in reviews if review.theme == "login"},
        "performance": {
            review.external_id for review in reviews if review.theme == "performance"
        },
        "billing": {review.external_id for review in reviews if review.theme == "billing"},
        "export": {review.external_id for review in reviews if review.theme == "export"},
    }


def filter_reviews(reviews: list[Review], filters: AnswerFilters) -> list[Review]:
    filtered = reviews
    if filters.rating_min is not None:
        filtered = [
            review
            for review in filtered
            if review.rating is not None and review.rating >= filters.rating_min
        ]
    if filters.rating_max is not None:
        filtered = [
            review
            for review in filtered
            if review.rating is not None and review.rating <= filters.rating_max
        ]
    if filters.product_version:
        filtered = [
            review for review in filtered if review.product_version == filters.product_version
        ]
    if filters.region:
        filtered = [review for review in filtered if review.region == filters.region]
    return filtered


def build_golden_reviews() -> list[GoldenReview]:
    rows: list[GoldenReview] = []
    theme_specs = [
        ("login", "Login fails and password reset keeps rejecting customers", 1, "4.3", "EU", 15),
        ("performance", "The app is slow with lag and freezes on reports", 2, "4.3", "NA", 15),
        ("billing", "Checkout payment fails and invoices are confusing", 1, "4.4", "EU", 15),
        ("export", "Export downloads fail and reports are missing", 2, "4.4", "NA", 15),
        (
            "positive",
            "Version 4.2 performance is stable smooth and easy to use",
            5,
            "4.2",
            "EU",
            20,
        ),
    ]
    counter = 1
    for theme, text, rating, version, region, count in theme_specs:
        for index in range(count):
            rows.append(
                GoldenReview(
                    external_id=f"eval-{counter:03d}",
                    text=f"{text} #{index + 1}",
                    rating=rating,
                    review_date=date(2026, 8, min(index + 1, 28)),
                    product_version=version,
                    region=region if index % 2 == 0 else ("NA" if region == "EU" else "EU"),
                    theme=theme,
                )
            )
            counter += 1
    return rows


def golden_reviews_csv(reviews: list[GoldenReview]) -> str:
    lines = ["review_id,review_text,rating,review_date,product_version,product,source,region"]
    for review in reviews:
        lines.append(
            ",".join(
                [
                    review.external_id,
                    review.text,
                    str(review.rating),
                    review.review_date.isoformat(),
                    review.product_version,
                    "Mobile App",
                    "golden_eval",
                    review.region,
                ]
            )
        )
    return "\n".join(lines)
