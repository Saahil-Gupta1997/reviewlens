from collections.abc import Iterable
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.routes.datasets import (
    apply_review_filters,
    build_rating_distribution,
    build_volume_trend,
    count_reviews,
    rating_summary,
)
from app.models.dataset import AnswerInteraction, Dataset, Review
from app.schemas.answers import AnswerRunDetail
from app.schemas.exploration import ExploreMetrics
from app.schemas.reports import InsightReportRequest, InsightReportResponse, InsightReportSection
from app.schemas.retrieval import RetrievalStatusResponse
from app.services.observability import (
    build_observability_metrics,
    get_answer_run_detail,
)
from app.services.retrieval import retrieval_status_for_dataset
from app.services.themes import analyze_review_themes, compare_theme_segments


async def build_insight_report(
    session: AsyncSession,
    *,
    dataset: Dataset,
    request: InsightReportRequest,
) -> InsightReportResponse:
    filters = request.filters
    base_query = select(Review).where(Review.dataset_id == dataset.id, Review.is_deleted.is_(False))
    filtered_query = apply_review_filters(
        base_query,
        rating_min=filters.rating_min,
        rating_max=filters.rating_max,
        date_from=filters.date_from,
        date_to=filters.date_to,
        product_name=filters.product_name,
        product_version=filters.product_version,
        source=filters.source,
        region=filters.region,
        country=filters.country,
        language=filters.language,
        customer_segment=filters.customer_segment,
        platform=filters.platform,
        channel=filters.channel,
        verified_purchase=filters.verified_purchase,
        q=filters.q,
    )

    total_reviews = await count_reviews(session, base_query)
    filtered_reviews = await count_reviews(session, filtered_query)
    average_rating, rated_reviews = await rating_summary(session, filtered_query)
    rating_distribution = await build_rating_distribution(session, filtered_query)
    volume_trend = await build_volume_trend(session, filtered_query)
    result = await session.execute(filtered_query.order_by(Review.row_number.asc()))
    reviews = list(result.scalars().all())

    theme_analysis = analyze_review_themes(
        dataset_id=dataset.id,
        reviews=reviews,
        total_reviews=total_reviews,
    )
    top_themes = theme_analysis.themes[: request.theme_limit]
    retrieval_status = await build_report_retrieval_status(session, dataset_id=dataset.id)
    quality_metrics = await build_observability_metrics(session, dataset_id=dataset.id)
    recent_answers = await build_recent_answer_details(
        session,
        dataset_id=dataset.id,
        limit=request.recent_answers_limit,
    )

    segment_comparison = None
    if request.segment_comparison:
        segment = request.segment_comparison
        segment_comparison = compare_theme_segments(
            dataset_id=dataset.id,
            compare_by=segment.compare_by,
            left_value=segment.left_value,
            right_value=segment.right_value,
            reviews=reviews,
            limit=segment.limit,
            min_count=segment.min_count,
        )

    metrics = ExploreMetrics(
        total_reviews=total_reviews,
        filtered_reviews=filtered_reviews,
        average_rating=average_rating,
        rated_reviews=rated_reviews,
    )
    generated_at = datetime.now(UTC)
    title = request.title or f"{dataset.name} Insight Brief"
    limitations = report_limitations(
        filtered_reviews=filtered_reviews,
        retrieval_status=retrieval_status.status,
        theme_limitations=theme_analysis.limitations,
        segment_limitations=segment_comparison.limitations if segment_comparison else [],
    )
    sections = build_sections(
        dataset=dataset,
        metrics=metrics,
        top_themes=top_themes,
        retrieval_status=retrieval_status,
        recent_answers=recent_answers,
        segment_comparison=segment_comparison,
        limitations=limitations,
    )
    markdown = build_markdown(
        title=title,
        generated_at=generated_at,
        dataset=dataset,
        filters=active_filter_lines(filters.model_dump(mode="json")),
        sections=sections,
        limitations=limitations,
    )

    return InsightReportResponse(
        dataset_id=dataset.id,
        title=title,
        generated_at=generated_at,
        filters=filters,
        metrics=metrics,
        rating_distribution=rating_distribution,
        volume_trend=volume_trend,
        retrieval_status=retrieval_status,
        quality_metrics=quality_metrics,
        top_themes=top_themes,
        segment_comparison=segment_comparison,
        recent_answers=recent_answers,
        sections=sections,
        markdown=markdown,
        limitations=limitations,
    )


async def build_report_retrieval_status(
    session: AsyncSession,
    *,
    dataset_id: str,
) -> RetrievalStatusResponse:
    return await retrieval_status_for_dataset(session, dataset_id=dataset_id)


async def build_recent_answer_details(
    session: AsyncSession,
    *,
    dataset_id: str,
    limit: int,
) -> list[AnswerRunDetail]:
    if limit <= 0:
        return []
    result = await session.execute(
        select(AnswerInteraction.id)
        .where(AnswerInteraction.dataset_id == dataset_id)
        .order_by(AnswerInteraction.created_at.desc())
        .limit(limit)
    )
    answer_ids = list(result.scalars().all())
    details: list[AnswerRunDetail] = []
    for answer_id in answer_ids:
        detail = await get_answer_run_detail(session, dataset_id=dataset_id, answer_id=answer_id)
        if detail:
            details.append(detail)
    return details


def build_sections(
    *,
    dataset: Dataset,
    metrics: ExploreMetrics,
    top_themes,
    retrieval_status: RetrievalStatusResponse,
    recent_answers: list[AnswerRunDetail],
    segment_comparison,
    limitations: list[str],
) -> list[InsightReportSection]:
    sections = [
        InsightReportSection(
            title="Snapshot",
            summary=(
                f"{dataset.name} has {metrics.filtered_reviews} matching reviews out of "
                f"{metrics.total_reviews} total, with average rating "
                f"{metrics.average_rating if metrics.average_rating is not None else 'N/A'}."
            ),
            bullets=[
                f"{metrics.rated_reviews} matching reviews include a rating.",
                f"Retrieval index status is {retrieval_status.status} "
                f"({retrieval_status.indexed_reviews}/{retrieval_status.total_reviews} indexed).",
            ],
        ),
        InsightReportSection(
            title="Top Themes",
            summary=theme_summary(top_themes),
            bullets=[
                f"{theme.label}: {theme.count} reviews, {round(theme.share * 100)}% share, "
                f"risk {theme.risk_score:.1f}."
                for theme in top_themes
            ]
            or ["No configured theme dictionary matched the filtered review set."],
        ),
    ]

    if segment_comparison:
        sections.append(
            InsightReportSection(
                title="Segment Comparison",
                summary=(
                    f"{segment_comparison.left.segment} vs {segment_comparison.right.segment} "
                    f"by {segment_comparison.compare_by}."
                ),
                bullets=[delta.summary for delta in segment_comparison.deltas]
                or ["No theme deltas found for the selected segments."],
            )
        )

    sections.append(
        InsightReportSection(
            title="Recent Grounded Answers",
            summary=(
                f"{len(recent_answers)} recent answer runs are included."
                if recent_answers
                else "No grounded answer runs have been saved yet."
            ),
            bullets=[
                f"{answer.question} - {answer.confidence} confidence, "
                f"{answer.evidence_count} citations."
                for answer in recent_answers
            ]
            or ["Generate a grounded answer to include cited conclusions in future briefs."],
        )
    )
    sections.append(
        InsightReportSection(
            title="Limitations",
            summary=f"{len(limitations)} limitations apply to this brief.",
            bullets=limitations,
        )
    )
    return sections


def theme_summary(top_themes) -> str:
    if not top_themes:
        return "No themes were detected in the filtered review set."
    lead = top_themes[0]
    return (
        f"{lead.label} is the leading theme with {lead.count} reviews and "
        f"{round(lead.share * 100)}% filtered share."
    )


def report_limitations(
    *,
    filtered_reviews: int,
    retrieval_status: str,
    theme_limitations: Iterable[str],
    segment_limitations: Iterable[str],
) -> list[str]:
    limitations = [
        (
            "Insight briefs are deterministic exports from the current ReviewLens data, "
            "not new LLM analysis."
        ),
    ]
    if filtered_reviews == 0:
        limitations.append("No reviews matched the report filters.")
    if retrieval_status != "indexed":
        limitations.append(
            "Retrieval index is not fully ready, so saved answer coverage may be partial."
        )
    limitations.extend(theme_limitations)
    limitations.extend(segment_limitations)
    return list(dict.fromkeys(limitations))


def build_markdown(
    *,
    title: str,
    generated_at: datetime,
    dataset: Dataset,
    filters: list[str],
    sections: list[InsightReportSection],
    limitations: list[str],
) -> str:
    lines = [
        f"# {title}",
        "",
        f"Generated: {generated_at.isoformat()}",
        f"Dataset: {dataset.name}",
        f"Source file: {dataset.source_filename}",
        "",
        "## Filters",
    ]
    lines.extend(filters or ["- No filters applied."])
    for section in sections:
        lines.extend(["", f"## {section.title}", "", section.summary, ""])
        lines.extend(f"- {bullet}" for bullet in section.bullets)
    if limitations and sections[-1].title != "Limitations":
        lines.extend(["", "## Limitations", ""])
        lines.extend(f"- {limitation}" for limitation in limitations)
    return "\n".join(lines).strip() + "\n"


def active_filter_lines(filters: dict[str, object]) -> list[str]:
    lines = []
    for key, value in filters.items():
        if value not in (None, "", []):
            lines.append(f"- {key}: {value}")
    return lines
