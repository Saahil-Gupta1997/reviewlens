import hashlib
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Literal, Protocol

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dataset import DatasetTheme, Review, ReviewThemeAssignment
from app.services.retrieval import tokenize

ThemeSource = Literal["ai", "fallback", "seeded"]

STOPWORDS = {
    "a",
    "about",
    "after",
    "all",
    "also",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "because",
    "been",
    "but",
    "by",
    "can",
    "customer",
    "customers",
    "did",
    "do",
    "does",
    "for",
    "from",
    "get",
    "guest",
    "guests",
    "had",
    "has",
    "have",
    "hotel",
    "how",
    "i",
    "in",
    "is",
    "it",
    "my",
    "not",
    "of",
    "on",
    "or",
    "our",
    "review",
    "reviews",
    "room",
    "rooms",
    "saying",
    "that",
    "the",
    "their",
    "this",
    "to",
    "users",
    "was",
    "were",
    "what",
    "when",
    "why",
    "with",
}

THEME_KEYWORDS = {
    "Login / Authentication": {
        "auth",
        "authenticate",
        "authentication",
        "log",
        "login",
        "password",
        "signin",
        "sign",
    },
    "Performance": {"freeze", "freezes", "lag", "latency", "performance", "slow", "slower"},
    "Reliability": {"bug", "crash", "crashes", "error", "fail", "fails", "failed", "broken"},
    "Exports / Reporting": {"download", "downloads", "export", "exports", "report", "reports"},
    "Checkout / Billing": {"billing", "checkout", "invoice", "payment", "payments"},
    "Usability": {"confusing", "hard", "navigation", "unclear", "ui", "usability"},
}

ADAPTIVE_THEME_SEEDS = {
    "Room cleanliness": {
        "bathroom",
        "bedsheet",
        "bedsheets",
        "clean",
        "cleaned",
        "cleanliness",
        "dirty",
        "dust",
        "dusty",
        "housekeeping",
        "mold",
        "mould",
        "sheet",
        "sheets",
        "smell",
        "stain",
        "stained",
        "stains",
        "towels",
        "unclean",
    },
    "Breakfast quality": {
        "breakfast",
        "buffet",
        "coffee",
        "cold",
        "dining",
        "eggs",
        "food",
        "fresh",
        "menu",
        "restaurant",
    },
    "Check-in delays": {
        "arrival",
        "check",
        "checkin",
        "desk",
        "front",
        "queue",
        "reception",
        "wait",
        "waited",
        "waiting",
    },
    "Room noise": {
        "hallway",
        "loud",
        "noise",
        "noisy",
        "quiet",
        "sound",
        "street",
        "thin",
        "walls",
    },
    "Staff behavior": {
        "behaviour",
        "behavior",
        "friendly",
        "helpful",
        "manager",
        "reception",
        "rude",
        "service",
        "staff",
    },
    "Wi-Fi reliability": {
        "connection",
        "fi",
        "internet",
        "network",
        "wifi",
        "wi",
    },
    "Data synchronization": {"sync", "synced", "synchronization", "synchronise", "synchronize"},
    "Subscription pricing": {
        "expensive",
        "plan",
        "price",
        "pricing",
        "renewal",
        "subscription",
    },
    "Export failures": {"download", "downloads", "export", "exports", "failed", "report"},
}

GENERIC_THEME_WORDS = {
    "app",
    "experience",
    "good",
    "great",
    "issue",
    "issues",
    "product",
    "problem",
    "problems",
    "service",
    "thing",
    "update",
    "use",
    "works",
}


@dataclass(frozen=True)
class DiscoveredTheme:
    theme_key: str
    label: str
    description: str
    keywords: frozenset[str]
    source: ThemeSource


@dataclass
class ThemeAssignment:
    theme: DiscoveredTheme
    review: Review
    confidence: float
    evidence_text: str


@dataclass
class ThemeDiscoveryResult:
    themes: list[DiscoveredTheme]
    assignments: list[ThemeAssignment]


class ThemeDiscoveryProvider(Protocol):
    model_name: str

    def discover(self, reviews: list[Review]) -> ThemeDiscoveryResult:
        ...


class LocalAdaptiveThemeDiscoveryProvider:
    model_name = "reviewlens-local-adaptive-themes-v1"

    def discover(self, reviews: list[Review]) -> ThemeDiscoveryResult:
        definitions = seeded_theme_definitions()
        definitions.extend(adaptive_seed_definitions(reviews))
        definitions.extend(phrase_theme_definitions(reviews))
        definitions_by_key = {definition.theme_key: definition for definition in definitions}
        assignments = build_assignments(reviews=reviews, themes=list(definitions_by_key.values()))
        assigned_keys = {assignment.theme.theme_key for assignment in assignments}
        themes = [
            definition
            for definition in definitions_by_key.values()
            if definition.source == "seeded" or definition.theme_key in assigned_keys
        ]
        return ThemeDiscoveryResult(themes=themes, assignments=assignments)


def get_theme_discovery_provider() -> ThemeDiscoveryProvider:
    return LocalAdaptiveThemeDiscoveryProvider()


async def ensure_theme_assignments(
    session: AsyncSession,
    *,
    dataset_id: str,
    reviews: list[Review],
) -> None:
    if not reviews:
        return

    result = get_theme_discovery_provider().discover(reviews)
    existing = await existing_theme_catalog(session, dataset_id=dataset_id)
    for theme in result.themes:
        row = existing.get(theme.theme_key)
        if row is None:
            row = DatasetTheme(
                dataset_id=dataset_id,
                theme_key=theme.theme_key,
                label=theme.label,
                description=theme.description,
                keywords_json=json.dumps(sorted(theme.keywords)),
                source=theme.source,
                discovery_model=get_theme_discovery_provider().model_name,
            )
            session.add(row)
            existing[theme.theme_key] = row
        else:
            row.label = theme.label
            row.description = theme.description
            row.keywords_json = json.dumps(sorted(theme.keywords))
            row.source = theme.source
            row.discovery_model = get_theme_discovery_provider().model_name
            row.updated_at = datetime.now(UTC)

    await session.flush()
    review_ids = [review.id for review in reviews]
    await session.execute(
        delete(ReviewThemeAssignment).where(
            ReviewThemeAssignment.dataset_id == dataset_id,
            ReviewThemeAssignment.review_id.in_(review_ids),
        )
    )
    for assignment in result.assignments:
        theme_row = existing[assignment.theme.theme_key]
        session.add(
            ReviewThemeAssignment(
                dataset_id=dataset_id,
                review_id=assignment.review.id,
                theme_id=theme_row.id,
                confidence=assignment.confidence,
                evidence_text=assignment.evidence_text,
            )
        )
    await session.commit()


async def existing_theme_catalog(
    session: AsyncSession,
    *,
    dataset_id: str,
) -> dict[str, DatasetTheme]:
    rows = await session.execute(
        select(DatasetTheme).where(DatasetTheme.dataset_id == dataset_id)
    )
    return {theme.theme_key: theme for theme in rows.scalars().all()}


def seeded_theme_definitions() -> list[DiscoveredTheme]:
    return [
        DiscoveredTheme(
            theme_key=theme_key_for_label(label),
            label=label,
            description=f"Reviews mentioning {label.lower()} issues.",
            keywords=frozenset(keywords),
            source="seeded",
        )
        for label, keywords in THEME_KEYWORDS.items()
    ]


def adaptive_seed_definitions(reviews: list[Review]) -> list[DiscoveredTheme]:
    min_count = minimum_theme_count(reviews)
    counts: Counter[str] = Counter()
    observed_keywords: dict[str, set[str]] = defaultdict(set)
    for review in reviews:
        tokens = review_token_set(review)
        for label, keywords in ADAPTIVE_THEME_SEEDS.items():
            matches = tokens & keywords
            if matches:
                counts[label] += 1
                observed_keywords[label].update(matches)

    definitions = []
    for label, count in counts.items():
        if count < min_count:
            continue
        keywords = ADAPTIVE_THEME_SEEDS[label] | observed_keywords[label]
        definitions.append(
            DiscoveredTheme(
                theme_key=theme_key_for_label(label),
                label=label,
                description=f"AI-assisted theme discovered from {count} matching reviews.",
                keywords=frozenset(keywords),
                source="ai",
            )
        )
    return definitions


def phrase_theme_definitions(reviews: list[Review]) -> list[DiscoveredTheme]:
    min_count = max(minimum_theme_count(reviews), 2)
    phrase_counts: Counter[tuple[str, ...]] = Counter()
    for review in reviews:
        tokens = meaningful_tokens(review.normalized_text)
        seen_phrases = set()
        for size in (2, 3):
            for index in range(0, max(len(tokens) - size + 1, 0)):
                phrase = tuple(tokens[index : index + size])
                if phrase_has_signal(phrase):
                    seen_phrases.add(phrase)
        phrase_counts.update(seen_phrases)

    definitions = []
    for phrase, count in phrase_counts.most_common(12):
        if count < min_count:
            continue
        label = " ".join(phrase).title()
        definitions.append(
            DiscoveredTheme(
                theme_key=theme_key_for_label(label),
                label=label,
                description=f"AI-assisted recurring phrase theme found in {count} reviews.",
                keywords=frozenset(phrase),
                source="ai",
            )
        )
    return definitions


def build_assignments(
    *,
    reviews: list[Review],
    themes: list[DiscoveredTheme],
) -> list[ThemeAssignment]:
    assignments = []
    for review in reviews:
        tokens = review_token_set(review)
        for theme in themes:
            matches = tokens & theme.keywords
            if not matches:
                continue
            confidence = confidence_for_matches(matches=matches, theme=theme)
            assignments.append(
                ThemeAssignment(
                    theme=theme,
                    review=review,
                    confidence=confidence,
                    evidence_text=", ".join(sorted(matches)[:6]),
                )
            )
    return assignments


def confidence_for_matches(*, matches: set[str], theme: DiscoveredTheme) -> float:
    denominator = max(min(len(theme.keywords), 6), 1)
    return round(min(0.55 + (len(matches) / denominator * 0.45), 0.98), 4)


def review_token_set(review: Review) -> set[str]:
    return set(meaningful_tokens(review.normalized_text))


def meaningful_tokens(text: str) -> list[str]:
    tokens = [normalize_token(token) for token in tokenize(text)]
    return [
        token
        for token in tokens
        if token and len(token) > 2 and token not in STOPWORDS and token not in GENERIC_THEME_WORDS
    ]


def normalize_token(token: str) -> str:
    lowered = token.lower()
    if lowered in {"wi-fi", "wifi"}:
        return "wifi"
    return re.sub(r"[^a-z0-9]", "", lowered)


def phrase_has_signal(phrase: tuple[str, ...]) -> bool:
    return len(set(phrase)) == len(phrase) and not set(phrase) <= GENERIC_THEME_WORDS


def minimum_theme_count(reviews: list[Review]) -> int:
    if len(reviews) < 8:
        return 1
    if len(reviews) < 50:
        return 2
    return max(3, round(len(reviews) * 0.03))


def theme_key_for_label(label: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
    digest = hashlib.sha1(label.lower().encode("utf-8")).hexdigest()[:8]
    return f"{slug}_{digest}"
