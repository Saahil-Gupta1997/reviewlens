import hashlib
import json
import math
import re
from collections import Counter
from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Protocol

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings, get_settings
from app.models.dataset import Review, ReviewEmbedding
from app.schemas.retrieval import (
    RetrievalEvidenceItem,
    RetrievalIndexResponse,
    RetrievalStatusResponse,
)

LOCAL_EMBEDDING_MODEL = "reviewlens-local-hash-v1"
LOCAL_EMBEDDING_DIMENSIONS = 64
TOKEN_RE = re.compile(r"[a-z0-9]+")


class ProviderConfigurationError(RuntimeError):
    """Raised when a configured RAG provider cannot be used."""


class EmbeddingProviderError(RuntimeError):
    """Raised when an embedding provider fails after configuration succeeds."""


class EmbeddingProvider(Protocol):
    model_name: str
    dimensions: int

    async def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        ...


class LocalHashEmbeddingProvider:
    def __init__(
        self,
        *,
        model_name: str = LOCAL_EMBEDDING_MODEL,
        dimensions: int = LOCAL_EMBEDDING_DIMENSIONS,
    ) -> None:
        self.model_name = model_name
        self.dimensions = dimensions

    async def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        return [embed_text(text, dimensions=self.dimensions) for text in texts]


class OpenAIEmbeddingProvider:
    def __init__(self, settings: Settings) -> None:
        self.model_name = settings.openai_embedding_model
        self.dimensions = 0
        self._settings = settings

    async def embed_texts(self, texts: Sequence[str]) -> list[list[float]]:
        if not texts:
            return []
        if not self._settings.openai_api_key:
            raise ProviderConfigurationError(
                "OPENAI_API_KEY is required when EMBEDDING_PROVIDER=openai."
            )

        try:
            from openai import AsyncOpenAI
        except ImportError as exc:
            raise ProviderConfigurationError(
                "Install the openai package to use EMBEDDING_PROVIDER=openai."
            ) from exc

        client = AsyncOpenAI(
            api_key=self._settings.openai_api_key,
            base_url=self._settings.openai_base_url,
            timeout=self._settings.openai_request_timeout_seconds,
        )
        try:
            response = await client.embeddings.create(model=self.model_name, input=list(texts))
        except Exception as exc:
            raise EmbeddingProviderError(
                "Embedding provider failed before returning vectors."
            ) from exc
        ordered = sorted(response.data, key=lambda item: item.index)
        return [list(item.embedding) for item in ordered]


def get_embedding_provider(settings: Settings | None = None) -> EmbeddingProvider:
    settings = settings or get_settings()
    provider = settings.embedding_provider.lower()
    if provider == "openai":
        return OpenAIEmbeddingProvider(settings)
    if provider == "local":
        return LocalHashEmbeddingProvider(
            model_name=settings.embedding_model,
            dimensions=settings.embedding_dimensions,
        )
    raise ProviderConfigurationError(
        f"Unsupported EMBEDDING_PROVIDER={settings.embedding_provider!r}."
    )


def current_embedding_model() -> str:
    return get_embedding_provider().model_name


def current_embedding_dimensions() -> int:
    return get_embedding_provider().dimensions


async def index_reviews(
    session: AsyncSession,
    *,
    dataset_id: str,
    reviews: list[Review],
    provider: EmbeddingProvider | None = None,
) -> RetrievalIndexResponse:
    provider = provider or get_embedding_provider()
    if not reviews:
        return RetrievalIndexResponse(
            dataset_id=dataset_id,
            embedding_model=provider.model_name,
            dimensions=provider.dimensions,
            indexed_reviews=0,
            skipped_reviews=0,
        )

    existing_result = await session.execute(
        select(ReviewEmbedding).where(
            ReviewEmbedding.review_id.in_([review.id for review in reviews]),
            ReviewEmbedding.embedding_model == provider.model_name,
        )
    )
    existing_by_review_id = {
        embedding.review_id: embedding for embedding in existing_result.scalars()
    }
    indexed_reviews = 0
    skipped_reviews = 0
    last_dimensions = provider.dimensions
    settings = get_settings()

    for batch in chunk_reviews(reviews, max(settings.embedding_batch_size, 1)):
        reviews_to_embed = []
        for review in batch:
            existing = existing_by_review_id.get(review.id)
            dimensions_match = provider.dimensions == 0 or (
                existing is not None and existing.dimensions == provider.dimensions
            )
            if existing and existing.chunk_hash == review.text_hash and dimensions_match:
                review.embedding_status = "indexed"
                review.indexed_at = datetime.now(UTC)
                last_dimensions = existing.dimensions
                skipped_reviews += 1
            else:
                reviews_to_embed.append(review)

        if not reviews_to_embed:
            continue

        vectors = await provider.embed_texts(
            [review.normalized_text for review in reviews_to_embed]
        )
        for review, vector in zip(reviews_to_embed, vectors, strict=True):
            vector_json = json.dumps(vector, separators=(",", ":"))
            vector_hash = sha256(vector_json)
            existing = existing_by_review_id.get(review.id)
            last_dimensions = len(vector)

            if existing:
                existing.vector_json = vector_json
                existing.vector_hash = vector_hash
                existing.chunk_hash = review.text_hash
                existing.chunk_text = review.review_text
                existing.dimensions = len(vector)
                existing.embedding_status = "embedded"
                existing.embedding_error = None
                existing.updated_at = datetime.now(UTC)
            else:
                session.add(
                    ReviewEmbedding(
                        dataset_id=dataset_id,
                        review_id=review.id,
                        chunk_index=0,
                        chunk_text=review.review_text,
                        chunk_hash=review.text_hash,
                        embedding_model=provider.model_name,
                        dimensions=len(vector),
                        vector_json=vector_json,
                        vector_hash=vector_hash,
                        embedding_status="embedded",
                    )
                )
            indexed_reviews += 1
            review.embedding_status = "indexed"
            review.indexed_at = datetime.now(UTC)

    await session.commit()
    return RetrievalIndexResponse(
        dataset_id=dataset_id,
        embedding_model=provider.model_name,
        dimensions=last_dimensions,
        indexed_reviews=indexed_reviews,
        skipped_reviews=skipped_reviews,
    )


async def search_reviews(
    session: AsyncSession,
    *,
    dataset_id: str,
    query: str,
    reviews: list[Review],
    mode: str,
    top_k: int,
) -> tuple[str, list[RetrievalEvidenceItem]]:
    if not reviews:
        return "empty", []

    provider = get_embedding_provider()
    if mode in {"semantic", "hybrid"} and get_settings().retrieval_auto_index:
        await ensure_review_embeddings(
            session,
            dataset_id=dataset_id,
            reviews=reviews,
            provider=provider,
        )

    embeddings = await load_embeddings_for_model(
        session,
        [review.id for review in reviews],
        embedding_model=provider.model_name,
    )
    query_vector = []
    if mode in {"semantic", "hybrid"}:
        query_vector = (await provider.embed_texts([query]))[0]
    query_tokens = set(tokenize(query))
    results: list[RetrievalEvidenceItem] = []

    for review in reviews:
        embedding = embeddings.get(review.id)
        semantic_score = cosine_similarity(query_vector, embedding) if embedding else 0.0
        keyword_score = keyword_overlap(query_tokens, review.normalized_text)
        hybrid_score = calculate_hybrid_score(
            mode=mode,
            semantic_score=semantic_score,
            keyword_score=keyword_score,
        )
        if hybrid_score <= 0:
            continue
        results.append(
            RetrievalEvidenceItem(
                review_id=review.id,
                row_number=review.row_number,
                review_text=review.review_text,
                rating=review.rating,
                review_date=review.review_date,
                source=review.source,
                product_name=review.product_name,
                product_version=review.product_version,
                region=review.region,
                country=review.country,
                customer_segment=review.customer_segment,
                semantic_score=round(semantic_score, 4),
                keyword_score=round(keyword_score, 4),
                hybrid_score=round(hybrid_score, 4),
            )
        )

    results.sort(key=lambda result: (-result.hybrid_score, result.row_number))
    index_status = "ready" if len(embeddings) == len(reviews) else "partial"
    return index_status, results[:top_k]


async def ensure_review_embeddings(
    session: AsyncSession,
    *,
    dataset_id: str,
    reviews: list[Review],
    provider: EmbeddingProvider,
) -> None:
    rows = await load_embedding_rows(
        session,
        [review.id for review in reviews],
        provider.model_name,
    )
    missing_or_stale = [
        review
        for review in reviews
        if review.id not in rows or rows[review.id].chunk_hash != review.text_hash
    ]
    if missing_or_stale:
        await index_reviews(
            session,
            dataset_id=dataset_id,
            reviews=missing_or_stale,
            provider=provider,
        )


async def retrieval_status_for_dataset(
    session: AsyncSession,
    *,
    dataset_id: str,
) -> RetrievalStatusResponse:
    provider = get_embedding_provider()
    total_reviews = int(
        await session.scalar(
            select(func.count()).where(
                Review.dataset_id == dataset_id,
                Review.is_deleted.is_(False),
            )
        )
        or 0
    )
    indexed_reviews = int(
        await session.scalar(
            select(func.count())
            .select_from(ReviewEmbedding)
            .where(
                ReviewEmbedding.dataset_id == dataset_id,
                ReviewEmbedding.embedding_model == provider.model_name,
                ReviewEmbedding.embedding_status == "embedded",
            )
        )
        or 0
    )
    stored_dimensions = await session.scalar(
        select(func.max(ReviewEmbedding.dimensions)).where(
            ReviewEmbedding.dataset_id == dataset_id,
            ReviewEmbedding.embedding_model == provider.model_name,
            ReviewEmbedding.embedding_status == "embedded",
        )
    )
    pending_reviews = max(total_reviews - indexed_reviews, 0)
    if total_reviews == 0:
        status_label = "empty"
    elif indexed_reviews == total_reviews:
        status_label = "indexed"
    elif indexed_reviews > 0:
        status_label = "partial"
    else:
        status_label = "pending"

    return RetrievalStatusResponse(
        dataset_id=dataset_id,
        embedding_model=provider.model_name,
        dimensions=int(stored_dimensions or provider.dimensions),
        total_reviews=total_reviews,
        indexed_reviews=indexed_reviews,
        pending_reviews=pending_reviews,
        status=status_label,
    )


async def load_embeddings(session: AsyncSession, review_ids: list[str]) -> dict[str, list[float]]:
    if not review_ids:
        return {}
    embedding_model = current_embedding_model()
    return await load_embeddings_for_model(session, review_ids, embedding_model=embedding_model)


async def load_embeddings_for_model(
    session: AsyncSession,
    review_ids: list[str],
    *,
    embedding_model: str,
) -> dict[str, list[float]]:
    rows = await load_embedding_rows(session, review_ids, embedding_model)
    return {
        review_id: json.loads(embedding.vector_json)
        for review_id, embedding in rows.items()
    }


async def load_embedding_rows(
    session: AsyncSession,
    review_ids: list[str],
    embedding_model: str,
) -> dict[str, ReviewEmbedding]:
    if not review_ids:
        return {}
    result = await session.execute(
        select(ReviewEmbedding).where(
            ReviewEmbedding.review_id.in_(review_ids),
            ReviewEmbedding.embedding_model == embedding_model,
            ReviewEmbedding.embedding_status == "embedded",
        )
    )
    return {embedding.review_id: embedding for embedding in result.scalars().all()}


def embed_text(text: str, *, dimensions: int = LOCAL_EMBEDDING_DIMENSIONS) -> list[float]:
    counts: Counter[int] = Counter()
    for token in tokenize(text):
        token_hash = int(hashlib.sha256(token.encode("utf-8")).hexdigest(), 16)
        index = token_hash % dimensions
        counts[index] += 1

    vector = [0.0] * dimensions
    for index, count in counts.items():
        vector[index] = float(count)

    magnitude = math.sqrt(sum(value * value for value in vector))
    if magnitude == 0:
        return vector
    return [round(value / magnitude, 6) for value in vector]


def tokenize(text: str) -> list[str]:
    return TOKEN_RE.findall(text.lower())


def cosine_similarity(left: list[float], right: list[float]) -> float:
    if not left or not right:
        return 0.0
    dot_product = sum(
        left_value * right_value for left_value, right_value in zip(left, right, strict=False)
    )
    left_magnitude = math.sqrt(sum(value * value for value in left))
    right_magnitude = math.sqrt(sum(value * value for value in right))
    if left_magnitude == 0 or right_magnitude == 0:
        return 0.0
    return dot_product / (left_magnitude * right_magnitude)


def keyword_overlap(query_tokens: set[str], normalized_text: str) -> float:
    if not query_tokens:
        return 0.0
    review_tokens = set(tokenize(normalized_text))
    return len(query_tokens & review_tokens) / len(query_tokens)


def calculate_hybrid_score(*, mode: str, semantic_score: float, keyword_score: float) -> float:
    if mode == "semantic":
        return semantic_score
    if mode == "keyword":
        return keyword_score
    return (semantic_score * 0.65) + (keyword_score * 0.35)


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def chunk_reviews(reviews: list[Review], size: int) -> list[list[Review]]:
    return [reviews[index : index + size] for index in range(0, len(reviews), size)]
