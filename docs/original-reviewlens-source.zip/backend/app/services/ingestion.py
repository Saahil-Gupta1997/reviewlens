import csv
import hashlib
import io
import json
import unicodedata
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dataset import Dataset, IngestionJob, Review, ReviewImportError
from app.schemas.ingestion import DatasetSummary, FieldMapping, ImportErrorPreview

MAX_ROWS_PER_UPLOAD = 50_000
MAX_REVIEW_TEXT_LENGTH = 10_000


class IngestionError(ValueError):
    pass


@dataclass(frozen=True)
class NormalizedReview:
    row_number: int
    external_review_id: str | None
    review_text: str
    normalized_text: str
    review_title: str | None
    rating: float | None
    review_date: date | None
    source: str | None
    product_name: str | None
    product_version: str | None
    region: str | None
    country: str | None
    language: str | None
    customer_segment: str | None
    platform: str | None
    channel: str | None
    verified_purchase: bool | None
    metadata_json: str
    text_hash: str
    metadata_hash: str
    dedupe_key: str


def parse_rows(filename: str, content: bytes) -> list[dict[str, Any]]:
    suffix = Path(filename).suffix.lower()
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise IngestionError("Uploaded file must be UTF-8 encoded.") from exc

    if suffix == ".csv":
        reader = csv.DictReader(io.StringIO(text))
        if not reader.fieldnames:
            raise IngestionError("CSV file must include a header row.")
        return [dict(row) for row in reader if any(value for value in row.values())]

    if suffix == ".json":
        try:
            payload = json.loads(text)
        except json.JSONDecodeError as exc:
            raise IngestionError("JSON file is malformed.") from exc
        if isinstance(payload, dict) and isinstance(payload.get("reviews"), list):
            payload = payload["reviews"]
        if not isinstance(payload, list):
            raise IngestionError("JSON file must be an array or an object with a reviews array.")
        if not all(isinstance(row, dict) for row in payload):
            raise IngestionError("Each JSON review must be an object.")
        return payload

    raise IngestionError("Unsupported file type. Upload a CSV or JSON file.")


async def ingest_dataset(
    session: AsyncSession,
    *,
    filename: str,
    content: bytes,
    dataset_name: str | None = None,
    mapping: FieldMapping | None = None,
    ) -> DatasetSummary:
    mapping = mapping or FieldMapping()
    rows = parse_rows(filename, content)
    if len(rows) > MAX_ROWS_PER_UPLOAD:
        raise IngestionError(
            f"Uploaded dataset has {len(rows)} rows; maximum allowed is "
            f"{MAX_ROWS_PER_UPLOAD} rows."
        )
    dataset = Dataset(
        name=dataset_name or Path(filename).stem or "Review dataset",
        source_filename=filename,
        status="processing",
        total_rows=len(rows),
    )
    session.add(dataset)
    await session.flush()

    accepted: list[NormalizedReview] = []
    errors: list[ImportErrorPreview] = []
    seen_dedupe_keys: set[str] = set()
    duplicate_rows = 0

    for row_number, row in enumerate(rows, start=2 if filename.lower().endswith(".csv") else 1):
        normalized, error = normalize_row(row, row_number, mapping)
        if error:
            errors.append(error)
            continue

        assert normalized is not None
        if normalized.dedupe_key in seen_dedupe_keys:
            duplicate_rows += 1
            continue

        seen_dedupe_keys.add(normalized.dedupe_key)
        accepted.append(normalized)

    for review in accepted:
        session.add(
            Review(
                dataset_id=dataset.id,
                external_review_id=review.external_review_id,
                review_text=review.review_text,
                normalized_text=review.normalized_text,
                review_title=review.review_title,
                rating=review.rating,
                review_date=review.review_date,
                source=review.source,
                product_name=review.product_name,
                product_version=review.product_version,
                region=review.region,
                country=review.country,
                language=review.language,
                customer_segment=review.customer_segment,
                platform=review.platform,
                channel=review.channel,
                verified_purchase=review.verified_purchase,
                metadata_json=review.metadata_json,
                text_hash=review.text_hash,
                metadata_hash=review.metadata_hash,
                dedupe_key=review.dedupe_key,
                row_number=review.row_number,
            )
        )

    for error in errors:
        session.add(
            ReviewImportError(
                dataset_id=dataset.id,
                row_number=error.row_number,
                error_code=error.error_code,
                message=error.message,
                raw_payload_json=json.dumps(error.payload, ensure_ascii=False),
            )
        )

    dataset.status = "ready" if not errors else "completed_with_errors"
    dataset.accepted_rows = len(accepted)
    dataset.rejected_rows = len(errors)
    dataset.duplicate_rows = duplicate_rows

    job = IngestionJob(
        dataset_id=dataset.id,
        status=dataset.status,
        file_type=Path(filename).suffix.lower().lstrip("."),
        field_mapping_json=mapping.model_dump_json(),
        total_rows=len(rows),
        accepted_rows=len(accepted),
        rejected_rows=len(errors),
        duplicate_rows=duplicate_rows,
    )
    session.add(job)

    try:
        await session.commit()
    except IntegrityError as exc:
        await session.rollback()
        message = "Dataset contains duplicate reviews already stored for this dataset."
        raise IngestionError(message) from exc

    return DatasetSummary(
        dataset_id=dataset.id,
        ingestion_job_id=job.id,
        name=dataset.name,
        filename=dataset.source_filename,
        status=dataset.status,
        total_rows=dataset.total_rows,
        accepted_rows=dataset.accepted_rows,
        rejected_rows=dataset.rejected_rows,
        duplicate_rows=dataset.duplicate_rows,
        field_mapping=mapping,
        errors_preview=errors[:10],
    )


def normalize_row(
    row: dict[str, Any],
    row_number: int,
    mapping: FieldMapping,
) -> tuple[NormalizedReview | None, ImportErrorPreview | None]:
    review_text = clean_text(read_field(row, mapping.review_text))
    if not review_text:
        return None, import_error(
            row_number,
            "missing_review_text",
            "Missing required review_text.",
            row,
        )
    if len(review_text) > MAX_REVIEW_TEXT_LENGTH:
        return None, import_error(
            row_number,
            "review_text_too_long",
            f"review_text must be {MAX_REVIEW_TEXT_LENGTH} characters or fewer.",
            row,
        )

    rating, rating_error = parse_rating(read_optional_field(row, mapping.rating))
    if rating_error:
        return None, import_error(row_number, "invalid_rating", rating_error, row)

    review_date, date_error = parse_date(read_optional_field(row, mapping.review_date))
    if date_error:
        return None, import_error(row_number, "invalid_review_date", date_error, row)

    verified_purchase, bool_error = parse_optional_bool(
        read_optional_field(row, mapping.verified_purchase)
    )
    if bool_error:
        return None, import_error(row_number, "invalid_verified_purchase", bool_error, row)

    external_review_id = clean_text(read_optional_field(row, mapping.external_review_id))
    source = clean_text(read_optional_field(row, mapping.source))
    product_name = clean_text(read_optional_field(row, mapping.product_name))
    product_version = clean_text(read_optional_field(row, mapping.product_version))
    metadata = {
        "region": clean_text(read_optional_field(row, mapping.region)),
        "country": clean_text(read_optional_field(row, mapping.country)),
        "language": clean_text(read_optional_field(row, mapping.language)),
        "customer_segment": clean_text(read_optional_field(row, mapping.customer_segment)),
        "platform": clean_text(read_optional_field(row, mapping.platform)),
        "channel": clean_text(read_optional_field(row, mapping.channel)),
    }
    metadata_json = json.dumps(
        {key: value for key, value in metadata.items() if value is not None},
        ensure_ascii=False,
        sort_keys=True,
    )
    normalized_text = normalize_text(review_text)
    text_hash = sha256(normalized_text)
    metadata_hash = sha256(metadata_json)

    return (
        NormalizedReview(
            row_number=row_number,
            external_review_id=external_review_id,
            review_text=review_text,
            normalized_text=normalized_text,
            review_title=clean_text(read_optional_field(row, mapping.review_title)),
            rating=rating,
            review_date=review_date,
            source=source,
            product_name=product_name,
            product_version=product_version,
            region=metadata["region"],
            country=metadata["country"],
            language=metadata["language"],
            customer_segment=metadata["customer_segment"],
            platform=metadata["platform"],
            channel=metadata["channel"],
            verified_purchase=verified_purchase,
            metadata_json=metadata_json,
            text_hash=text_hash,
            metadata_hash=metadata_hash,
            dedupe_key=build_dedupe_key(
                external_review_id=external_review_id,
                normalized_text=normalized_text,
                rating=rating,
                review_date=review_date,
                source=source,
                product_name=product_name,
                product_version=product_version,
            ),
        ),
        None,
    )


def read_field(row: dict[str, Any], field_name: str) -> Any:
    return row.get(field_name)


def read_optional_field(row: dict[str, Any], field_name: str | None) -> Any:
    if not field_name:
        return None
    return row.get(field_name)


def clean_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def parse_rating(value: Any) -> tuple[float | None, str | None]:
    text = clean_text(value)
    if not text:
        return None, None
    try:
        rating = float(text)
    except ValueError:
        return None, "rating must be numeric when provided."
    if rating < 0 or rating > 5:
        return None, "rating must be between 0 and 5."
    return rating, None


def parse_date(value: Any) -> tuple[date | None, str | None]:
    text = clean_text(value)
    if not text:
        return None, None
    try:
        return date.fromisoformat(text[:10]), None
    except ValueError:
        return None, "review_date must use ISO format YYYY-MM-DD when provided."


def parse_optional_bool(value: Any) -> tuple[bool | None, str | None]:
    text = clean_text(value)
    if not text:
        return None, None
    normalized = text.lower()
    if normalized in {"true", "t", "yes", "y", "1", "verified"}:
        return True, None
    if normalized in {"false", "f", "no", "n", "0", "unverified"}:
        return False, None
    return None, "verified_purchase must be true/false when provided."


def build_dedupe_key(
    *,
    external_review_id: str | None,
    normalized_text: str,
    rating: float | None,
    review_date: date | None,
    source: str | None,
    product_name: str | None,
    product_version: str | None,
) -> str:
    if external_review_id:
        return sha256(f"external:{external_review_id.lower()}")

    context = "|".join(
        [
            "context",
            normalized_text,
            "" if rating is None else str(rating),
            "" if review_date is None else review_date.isoformat(),
            normalize_text(source or ""),
            normalize_text(product_name or ""),
            normalize_text(product_version or ""),
        ]
    )
    return sha256(context)


def normalize_text(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value)
    return " ".join(normalized.lower().split())


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def import_error(
    row_number: int,
    error_code: str,
    message: str,
    row: dict[str, Any],
) -> ImportErrorPreview:
    return ImportErrorPreview(
        row_number=row_number,
        error_code=error_code,
        message=message,
        payload=safe_payload(row),
    )


def safe_payload(row: dict[str, Any]) -> dict[str, object | None]:
    safe: dict[str, object | None] = {}
    for key, value in row.items():
        if value is None:
            safe[key] = None
        else:
            text = str(value)
            safe[key] = text if len(text) <= 500 else text[:497] + "..."
    return safe
