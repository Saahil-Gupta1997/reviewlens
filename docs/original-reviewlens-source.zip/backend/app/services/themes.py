from collections import Counter
from dataclasses import dataclass, field
from datetime import date, timedelta

from app.models.dataset import Review
from app.schemas.themes import (
    DatasetThemesResponse,
    SegmentThemeComparisonResponse,
    SegmentThemeDelta,
    SegmentThemeSummary,
    SentimentBucket,
    ThemeComparison,
    ThemeComparisonItem,
    ThemeInsight,
    ThemeSample,
)
from app.services.theme_discovery import (
    ThemeSource,
    get_theme_discovery_provider,
)

MAX_THEMES = 8
MAX_SAMPLES_PER_THEME = 2


@dataclass
class ThemeAccumulator:
    theme_id: str
    label: str
    keywords: set[str]
    source: ThemeSource
    reviews: list[Review] = field(default_factory=list)


def analyze_review_themes(
    *,
    dataset_id: str,
    reviews: list[Review],
    total_reviews: int,
    comparison_reviews: list[Review] | None = None,
    current_start=None,
    current_end=None,
    previous_start=None,
    previous_end=None,
) -> DatasetThemesResponse:
    theme_map = build_theme_map(reviews)
    themes = build_theme_insights(theme_map, analyzed_reviews=len(reviews))
    matched_review_ids = {
        review.id for accumulator in theme_map.values() for review in accumulator.reviews
    }
    comparison = None
    if (
        comparison_reviews is not None
        and current_start is not None
        and current_end is not None
        and previous_start is not None
        and previous_end is not None
    ):
        comparison = build_theme_comparison(
            current_reviews=reviews,
            previous_reviews=comparison_reviews,
            current_start=current_start,
            current_end=current_end,
            previous_start=previous_start,
            previous_end=previous_end,
        )

    return DatasetThemesResponse(
        dataset_id=dataset_id,
        total_reviews=total_reviews,
        analyzed_reviews=len(reviews),
        theme_coverage=round(len(matched_review_ids) / len(reviews), 4) if reviews else 0,
        sentiment_distribution=build_sentiment_distribution(reviews),
        themes=themes,
        comparison=comparison,
        limitations=build_limitations(reviews=reviews, themes=themes, comparison=comparison),
    )


def comparison_window(current_start, current_end):
    if current_start is None or current_end is None:
        return None
    period_days = (current_end - current_start).days + 1
    previous_end = current_start - timedelta(days=1)
    previous_start = previous_end - timedelta(days=period_days - 1)
    return previous_start, previous_end


def build_theme_map(reviews: list[Review]) -> dict[str, ThemeAccumulator]:
    discovery = get_theme_discovery_provider().discover(reviews)
    theme_map = {
        theme.label: ThemeAccumulator(
            theme_id=theme.theme_key,
            label=theme.label,
            keywords=set(theme.keywords),
            source=theme.source,
        )
        for theme in discovery.themes
    }
    for assignment in discovery.assignments:
        accumulator = theme_map.get(assignment.theme.label)
        if accumulator is not None:
            accumulator.reviews.append(assignment.review)

    return theme_map


def build_theme_insights(
    theme_map: dict[str, ThemeAccumulator],
    *,
    analyzed_reviews: int,
    max_themes: int = MAX_THEMES,
    min_count: int = 1,
) -> list[ThemeInsight]:
    insights: list[ThemeInsight] = []
    for accumulator in theme_map.values():
        if len(accumulator.reviews) < min_count:
            continue
        ratings = [review.rating for review in accumulator.reviews if review.rating is not None]
        negative_count = sum(1 for rating in ratings if rating <= 2)
        positive_count = sum(1 for rating in ratings if rating >= 4)
        average_rating = round(sum(ratings) / len(ratings), 2) if ratings else None
        share = len(accumulator.reviews) / analyzed_reviews if analyzed_reviews else 0
        negative_share = negative_count / len(accumulator.reviews)
        risk_score = round((share * 60) + (negative_share * 40), 2)
        insights.append(
            ThemeInsight(
                label=accumulator.label,
                count=len(accumulator.reviews),
                share=round(share, 4),
                average_rating=average_rating,
                negative_count=negative_count,
                positive_count=positive_count,
                risk_score=risk_score,
                keywords=sorted(accumulator.keywords),
                samples=build_samples(accumulator.reviews),
            )
        )

    insights.sort(key=lambda theme: (-theme.risk_score, -theme.count, theme.label))
    return insights[:max_themes]


def build_samples(reviews: list[Review]) -> list[ThemeSample]:
    sorted_reviews = sorted(
        reviews,
        key=lambda review: (
            review.rating if review.rating is not None else 3,
            review.review_date or date.max,
            review.row_number,
        ),
    )
    return [
        ThemeSample(
            review_id=review.id,
            row_number=review.row_number,
            review_text=review.review_text,
            rating=review.rating,
            review_date=review.review_date,
            source=review.source,
            product_name=review.product_name,
        )
        for review in sorted_reviews[:MAX_SAMPLES_PER_THEME]
    ]


def build_sentiment_distribution(reviews: list[Review]) -> list[SentimentBucket]:
    counts = Counter(sentiment_label(review.rating) for review in reviews)
    total = len(reviews)
    return [
        SentimentBucket(
            label=label,
            count=counts[label],
            share=round(counts[label] / total, 4) if total else 0,
        )
        for label in ["negative", "neutral", "positive", "unrated"]
        if counts[label]
    ]


def compare_theme_segments(
    *,
    dataset_id: str,
    compare_by: str,
    left_value: str,
    right_value: str,
    reviews: list[Review],
    limit: int,
    min_count: int,
) -> SegmentThemeComparisonResponse:
    left_reviews = [
        review for review in reviews if segment_value(review, compare_by) == left_value
    ]
    right_reviews = [
        review for review in reviews if segment_value(review, compare_by) == right_value
    ]
    left = build_segment_summary(
        segment=left_value,
        reviews=left_reviews,
        limit=limit,
        min_count=min_count,
    )
    right = build_segment_summary(
        segment=right_value,
        reviews=right_reviews,
        limit=limit,
        min_count=min_count,
    )
    deltas = build_segment_deltas(left=left, right=right, limit=limit)
    return SegmentThemeComparisonResponse(
        dataset_id=dataset_id,
        compare_by=compare_by,
        filtered_review_count=len(reviews),
        left=left,
        right=right,
        deltas=deltas,
        limitations=build_segment_limitations(
            left=left,
            right=right,
            compare_by=compare_by,
            left_value=left_value,
            right_value=right_value,
        ),
    )


def build_segment_summary(
    *,
    segment: str,
    reviews: list[Review],
    limit: int,
    min_count: int,
) -> SegmentThemeSummary:
    ratings = [review.rating for review in reviews if review.rating is not None]
    average_rating = round(sum(ratings) / len(ratings), 2) if ratings else None
    negative_count = sum(1 for rating in ratings if rating <= 2)
    theme_map = build_theme_map(reviews)
    top_themes = build_theme_insights(
        theme_map,
        analyzed_reviews=len(reviews),
        max_themes=limit,
        min_count=min_count,
    )
    return SegmentThemeSummary(
        segment=segment,
        review_count=len(reviews),
        average_rating=average_rating,
        negative_rate=round(negative_count / len(reviews), 4) if reviews else 0,
        sentiment_distribution=build_sentiment_distribution(reviews),
        top_themes=top_themes,
    )


def build_segment_deltas(
    *,
    left: SegmentThemeSummary,
    right: SegmentThemeSummary,
    limit: int,
) -> list[SegmentThemeDelta]:
    left_by_label = {theme.label: theme for theme in left.top_themes}
    right_by_label = {theme.label: theme for theme in right.top_themes}
    labels = sorted(set(left_by_label) | set(right_by_label))
    deltas = []
    for label in labels:
        left_theme = left_by_label.get(label)
        right_theme = right_by_label.get(label)
        left_count = left_theme.count if left_theme else 0
        right_count = right_theme.count if right_theme else 0
        left_share = left_theme.share if left_theme else 0
        right_share = right_theme.share if right_theme else 0
        delta_share = round(left_share - right_share, 4)
        direction = delta_direction(delta_share)
        deltas.append(
            SegmentThemeDelta(
                label=label,
                left_count=left_count,
                right_count=right_count,
                left_share=left_share,
                right_share=right_share,
                delta_share=delta_share,
                direction=direction,
                summary=delta_summary(
                    label=label,
                    left_segment=left.segment,
                    right_segment=right.segment,
                    direction=direction,
                ),
            )
        )
    deltas.sort(
        key=lambda item: (
            -abs(item.delta_share),
            -abs(item.left_count - item.right_count),
            item.label,
        )
    )
    return deltas[:limit]


def delta_direction(delta_share: float):
    if delta_share >= 0.05:
        return "left_higher"
    if delta_share <= -0.05:
        return "right_higher"
    return "similar"


def delta_summary(
    *,
    label: str,
    left_segment: str,
    right_segment: str,
    direction: str,
) -> str:
    if direction == "left_higher":
        return f"{label} appears more often in {left_segment} than {right_segment}."
    if direction == "right_higher":
        return f"{label} appears more often in {right_segment} than {left_segment}."
    return f"{label} appears at a similar rate in {left_segment} and {right_segment}."


def segment_value(review: Review, compare_by: str) -> str:
    value = getattr(review, compare_by)
    if value is None or value == "":
        return "Unknown"
    return str(value)


def build_segment_limitations(
    *,
    left: SegmentThemeSummary,
    right: SegmentThemeSummary,
    compare_by: str,
    left_value: str,
    right_value: str,
) -> list[str]:
    limitations = []
    if left.review_count == 0:
        limitations.append(f"No reviews matched {compare_by}={left_value}.")
    if right.review_count == 0:
        limitations.append(f"No reviews matched {compare_by}={right_value}.")
    if left.review_count < 5 or right.review_count < 5:
        limitations.append("Segment comparison is based on a small sample.")
    limitations.append("Segment comparison uses deterministic keyword groups and rating buckets.")
    return limitations


def build_theme_comparison(
    *,
    current_reviews: list[Review],
    previous_reviews: list[Review],
    current_start,
    current_end,
    previous_start,
    previous_end,
) -> ThemeComparison:
    current_counts = theme_counts(current_reviews)
    previous_counts = theme_counts(previous_reviews)
    labels = sorted(set(current_counts) | set(previous_counts))
    current_total = max(len(current_reviews), 1)
    previous_total = max(len(previous_reviews), 1)
    items = [
        ThemeComparisonItem(
            label=label,
            current_count=current_counts[label],
            previous_count=previous_counts[label],
            delta=current_counts[label] - previous_counts[label],
            delta_share=round(
                (current_counts[label] / current_total)
                - (previous_counts[label] / previous_total),
                4,
            ),
        )
        for label in labels
    ]
    items.sort(key=lambda item: (-abs(item.delta_share), -abs(item.delta), item.label))
    return ThemeComparison(
        current_start=current_start,
        current_end=current_end,
        previous_start=previous_start,
        previous_end=previous_end,
        items=items[:MAX_THEMES],
    )


def theme_counts(reviews: list[Review]) -> Counter[str]:
    counts: Counter[str] = Counter()
    for label, accumulator in build_theme_map(reviews).items():
        counts[label] = len(accumulator.reviews)
    return counts


def build_limitations(
    *,
    reviews: list[Review],
    themes: list[ThemeInsight],
    comparison: ThemeComparison | None,
) -> list[str]:
    limitations: list[str] = []
    if not reviews:
        limitations.append("No reviews matched the selected filters.")
    if len(reviews) < 5:
        limitations.append("Theme percentages are based on a small filtered sample.")
    if not themes:
        limitations.append("No recurring issue theme was discovered in this review set.")
    if comparison is None:
        limitations.append("Select both Date from and Date to to enable period comparison.")
    limitations.append(
        "Theme labels are AI-assisted; percentages are counted from "
        "deterministic review assignments."
    )
    return limitations


def sentiment_label(rating: float | None) -> str:
    if rating is None:
        return "unrated"
    if rating <= 2:
        return "negative"
    if rating >= 4:
        return "positive"
    return "neutral"
