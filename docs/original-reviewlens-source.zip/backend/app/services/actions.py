from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.routes.datasets import apply_review_filters
from app.models.dataset import Dataset, Review
from app.schemas.actions import (
    ActionPlanMetric,
    ActionPlanRequest,
    ActionPlanResponse,
    ReviewActionItem,
)
from app.schemas.themes import SegmentThemeComparisonResponse, ThemeInsight
from app.services.themes import analyze_review_themes, compare_theme_segments


async def build_action_plan(
    session: AsyncSession,
    *,
    dataset: Dataset,
    request: ActionPlanRequest,
) -> ActionPlanResponse:
    filters = request.filters
    query = apply_review_filters(
        select(Review).where(Review.dataset_id == dataset.id, Review.is_deleted.is_(False)),
        rating_min=filters.rating_min,
        rating_max=filters.rating_max,
        date_from=filters.date_from,
        date_to=filters.date_to,
        product_name=filters.product_name,
        product_version=filters.product_version,
        source=filters.source,
        region=filters.region,
        country=filters.country,
        language=filters.language,
        customer_segment=filters.customer_segment,
        platform=filters.platform,
        channel=filters.channel,
        verified_purchase=filters.verified_purchase,
        q=filters.q,
    )
    result = await session.execute(query.order_by(Review.row_number.asc()))
    reviews = list(result.scalars().all())

    all_reviews_result = await session.execute(
        select(Review).where(Review.dataset_id == dataset.id, Review.is_deleted.is_(False))
    )
    total_reviews = len(list(all_reviews_result.scalars().all()))
    ratings = [review.rating for review in reviews if review.rating is not None]
    average_rating = round(sum(ratings) / len(ratings), 2) if ratings else None
    negative_review_count = sum(1 for rating in ratings if rating <= 2)

    theme_analysis = analyze_review_themes(
        dataset_id=dataset.id,
        reviews=reviews,
        total_reviews=total_reviews,
    )
    top_themes = theme_analysis.themes[: request.theme_limit]

    segment_comparison = None
    if request.segment_comparison:
        segment = request.segment_comparison
        segment_comparison = compare_theme_segments(
            dataset_id=dataset.id,
            compare_by=segment.compare_by,
            left_value=segment.left_value,
            right_value=segment.right_value,
            reviews=reviews,
            limit=segment.limit,
            min_count=segment.min_count,
        )

    actions = [
        build_action_item(
            theme=theme,
            rank=index + 1,
            audience=request.audience,
            filtered_review_count=len(reviews),
            segment_comparison=segment_comparison,
        )
        for index, theme in enumerate(top_themes[: request.max_actions])
    ]
    limitations = build_limitations(
        reviews=reviews,
        top_themes=top_themes,
        theme_limitations=theme_analysis.limitations,
        segment_comparison=segment_comparison,
    )
    segment_drivers = build_segment_drivers(segment_comparison)
    generated_at = datetime.now(UTC)
    markdown = build_markdown(
        dataset=dataset,
        generated_at=generated_at,
        request=request,
        filtered_review_count=len(reviews),
        average_rating=average_rating,
        negative_review_count=negative_review_count,
        actions=actions,
        segment_drivers=segment_drivers,
        limitations=limitations,
    )

    return ActionPlanResponse(
        dataset_id=dataset.id,
        generated_at=generated_at,
        audience=request.audience,
        filters=filters,
        filtered_review_count=len(reviews),
        average_rating=average_rating,
        negative_review_count=negative_review_count,
        top_themes=top_themes,
        actions=actions,
        segment_drivers=segment_drivers,
        limitations=limitations,
        markdown=markdown,
    )


def build_action_item(
    *,
    theme: ThemeInsight,
    rank: int,
    audience: str,
    filtered_review_count: int,
    segment_comparison: SegmentThemeComparisonResponse | None,
) -> ReviewActionItem:
    owner = owner_for_theme(theme.label, audience)
    priority = priority_for_theme(theme=theme, filtered_review_count=filtered_review_count)
    effort = effort_for_theme(theme.label)
    leading_segment = leading_segment_for_theme(theme.label, segment_comparison)
    segment_phrase = (
        f" The strongest segment signal is {leading_segment}." if leading_segment else ""
    )
    title = title_for_theme(theme.label, owner)
    negative_rate = theme.negative_count / theme.count if theme.count else 0
    return ReviewActionItem(
        action_id=f"A{rank:02d}",
        title=title,
        priority=priority,
        owner=owner,
        effort=effort,
        theme=theme.label,
        rationale=(
            f"{theme.label} appears in {theme.count} filtered reviews "
            f"({round(theme.share * 100)}%) with risk score {theme.risk_score:.1f} "
            f"and {theme.negative_count} negative reviews.{segment_phrase}"
        ),
        expected_impact=expected_impact(theme=theme, owner=owner),
        next_steps=next_steps_for_theme(theme.label, owner),
        evidence=theme.samples,
        metrics=[
            ActionPlanMetric(label="Filtered share", value=f"{round(theme.share * 100)}%"),
            ActionPlanMetric(label="Risk score", value=f"{theme.risk_score:.1f}"),
            ActionPlanMetric(label="Negative rate", value=f"{round(negative_rate * 100)}%"),
        ],
    )


def priority_for_theme(*, theme: ThemeInsight, filtered_review_count: int) -> str:
    filtered_share = theme.count / filtered_review_count if filtered_review_count else 0
    negative_rate = theme.negative_count / theme.count if theme.count else 0
    if theme.risk_score >= 70 or (theme.negative_count >= 5 and negative_rate >= 0.6):
        return "critical"
    if theme.risk_score >= 45 or (theme.negative_count >= 2 and filtered_share >= 0.2):
        return "high"
    if theme.risk_score >= 20 or theme.negative_count >= 1:
        return "medium"
    return "low"


def owner_for_theme(theme_label: str, audience: str) -> str:
    if audience == "support":
        return "support"
    if "Export" in theme_label:
        return "success"
    if any(token in theme_label for token in ["Login", "Reliability", "Performance", "Checkout"]):
        return "engineering"
    return "product"


def effort_for_theme(theme_label: str) -> str:
    if any(token in theme_label for token in ["Reliability", "Performance", "Checkout"]):
        return "large"
    if any(token in theme_label for token in ["Login", "Export"]):
        return "medium"
    return "small"


def title_for_theme(theme_label: str, owner: str) -> str:
    action_verbs = {
        "engineering": "Investigate and reduce",
        "product": "Prioritize improvements for",
        "support": "Prepare response playbook for",
        "success": "Clarify customer workflow for",
    }
    return f"{action_verbs[owner]} {theme_label.lower()}"


def expected_impact(*, theme: ThemeInsight, owner: str) -> str:
    if owner == "support":
        return "Faster customer response and fewer repeated escalations."
    if owner == "engineering":
        return "Reduced defect-driven negative reviews in the affected workflow."
    if owner == "success":
        return "Lower confusion for customers trying to complete the workflow."
    if theme.positive_count > theme.negative_count:
        return "Preserve a known strength while tightening weaker moments."
    return "Improved review sentiment on a recurring customer driver."


def next_steps_for_theme(theme_label: str, owner: str) -> list[str]:
    if owner == "support":
        return [
            f"Draft macros for the top {theme_label.lower()} complaints.",
            "Tag incoming tickets with the same theme for one week.",
            "Escalate repeated evidence rows to product and engineering.",
        ]
    if owner == "engineering":
        return [
            f"Review recent changes and logs for {theme_label.lower()} incidents.",
            "Reproduce the top customer-reported failure path.",
            "Ship a fix or instrumentation plan with owner and target date.",
        ]
    if owner == "success":
        return [
            "Audit help content and in-product wording for the affected workflow.",
            "Create a short customer-facing troubleshooting note.",
            "Track whether follow-up reviews mention the same confusion.",
        ]
    return [
        f"Validate the {theme_label.lower()} driver with product and support leads.",
        "Size the reachable customer impact using filtered review share.",
        "Add the highest-impact mitigation to the next planning review.",
    ]


def leading_segment_for_theme(
    theme_label: str,
    segment_comparison: SegmentThemeComparisonResponse | None,
) -> str | None:
    if segment_comparison is None:
        return None
    for delta in segment_comparison.deltas:
        if delta.label != theme_label or delta.direction == "similar":
            continue
        if delta.direction == "left_higher":
            return f"{segment_comparison.left.segment} by {segment_comparison.compare_by}"
        return f"{segment_comparison.right.segment} by {segment_comparison.compare_by}"
    return None


def build_segment_drivers(
    segment_comparison: SegmentThemeComparisonResponse | None,
) -> list[str]:
    if segment_comparison is None:
        return []
    return [
        delta.summary
        for delta in segment_comparison.deltas
        if delta.direction != "similar"
    ][:5]


def build_limitations(
    *,
    reviews: list[Review],
    top_themes: list[ThemeInsight],
    theme_limitations: list[str],
    segment_comparison: SegmentThemeComparisonResponse | None,
) -> list[str]:
    limitations = [
        (
            "Action plans are deterministic recommendations from filtered ReviewLens data, "
            "not workflow approvals."
        ),
    ]
    if not reviews:
        limitations.append("No reviews matched the action-plan filters.")
    if len(reviews) < 5:
        limitations.append("Priorities are based on a small filtered sample.")
    if not top_themes:
        limitations.append("No configured theme dictionary matched this review set.")
    if segment_comparison is not None:
        limitations.extend(segment_comparison.limitations)
    limitations.extend(theme_limitations)
    return list(dict.fromkeys(limitations))


def build_markdown(
    *,
    dataset: Dataset,
    generated_at: datetime,
    request: ActionPlanRequest,
    filtered_review_count: int,
    average_rating: float | None,
    negative_review_count: int,
    actions: list[ReviewActionItem],
    segment_drivers: list[str],
    limitations: list[str],
) -> str:
    lines = [
        f"# {dataset.name} Action Plan",
        "",
        f"Generated: {generated_at.isoformat()}",
        f"Audience: {request.audience}",
        f"Filtered reviews: {filtered_review_count}",
        f"Average rating: {average_rating if average_rating is not None else 'N/A'}",
        f"Negative reviews: {negative_review_count}",
        "",
        "## Recommended Actions",
    ]
    if not actions:
        lines.append("- No actions were generated for the current filters.")
    for action in actions:
        lines.extend(
            [
                "",
                f"### {action.action_id}. {action.title}",
                "",
                f"- Priority: {action.priority}",
                f"- Owner: {action.owner}",
                f"- Effort: {action.effort}",
                f"- Theme: {action.theme}",
                f"- Rationale: {action.rationale}",
                f"- Expected impact: {action.expected_impact}",
                "- Next steps:",
            ]
        )
        lines.extend(f"  - {step}" for step in action.next_steps)
        if action.evidence:
            lines.append("- Evidence rows:")
            lines.extend(
                f"  - Row {sample.row_number}: {sample.review_text[:180]}"
                for sample in action.evidence
            )

    if segment_drivers:
        lines.extend(["", "## Segment Drivers"])
        lines.extend(f"- {driver}" for driver in segment_drivers)
    lines.extend(["", "## Limitations"])
    lines.extend(f"- {limitation}" for limitation in limitations)
    return "\n".join(lines).strip() + "\n"
