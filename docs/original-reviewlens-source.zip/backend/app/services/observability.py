import json
from collections import Counter

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dataset import AnswerFeedback, AnswerInteraction
from app.schemas.answers import (
    AnswerFeedbackRequest,
    AnswerFeedbackResponse,
    AnswerFilters,
    AnswerResponse,
    AnswerRunDetail,
    AnswerRunSummary,
    CountBucket,
    ObservabilityMetricsResponse,
)


async def record_answer_interaction(
    session: AsyncSession,
    *,
    response: AnswerResponse,
    mode: str,
    top_k: int,
    filters: AnswerFilters,
    latency_ms: float,
) -> AnswerResponse:
    interaction = AnswerInteraction(
        dataset_id=response.dataset_id,
        question=response.question,
        mode=mode,
        top_k=top_k,
        answer_style=response.answer_style,
        route=response.route,
        filters_json=dump(filters.model_dump(mode="json")),
        answer_text=response.answer,
        confidence=response.confidence,
        confidence_score=response.confidence_score,
        index_status=response.index_status,
        evidence_count=response.evidence_count,
        filtered_review_count=response.filtered_review_count,
        themes_json=dump([theme.model_dump(mode="json") for theme in response.themes]),
        analytics_json=dump(
            [analytic.model_dump(mode="json") for analytic in response.analytics]
        ),
        comparison_json=dump(
            response.comparison.model_dump(mode="json") if response.comparison else None
        ),
        citations_json=dump(
            [citation.model_dump(mode="json") for citation in response.citations]
        ),
        limitations_json=dump(response.limitations),
        generation_model=response.generation_model,
        latency_ms=latency_ms,
        status="completed",
    )
    session.add(interaction)
    await session.commit()
    await session.refresh(interaction)
    return response.model_copy(update={"answer_id": interaction.id})


async def list_answer_runs(
    session: AsyncSession,
    *,
    dataset_id: str,
    limit: int,
) -> list[AnswerRunSummary]:
    result = await session.execute(
        select(AnswerInteraction)
        .where(AnswerInteraction.dataset_id == dataset_id)
        .order_by(AnswerInteraction.created_at.desc())
        .limit(limit)
    )
    interactions = list(result.scalars().all())
    feedback_by_answer = await latest_feedback_by_answer(
        session,
        [item.id for item in interactions],
    )
    return [
        AnswerRunSummary(
            answer_id=interaction.id,
            dataset_id=interaction.dataset_id,
            question=interaction.question,
            answer_style=interaction.answer_style,
            confidence=interaction.confidence,
            confidence_score=interaction.confidence_score,
            index_status=interaction.index_status,
            evidence_count=interaction.evidence_count,
            feedback_rating=feedback_by_answer.get(interaction.id),
            created_at=interaction.created_at,
        )
        for interaction in interactions
    ]


async def get_answer_run_detail(
    session: AsyncSession,
    *,
    dataset_id: str,
    answer_id: str,
) -> AnswerRunDetail | None:
    interaction = await get_dataset_answer(session, dataset_id=dataset_id, answer_id=answer_id)
    if interaction is None:
        return None
    feedback = await latest_feedback(session, answer_id=answer_id)
    return interaction_to_detail(interaction, feedback)


async def submit_answer_feedback(
    session: AsyncSession,
    *,
    dataset_id: str,
    answer_id: str,
    request: AnswerFeedbackRequest,
) -> AnswerFeedbackResponse | None:
    interaction = await get_dataset_answer(session, dataset_id=dataset_id, answer_id=answer_id)
    if interaction is None:
        return None

    feedback = AnswerFeedback(
        dataset_id=dataset_id,
        answer_id=answer_id,
        rating=request.rating,
        notes=request.notes,
    )
    session.add(feedback)
    await session.commit()
    await session.refresh(feedback)
    return AnswerFeedbackResponse(
        feedback_id=feedback.id,
        answer_id=answer_id,
        dataset_id=dataset_id,
        rating=feedback.rating,
        notes=feedback.notes,
    )


async def build_observability_metrics(
    session: AsyncSession,
    *,
    dataset_id: str,
) -> ObservabilityMetricsResponse:
    result = await session.execute(
        select(AnswerInteraction)
        .where(AnswerInteraction.dataset_id == dataset_id)
        .order_by(AnswerInteraction.created_at.desc())
    )
    interactions = list(result.scalars().all())
    feedback_result = await session.execute(
        select(AnswerFeedback).where(AnswerFeedback.dataset_id == dataset_id)
    )
    feedback = list(feedback_result.scalars().all())

    if not interactions:
        return ObservabilityMetricsResponse(
            dataset_id=dataset_id,
            answer_count=0,
            average_confidence_score=None,
            average_latency_ms=None,
            average_evidence_count=None,
            no_evidence_rate=0,
            partial_index_rate=0,
            confidence_distribution=[],
            feedback_distribution=[],
            top_themes=[],
            top_limitations=[],
        )

    answer_count = len(interactions)
    no_evidence = sum(1 for item in interactions if item.evidence_count == 0)
    partial_index = sum(
        1 for item in interactions if item.index_status not in {"ready", "not_required"}
    )
    confidence_counter = Counter(item.confidence for item in interactions)
    feedback_counter = Counter(item.rating for item in feedback)
    theme_counter: Counter[str] = Counter()
    limitation_counter: Counter[str] = Counter()

    for interaction in interactions:
        for theme in json.loads(interaction.themes_json):
            theme_counter[theme["label"]] += int(theme["count"])
        limitation_counter.update(json.loads(interaction.limitations_json))

    return ObservabilityMetricsResponse(
        dataset_id=dataset_id,
        answer_count=answer_count,
        average_confidence_score=round(
            sum(item.confidence_score for item in interactions) / answer_count,
            2,
        ),
        average_latency_ms=round(sum(item.latency_ms for item in interactions) / answer_count, 2),
        average_evidence_count=round(
            sum(item.evidence_count for item in interactions) / answer_count,
            2,
        ),
        no_evidence_rate=round(no_evidence / answer_count, 4),
        partial_index_rate=round(partial_index / answer_count, 4),
        confidence_distribution=to_buckets(confidence_counter),
        feedback_distribution=to_buckets(feedback_counter),
        top_themes=to_buckets(theme_counter, limit=5),
        top_limitations=to_buckets(limitation_counter, limit=5),
    )


async def get_dataset_answer(
    session: AsyncSession,
    *,
    dataset_id: str,
    answer_id: str,
) -> AnswerInteraction | None:
    return await session.scalar(
        select(AnswerInteraction).where(
            AnswerInteraction.id == answer_id,
            AnswerInteraction.dataset_id == dataset_id,
        )
    )


async def latest_feedback(
    session: AsyncSession,
    *,
    answer_id: str,
) -> AnswerFeedback | None:
    return await session.scalar(
        select(AnswerFeedback)
        .where(AnswerFeedback.answer_id == answer_id)
        .order_by(AnswerFeedback.created_at.desc())
        .limit(1)
    )


async def latest_feedback_by_answer(
    session: AsyncSession,
    answer_ids: list[str],
) -> dict[str, str]:
    if not answer_ids:
        return {}
    result = await session.execute(
        select(AnswerFeedback)
        .where(AnswerFeedback.answer_id.in_(answer_ids))
        .order_by(AnswerFeedback.created_at.asc())
    )
    feedback_by_answer: dict[str, str] = {}
    for feedback in result.scalars().all():
        feedback_by_answer[feedback.answer_id] = feedback.rating
    return feedback_by_answer


def interaction_to_detail(
    interaction: AnswerInteraction,
    feedback: AnswerFeedback | None,
) -> AnswerRunDetail:
    return AnswerRunDetail(
        answer_id=interaction.id,
        dataset_id=interaction.dataset_id,
        question=interaction.question,
        mode=interaction.mode,
        top_k=interaction.top_k,
        answer_style=interaction.answer_style,
        route=interaction.route,
        filters=AnswerFilters.model_validate(json.loads(interaction.filters_json)),
        answer=interaction.answer_text,
        confidence=interaction.confidence,
        confidence_score=interaction.confidence_score,
        index_status=interaction.index_status,
        evidence_count=interaction.evidence_count,
        filtered_review_count=interaction.filtered_review_count,
        themes=json.loads(interaction.themes_json),
        analytics=json.loads(interaction.analytics_json),
        comparison=json.loads(interaction.comparison_json),
        citations=json.loads(interaction.citations_json),
        limitations=json.loads(interaction.limitations_json),
        generation_model=interaction.generation_model,
        latency_ms=interaction.latency_ms,
        feedback_rating=feedback.rating if feedback else None,
        feedback_notes=feedback.notes if feedback else None,
        created_at=interaction.created_at,
    )


def to_buckets(counter: Counter[str], limit: int | None = None) -> list[CountBucket]:
    items = counter.most_common(limit)
    return [CountBucket(label=label, count=count) for label, count in items]


def dump(value: object) -> str:
    return json.dumps(value, separators=(",", ":"), sort_keys=True)
