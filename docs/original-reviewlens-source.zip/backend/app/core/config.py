from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "ReviewLens API"
    app_version: str = "0.1.0"
    app_env: str = Field(default="local", validation_alias="APP_ENV")
    log_level: str = Field(default="INFO", validation_alias="LOG_LEVEL")
    database_url: str = Field(
        default="postgresql+asyncpg://reviewlens:reviewlens@localhost:5432/reviewlens",
        validation_alias="DATABASE_URL",
    )
    backend_cors_origins: str = Field(
        default="http://localhost:5173,http://127.0.0.1:5173",
        validation_alias="BACKEND_CORS_ORIGINS",
    )
    auto_create_tables: bool = Field(default=True, validation_alias="AUTO_CREATE_TABLES")
    embedding_provider: str = Field(default="local", validation_alias="EMBEDDING_PROVIDER")
    embedding_model: str = Field(
        default="reviewlens-local-hash-v1",
        validation_alias="EMBEDDING_MODEL",
    )
    embedding_dimensions: int = Field(default=64, validation_alias="EMBEDDING_DIMENSIONS")
    embedding_batch_size: int = Field(default=64, validation_alias="EMBEDDING_BATCH_SIZE")
    answer_provider: str = Field(default="local", validation_alias="ANSWER_PROVIDER")
    answer_model: str = Field(
        default="reviewlens-local-template-v1",
        validation_alias="ANSWER_MODEL",
    )
    openai_api_key: str | None = Field(default=None, validation_alias="OPENAI_API_KEY")
    openai_embedding_model: str = Field(
        default="text-embedding-3-small",
        validation_alias="OPENAI_EMBEDDING_MODEL",
    )
    openai_answer_model: str = Field(
        default="gpt-4.1-mini",
        validation_alias="OPENAI_ANSWER_MODEL",
    )
    openai_request_timeout_seconds: float = Field(
        default=45.0,
        validation_alias="OPENAI_REQUEST_TIMEOUT_SECONDS",
    )
    retrieval_auto_index: bool = Field(default=True, validation_alias="RETRIEVAL_AUTO_INDEX")
    openai_base_url: str | None = Field(default=None, validation_alias="OPENAI_BASE_URL")
    embedding_cost_per_1k_tokens_usd: float = Field(
        default=0.0,
        validation_alias="EMBEDDING_COST_PER_1K_TOKENS_USD",
    )
    answer_input_cost_per_1k_tokens_usd: float = Field(
        default=0.0,
        validation_alias="ANSWER_INPUT_COST_PER_1K_TOKENS_USD",
    )
    answer_output_cost_per_1k_tokens_usd: float = Field(
        default=0.0,
        validation_alias="ANSWER_OUTPUT_COST_PER_1K_TOKENS_USD",
    )

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.backend_cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
