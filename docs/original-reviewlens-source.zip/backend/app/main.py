from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import (
    actions,
    answers,
    datasets,
    evaluations,
    health,
    observability,
    productization,
    reports,
    retrieval,
    themes,
)
from app.core.config import get_settings
from app.core.logging import configure_logging, get_logger
from app.db.session import create_database_schema


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    configure_logging(settings.log_level)
    logger = get_logger(__name__)
    logger.info("service_starting", service=settings.app_name, environment=settings.app_env)
    if settings.auto_create_tables:
        await create_database_schema()
    yield
    logger.info("service_stopping", service=settings.app_name)


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="Backend API for ReviewLens customer-review intelligence.",
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(actions.router, prefix="/api")
    app.include_router(answers.router, prefix="/api")
    app.include_router(datasets.router, prefix="/api")
    app.include_router(evaluations.router, prefix="/api")
    app.include_router(observability.router, prefix="/api")
    app.include_router(productization.router, prefix="/api")
    app.include_router(reports.router, prefix="/api")
    app.include_router(retrieval.router, prefix="/api")
    app.include_router(themes.router, prefix="/api")
    app.include_router(health.router, prefix="/api", tags=["health"])
    return app


app = create_app()
