from datetime import date
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.routes.datasets import apply_review_filters
from app.db.session import get_db_session
from app.models.dataset import Dataset, Review
from app.schemas.retrieval import (
    RetrievalIndexResponse,
    RetrievalSearchResponse,
    RetrievalStatusResponse,
)
from app.services.retrieval import (
    EmbeddingProviderError,
    ProviderConfigurationError,
    index_reviews,
    retrieval_status_for_dataset,
    search_reviews,
)

router = APIRouter(prefix="/datasets/{dataset_id}/retrieval", tags=["retrieval"])


@router.post("/index", response_model=RetrievalIndexResponse)
async def index_dataset_reviews(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> RetrievalIndexResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    result = await session.execute(
        select(Review)
        .where(Review.dataset_id == dataset_id, Review.is_deleted.is_(False))
        .order_by(Review.row_number.asc())
    )
    reviews = list(result.scalars().all())
    try:
        return await index_reviews(session, dataset_id=dataset_id, reviews=reviews)
    except (EmbeddingProviderError, ProviderConfigurationError) as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc


@router.get("/status", response_model=RetrievalStatusResponse)
async def get_retrieval_status(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> RetrievalStatusResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    try:
        return await retrieval_status_for_dataset(session, dataset_id=dataset_id)
    except (EmbeddingProviderError, ProviderConfigurationError) as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc


@router.get("/search", response_model=RetrievalSearchResponse)
async def search_dataset_reviews(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    q: Annotated[str, Query(min_length=1)],
    mode: Literal["keyword", "semantic", "hybrid"] = "hybrid",
    top_k: Annotated[int, Query(ge=1, le=50)] = 10,
    rating_min: Annotated[float | None, Query(ge=0, le=5)] = None,
    rating_max: Annotated[float | None, Query(ge=0, le=5)] = None,
    date_from: date | None = None,
    date_to: date | None = None,
    product_name: str | None = None,
    product_version: str | None = None,
    source: str | None = None,
    region: str | None = None,
    country: str | None = None,
    language: str | None = None,
    customer_segment: str | None = None,
    platform: str | None = None,
    channel: str | None = None,
    verified_purchase: bool | None = None,
) -> RetrievalSearchResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    query = apply_review_filters(
        select(Review).where(Review.dataset_id == dataset_id, Review.is_deleted.is_(False)),
        rating_min=rating_min,
        rating_max=rating_max,
        date_from=date_from,
        date_to=date_to,
        product_name=product_name,
        product_version=product_version,
        source=source,
        region=region,
        country=country,
        language=language,
        customer_segment=customer_segment,
        platform=platform,
        channel=channel,
        verified_purchase=verified_purchase,
        q=None,
    )
    result = await session.execute(query.order_by(Review.row_number.asc()))
    reviews = list(result.scalars().all())
    try:
        index_status, results = await search_reviews(
            session,
            dataset_id=dataset_id,
            query=q,
            reviews=reviews,
            mode=mode,
            top_k=top_k,
        )
    except ProviderConfigurationError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    return RetrievalSearchResponse(
        dataset_id=dataset_id,
        query=q,
        mode=mode,
        top_k=top_k,
        index_status=index_status,
        results=results,
    )
