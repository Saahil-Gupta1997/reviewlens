from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db_session
from app.models.dataset import Dataset
from app.schemas.answers import ObservabilityMetricsResponse
from app.services.observability import build_observability_metrics

router = APIRouter(prefix="/datasets/{dataset_id}/observability", tags=["observability"])


@router.get("/metrics", response_model=ObservabilityMetricsResponse)
async def get_dataset_observability_metrics(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> ObservabilityMetricsResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")
    return await build_observability_metrics(session, dataset_id=dataset_id)
