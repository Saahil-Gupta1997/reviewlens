from fastapi import APIRouter

from app.core.config import get_settings
from app.schemas.productization import (
    CostConfiguration,
    ModelConfiguration,
    ReleaseReadinessResponse,
)
from app.services.ingestion import MAX_REVIEW_TEXT_LENGTH, MAX_ROWS_PER_UPLOAD

router = APIRouter(prefix="/productization", tags=["productization"])

MAX_UPLOAD_MB = 10


@router.get("/release-readiness", response_model=ReleaseReadinessResponse)
async def get_release_readiness() -> ReleaseReadinessResponse:
    settings = get_settings()
    answer_model = (
        settings.openai_answer_model
        if settings.answer_provider.lower() == "openai"
        else settings.answer_model
    )
    embedding_model = (
        settings.openai_embedding_model
        if settings.embedding_provider.lower() == "openai"
        else settings.embedding_model
    )

    return ReleaseReadinessResponse(
        app_name=settings.app_name,
        app_version=settings.app_version,
        environment=settings.app_env,
        model_configuration=ModelConfiguration(
            embedding_provider=settings.embedding_provider,
            embedding_model=embedding_model,
            embedding_dimensions=settings.embedding_dimensions,
            answer_provider=settings.answer_provider,
            answer_model=answer_model,
            retrieval_auto_index=settings.retrieval_auto_index,
            openai_configured=bool(settings.openai_api_key),
        ),
        cost_configuration=CostConfiguration(
            tracking_basis="Configured model rates plus stored answer latency/model records.",
            embedding_cost_per_1k_tokens_usd=settings.embedding_cost_per_1k_tokens_usd,
            answer_input_cost_per_1k_tokens_usd=settings.answer_input_cost_per_1k_tokens_usd,
            answer_output_cost_per_1k_tokens_usd=settings.answer_output_cost_per_1k_tokens_usd,
            notes=[
                "Local providers have zero external API cost.",
                "Set cost-rate environment variables when using paid providers.",
                "Answer history stores model name, confidence, evidence count, and latency.",
            ],
        ),
        privacy=[
            "Uploaded reviews are stored in the configured backend database.",
            (
                "Dataset deletion removes reviews, embeddings, themes, answers, "
                "feedback, and import errors."
            ),
            (
                "OpenAI API keys are read only from backend environment variables "
                "and are never returned."
            ),
        ],
        security=[
            "CORS is restricted through BACKEND_CORS_ORIGINS.",
            "Review text is treated as untrusted data in RAG prompts.",
            "Uploads are bounded by file size, row count, and per-review text length.",
        ],
        limits=[
            f"Maximum upload size is {MAX_UPLOAD_MB} MB.",
            f"Maximum rows per upload is {MAX_ROWS_PER_UPLOAD}.",
            f"Maximum review text length is {MAX_REVIEW_TEXT_LENGTH} characters.",
        ],
        limitations=[
            (
                "Local embeddings are deterministic and intended for demos/tests, "
                "not production recall."
            ),
            (
                "LLM quality depends on retrieved review evidence and configured "
                "provider availability."
            ),
            (
                "Cost tracking uses configured rates; verify current vendor pricing "
                "before portfolio demos."
            ),
            (
                "Evaluation is a golden synthetic benchmark, not a substitute for "
                "production monitoring."
            ),
        ],
        release_checklist=[
            "Run backend lint and tests.",
            "Run frontend lint, tests, and production build.",
            "Load sample_data/reviewlens_demo_reviews.csv.",
            "Ask a RAG question, inspect citations, run a comparison, and run evaluation.",
            "Confirm OPENAI_API_KEY is not committed or exposed in browser responses.",
        ],
    )
