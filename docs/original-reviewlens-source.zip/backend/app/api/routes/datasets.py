import json
from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from sqlalchemy import Select, delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db_session
from app.models.dataset import (
    AnswerFeedback,
    AnswerInteraction,
    Dataset,
    DatasetTheme,
    IngestionJob,
    Review,
    ReviewEmbedding,
    ReviewImportError,
    ReviewThemeAssignment,
)
from app.schemas.exploration import (
    DatasetExploreResponse,
    ExploreMetrics,
    FilterOptions,
    RatingBucket,
    ReviewListItem,
    TrendPoint,
)
from app.schemas.ingestion import DatasetListItem, DatasetSummary, FieldMapping
from app.services.ingestion import IngestionError, ingest_dataset

MAX_UPLOAD_BYTES = 10 * 1024 * 1024

router = APIRouter(prefix="/datasets", tags=["datasets"])


@router.post("", response_model=DatasetSummary, status_code=status.HTTP_201_CREATED)
async def upload_dataset(
    file: Annotated[UploadFile, File()],
    session: Annotated[AsyncSession, Depends(get_db_session)],
    dataset_name: Annotated[str | None, Form()] = None,
    field_mapping: Annotated[str | None, Form()] = None,
) -> DatasetSummary:
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=400,
            detail="Uploaded file is too large; maximum allowed size is 10 MB.",
        )

    try:
        return await ingest_dataset(
            session,
            filename=file.filename or "reviews",
            content=content,
            dataset_name=dataset_name,
            mapping=parse_field_mapping(field_mapping),
        )
    except IngestionError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("", response_model=list[DatasetListItem])
async def list_datasets(
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> list[DatasetListItem]:
    result = await session.execute(select(Dataset).order_by(Dataset.created_at.desc()))
    return [dataset_to_list_item(dataset) for dataset in result.scalars().all()]


@router.get("/{dataset_id}", response_model=DatasetListItem)
async def get_dataset(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> DatasetListItem:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")
    return dataset_to_list_item(dataset)


@router.delete("/{dataset_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_dataset(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> None:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    for model in (
        ReviewThemeAssignment,
        DatasetTheme,
        ReviewEmbedding,
        AnswerFeedback,
        AnswerInteraction,
        ReviewImportError,
        IngestionJob,
        Review,
    ):
        await session.execute(delete(model).where(model.dataset_id == dataset_id))
    await session.delete(dataset)
    await session.commit()


@router.get("/{dataset_id}/explore", response_model=DatasetExploreResponse)
async def explore_dataset(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    rating_min: Annotated[float | None, Query(ge=0, le=5)] = None,
    rating_max: Annotated[float | None, Query(ge=0, le=5)] = None,
    date_from: date | None = None,
    date_to: date | None = None,
    product_name: str | None = None,
    product_version: str | None = None,
    source: str | None = None,
    region: str | None = None,
    country: str | None = None,
    language: str | None = None,
    customer_segment: str | None = None,
    platform: str | None = None,
    channel: str | None = None,
    verified_purchase: bool | None = None,
    q: str | None = None,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    offset: Annotated[int, Query(ge=0)] = 0,
) -> DatasetExploreResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    base_query = select(Review).where(Review.dataset_id == dataset_id, Review.is_deleted.is_(False))
    filtered_query = apply_review_filters(
        base_query,
        rating_min=rating_min,
        rating_max=rating_max,
        date_from=date_from,
        date_to=date_to,
        product_name=product_name,
        product_version=product_version,
        source=source,
        region=region,
        country=country,
        language=language,
        customer_segment=customer_segment,
        platform=platform,
        channel=channel,
        verified_purchase=verified_purchase,
        q=q,
    )

    total_reviews = await count_reviews(session, base_query)
    filtered_reviews = await count_reviews(session, filtered_query)
    average_rating, rated_reviews = await rating_summary(session, filtered_query)
    rating_distribution = await build_rating_distribution(session, filtered_query)
    volume_trend = await build_volume_trend(session, filtered_query)
    reviews = await fetch_review_page(session, filtered_query, limit=limit, offset=offset)
    filter_options = await build_filter_options(session, dataset_id)

    return DatasetExploreResponse(
        dataset_id=dataset_id,
        metrics=ExploreMetrics(
            total_reviews=total_reviews,
            filtered_reviews=filtered_reviews,
            average_rating=average_rating,
            rated_reviews=rated_reviews,
        ),
        rating_distribution=rating_distribution,
        volume_trend=volume_trend,
        filter_options=filter_options,
        reviews=reviews,
        limit=limit,
        offset=offset,
    )


def parse_field_mapping(raw_mapping: str | None) -> FieldMapping:
    if not raw_mapping:
        return FieldMapping()
    try:
        payload = json.loads(raw_mapping)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="field_mapping must be valid JSON.") from exc
    return FieldMapping.model_validate(payload)


def dataset_to_list_item(dataset: Dataset) -> DatasetListItem:
    return DatasetListItem(
        dataset_id=dataset.id,
        name=dataset.name,
        filename=dataset.source_filename,
        status=dataset.status,
        total_rows=dataset.total_rows,
        accepted_rows=dataset.accepted_rows,
        rejected_rows=dataset.rejected_rows,
        duplicate_rows=dataset.duplicate_rows,
    )


def apply_review_filters(
    query: Select[tuple[Review]],
    *,
    rating_min: float | None,
    rating_max: float | None,
    date_from: date | None,
    date_to: date | None,
    product_name: str | None,
    product_version: str | None,
    source: str | None,
    region: str | None,
    country: str | None,
    language: str | None,
    customer_segment: str | None,
    platform: str | None,
    channel: str | None,
    verified_purchase: bool | None,
    q: str | None,
) -> Select[tuple[Review]]:
    if rating_min is not None:
        query = query.where(Review.rating >= rating_min)
    if rating_max is not None:
        query = query.where(Review.rating <= rating_max)
    if date_from is not None:
        query = query.where(Review.review_date >= date_from)
    if date_to is not None:
        query = query.where(Review.review_date <= date_to)

    exact_filters = {
        Review.product_name: product_name,
        Review.product_version: product_version,
        Review.source: source,
        Review.region: region,
        Review.country: country,
        Review.language: language,
        Review.customer_segment: customer_segment,
        Review.platform: platform,
        Review.channel: channel,
    }
    for column, value in exact_filters.items():
        if value:
            query = query.where(column == value)

    if verified_purchase is not None:
        query = query.where(Review.verified_purchase.is_(verified_purchase))

    if q:
        normalized_q = " ".join(q.lower().split())
        query = query.where(Review.normalized_text.contains(normalized_q))

    return query


async def count_reviews(session: AsyncSession, query: Select[tuple[Review]]) -> int:
    count_query = select(func.count()).select_from(query.subquery())
    return int(await session.scalar(count_query) or 0)


async def rating_summary(
    session: AsyncSession, query: Select[tuple[Review]]
) -> tuple[float | None, int]:
    subquery = query.where(Review.rating.is_not(None)).subquery()
    result = await session.execute(
        select(func.avg(subquery.c.rating), func.count()).select_from(subquery)
    )
    average, count = result.one()
    return (round(float(average), 2) if average is not None else None, int(count or 0))


async def build_rating_distribution(
    session: AsyncSession, query: Select[tuple[Review]]
) -> list[RatingBucket]:
    subquery = query.subquery()
    result = await session.execute(
        select(subquery.c.rating, func.count())
        .group_by(subquery.c.rating)
        .order_by(subquery.c.rating.asc())
    )
    counts = {rating: int(count) for rating, count in result.all()}
    buckets: list[RatingBucket] = []
    for rating in range(0, 6):
        total = sum(
            count for value, count in counts.items() if value is not None and int(value) == rating
        )
        buckets.append(RatingBucket(rating=str(rating), count=total))
    unrated = int(counts.get(None, 0))
    if unrated:
        buckets.append(RatingBucket(rating="unrated", count=unrated))
    return buckets


async def build_volume_trend(
    session: AsyncSession, query: Select[tuple[Review]]
) -> list[TrendPoint]:
    subquery = query.where(Review.review_date.is_not(None)).subquery()
    result = await session.execute(
        select(subquery.c.review_date, func.count())
        .group_by(subquery.c.review_date)
        .order_by(subquery.c.review_date.asc())
        .limit(30)
    )
    return [TrendPoint(date=review_date, count=int(count)) for review_date, count in result.all()]


async def fetch_review_page(
    session: AsyncSession,
    query: Select[tuple[Review]],
    *,
    limit: int,
    offset: int,
) -> list[ReviewListItem]:
    result = await session.execute(
        query.order_by(Review.review_date.desc().nullslast(), Review.row_number.asc())
        .limit(limit)
        .offset(offset)
    )
    return [review_to_list_item(review) for review in result.scalars().all()]


async def build_filter_options(session: AsyncSession, dataset_id: str) -> FilterOptions:
    async def distinct_values(column) -> list[str]:
        result = await session.execute(
            select(column)
            .where(
                Review.dataset_id == dataset_id,
                Review.is_deleted.is_(False),
                column.is_not(None),
            )
            .distinct()
            .order_by(column.asc())
        )
        return [str(value) for value in result.scalars().all() if value]

    return FilterOptions(
        product_names=await distinct_values(Review.product_name),
        product_versions=await distinct_values(Review.product_version),
        sources=await distinct_values(Review.source),
        regions=await distinct_values(Review.region),
        countries=await distinct_values(Review.country),
        customer_segments=await distinct_values(Review.customer_segment),
        platforms=await distinct_values(Review.platform),
        channels=await distinct_values(Review.channel),
    )


def review_to_list_item(review: Review) -> ReviewListItem:
    return ReviewListItem(
        id=review.id,
        external_review_id=review.external_review_id,
        review_text=review.review_text,
        review_title=review.review_title,
        rating=review.rating,
        review_date=review.review_date,
        source=review.source,
        product_name=review.product_name,
        product_version=review.product_version,
        region=review.region,
        country=review.country,
        customer_segment=review.customer_segment,
        platform=review.platform,
        channel=review.channel,
        verified_purchase=review.verified_purchase,
        row_number=review.row_number,
    )
