from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db_session
from app.models.dataset import Dataset
from app.schemas.reports import InsightReportRequest, InsightReportResponse
from app.services.reports import build_insight_report

router = APIRouter(prefix="/datasets/{dataset_id}/reports", tags=["reports"])


@router.post("/insight-brief", response_model=InsightReportResponse)
async def create_dataset_insight_brief(
    dataset_id: str,
    request: InsightReportRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> InsightReportResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    return await build_insight_report(session, dataset=dataset, request=request)
