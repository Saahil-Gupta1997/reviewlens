from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db_session
from app.models.dataset import Dataset
from app.schemas.actions import ActionPlanRequest, ActionPlanResponse
from app.services.actions import build_action_plan

router = APIRouter(prefix="/datasets/{dataset_id}/actions", tags=["actions"])


@router.post("/plan", response_model=ActionPlanResponse)
async def create_dataset_action_plan(
    dataset_id: str,
    request: ActionPlanRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> ActionPlanResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    return await build_action_plan(session, dataset=dataset, request=request)
