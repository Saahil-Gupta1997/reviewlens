from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.routes.datasets import apply_review_filters, count_reviews
from app.db.session import get_db_session
from app.models.dataset import Dataset, Review
from app.schemas.themes import (
    DatasetThemesResponse,
    SegmentThemeComparisonResponse,
    ThemeCompareRequest,
)
from app.services.theme_discovery import ensure_theme_assignments
from app.services.themes import analyze_review_themes, compare_theme_segments, comparison_window

router = APIRouter(prefix="/datasets/{dataset_id}/themes", tags=["themes"])


@router.get("", response_model=DatasetThemesResponse)
async def get_dataset_themes(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    rating_min: Annotated[float | None, Query(ge=0, le=5)] = None,
    rating_max: Annotated[float | None, Query(ge=0, le=5)] = None,
    date_from: date | None = None,
    date_to: date | None = None,
    product_name: str | None = None,
    product_version: str | None = None,
    source: str | None = None,
    region: str | None = None,
    country: str | None = None,
    language: str | None = None,
    customer_segment: str | None = None,
    platform: str | None = None,
    channel: str | None = None,
    verified_purchase: bool | None = None,
    q: str | None = None,
) -> DatasetThemesResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    base_query = select(Review).where(Review.dataset_id == dataset_id, Review.is_deleted.is_(False))
    filtered_query = apply_review_filters(
        base_query,
        rating_min=rating_min,
        rating_max=rating_max,
        date_from=date_from,
        date_to=date_to,
        product_name=product_name,
        product_version=product_version,
        source=source,
        region=region,
        country=country,
        language=language,
        customer_segment=customer_segment,
        platform=platform,
        channel=channel,
        verified_purchase=verified_purchase,
        q=q,
    )
    total_reviews = await count_reviews(session, base_query)
    result = await session.execute(filtered_query.order_by(Review.row_number.asc()))
    reviews = list(result.scalars().all())
    await ensure_theme_assignments(session, dataset_id=dataset_id, reviews=reviews)

    previous_reviews = None
    previous_start = None
    previous_end = None
    window = comparison_window(date_from, date_to)
    if window:
        previous_start, previous_end = window
        previous_query = apply_review_filters(
            base_query,
            rating_min=rating_min,
            rating_max=rating_max,
            date_from=previous_start,
            date_to=previous_end,
            product_name=product_name,
            product_version=product_version,
            source=source,
            region=region,
            country=country,
            language=language,
            customer_segment=customer_segment,
            platform=platform,
            channel=channel,
            verified_purchase=verified_purchase,
            q=q,
        )
        previous_result = await session.execute(previous_query.order_by(Review.row_number.asc()))
        previous_reviews = list(previous_result.scalars().all())

    return analyze_review_themes(
        dataset_id=dataset_id,
        reviews=reviews,
        total_reviews=total_reviews,
        comparison_reviews=previous_reviews,
        current_start=date_from,
        current_end=date_to,
        previous_start=previous_start,
        previous_end=previous_end,
    )


@router.post("/compare", response_model=SegmentThemeComparisonResponse)
async def compare_dataset_theme_segments(
    dataset_id: str,
    request: ThemeCompareRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> SegmentThemeComparisonResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    filters = request.filters
    query = apply_review_filters(
        select(Review).where(Review.dataset_id == dataset_id, Review.is_deleted.is_(False)),
        rating_min=filters.rating_min,
        rating_max=filters.rating_max,
        date_from=filters.date_from,
        date_to=filters.date_to,
        product_name=filters.product_name,
        product_version=filters.product_version,
        source=filters.source,
        region=filters.region,
        country=filters.country,
        language=filters.language,
        customer_segment=filters.customer_segment,
        platform=filters.platform,
        channel=filters.channel,
        verified_purchase=filters.verified_purchase,
        q=filters.q,
    )
    result = await session.execute(query.order_by(Review.row_number.asc()))
    reviews = list(result.scalars().all())
    await ensure_theme_assignments(session, dataset_id=dataset_id, reviews=reviews)

    return compare_theme_segments(
        dataset_id=dataset_id,
        compare_by=request.compare_by,
        left_value=request.left_value,
        right_value=request.right_value,
        reviews=reviews,
        limit=request.limit,
        min_count=request.min_count,
    )
