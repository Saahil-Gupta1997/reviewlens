from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db_session
from app.schemas.evaluations import EvaluationRunResponse
from app.services.evaluations import run_golden_evaluation

router = APIRouter(prefix="/evaluations", tags=["evaluations"])


@router.post("/run", response_model=EvaluationRunResponse)
async def run_evaluation(
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> EvaluationRunResponse:
    return await run_golden_evaluation(session)
