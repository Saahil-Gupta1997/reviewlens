from time import perf_counter
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.routes.datasets import apply_review_filters
from app.db.session import get_db_session
from app.models.dataset import Dataset, Review
from app.schemas.answers import (
    AnswerFeedbackRequest,
    AnswerFeedbackResponse,
    AnswerRequest,
    AnswerResponse,
    AnswerRunDetail,
    AnswerRunSummary,
)
from app.services.answers import AnswerProviderError, generate_grounded_answer
from app.services.observability import (
    get_answer_run_detail,
    list_answer_runs,
    record_answer_interaction,
    submit_answer_feedback,
)
from app.services.retrieval import EmbeddingProviderError, ProviderConfigurationError

router = APIRouter(prefix="/datasets/{dataset_id}/answers", tags=["answers"])


@router.post("", response_model=AnswerResponse)
async def answer_dataset_question(
    dataset_id: str,
    request: AnswerRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> AnswerResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")

    filters = request.filters
    query = apply_review_filters(
        select(Review).where(Review.dataset_id == dataset_id, Review.is_deleted.is_(False)),
        rating_min=filters.rating_min,
        rating_max=filters.rating_max,
        date_from=filters.date_from,
        date_to=filters.date_to,
        product_name=filters.product_name,
        product_version=filters.product_version,
        source=filters.source,
        region=filters.region,
        country=filters.country,
        language=filters.language,
        customer_segment=filters.customer_segment,
        platform=filters.platform,
        channel=filters.channel,
        verified_purchase=filters.verified_purchase,
        q=None,
    )
    result = await session.execute(query.order_by(Review.row_number.asc()))
    reviews = list(result.scalars().all())

    started_at = perf_counter()
    try:
        answer = await generate_grounded_answer(
            session,
            dataset_id=dataset_id,
            question=request.question,
            reviews=reviews,
            mode=request.mode,
            top_k=request.top_k,
            answer_style=request.answer_style,
        )
    except (EmbeddingProviderError, ProviderConfigurationError, AnswerProviderError) as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    latency_ms = (perf_counter() - started_at) * 1000
    return await record_answer_interaction(
        session,
        response=answer,
        mode=request.mode,
        top_k=request.top_k,
        filters=request.filters,
        latency_ms=latency_ms,
    )


@router.get("", response_model=list[AnswerRunSummary])
async def list_dataset_answers(
    dataset_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
    limit: Annotated[int, Query(ge=1, le=25)] = 10,
) -> list[AnswerRunSummary]:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")
    return await list_answer_runs(session, dataset_id=dataset_id, limit=limit)


@router.get("/{answer_id}", response_model=AnswerRunDetail)
async def get_dataset_answer(
    dataset_id: str,
    answer_id: str,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> AnswerRunDetail:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")
    detail = await get_answer_run_detail(session, dataset_id=dataset_id, answer_id=answer_id)
    if detail is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Answer not found.")
    return detail


@router.post("/{answer_id}/feedback", response_model=AnswerFeedbackResponse)
async def create_answer_feedback(
    dataset_id: str,
    answer_id: str,
    request: AnswerFeedbackRequest,
    session: Annotated[AsyncSession, Depends(get_db_session)],
) -> AnswerFeedbackResponse:
    dataset = await session.get(Dataset, dataset_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found.")
    feedback = await submit_answer_feedback(
        session,
        dataset_id=dataset_id,
        answer_id=answer_id,
        request=request,
    )
    if feedback is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Answer not found.")
    return feedback
