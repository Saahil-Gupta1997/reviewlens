from datetime import datetime

from pydantic import BaseModel, Field

from app.schemas.answers import AnswerRunDetail, ObservabilityMetricsResponse
from app.schemas.exploration import ExploreMetrics, RatingBucket, TrendPoint
from app.schemas.retrieval import RetrievalStatusResponse
from app.schemas.themes import (
    SegmentThemeComparisonResponse,
    ThemeCompareDimension,
    ThemeCompareFilters,
    ThemeInsight,
)


class ReportSegmentComparisonRequest(BaseModel):
    compare_by: ThemeCompareDimension
    left_value: str = Field(min_length=1, max_length=120)
    right_value: str = Field(min_length=1, max_length=120)
    limit: int = Field(default=5, ge=1, le=25)
    min_count: int = Field(default=1, ge=1, le=100)


class InsightReportRequest(BaseModel):
    title: str | None = Field(default=None, max_length=160)
    filters: ThemeCompareFilters = Field(default_factory=ThemeCompareFilters)
    theme_limit: int = Field(default=5, ge=1, le=10)
    recent_answers_limit: int = Field(default=5, ge=0, le=10)
    segment_comparison: ReportSegmentComparisonRequest | None = None


class InsightReportSection(BaseModel):
    title: str
    summary: str
    bullets: list[str]


class InsightReportResponse(BaseModel):
    dataset_id: str
    title: str
    generated_at: datetime
    filters: ThemeCompareFilters
    metrics: ExploreMetrics
    rating_distribution: list[RatingBucket]
    volume_trend: list[TrendPoint]
    retrieval_status: RetrievalStatusResponse
    quality_metrics: ObservabilityMetricsResponse
    top_themes: list[ThemeInsight]
    segment_comparison: SegmentThemeComparisonResponse | None
    recent_answers: list[AnswerRunDetail]
    sections: list[InsightReportSection]
    markdown: str
    limitations: list[str]
