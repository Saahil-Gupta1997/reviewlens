from datetime import datetime
from typing import Literal

from pydantic import BaseModel

EvaluationCategory = Literal[
    "factual",
    "theme",
    "quantitative",
    "filter",
    "comparison",
    "impossible",
]


class EvaluationMetric(BaseModel):
    name: str
    score: float
    passed: int
    total: int
    details: str


class EvaluationCategorySummary(BaseModel):
    category: EvaluationCategory
    passed: int
    total: int
    score: float


class EvaluationCaseResult(BaseModel):
    case_id: str
    category: EvaluationCategory
    question: str
    passed: bool
    latency_ms: float
    confidence: str
    evidence_count: int
    expected: str
    observed: str
    failures: list[str]


class EvaluationRunResponse(BaseModel):
    run_id: str
    version: str
    dataset_id: str
    generated_at: datetime
    total_questions: int
    passed_questions: int
    overall_score: float
    average_latency_ms: float
    p95_latency_ms: float
    metrics: list[EvaluationMetric]
    category_breakdown: list[EvaluationCategorySummary]
    cases: list[EvaluationCaseResult]
