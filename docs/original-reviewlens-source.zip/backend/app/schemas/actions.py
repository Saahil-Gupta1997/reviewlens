from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

from app.schemas.themes import (
    ThemeCompareDimension,
    ThemeCompareFilters,
    ThemeInsight,
    ThemeSample,
)

ActionPlanAudience = Literal["product", "support", "leadership"]
ActionPriority = Literal["critical", "high", "medium", "low"]
ActionEffort = Literal["small", "medium", "large"]


class ActionPlanSegmentRequest(BaseModel):
    compare_by: ThemeCompareDimension
    left_value: str = Field(min_length=1, max_length=120)
    right_value: str = Field(min_length=1, max_length=120)
    limit: int = Field(default=5, ge=1, le=10)
    min_count: int = Field(default=1, ge=1, le=100)


class ActionPlanRequest(BaseModel):
    audience: ActionPlanAudience = "product"
    filters: ThemeCompareFilters = Field(default_factory=ThemeCompareFilters)
    theme_limit: int = Field(default=6, ge=1, le=10)
    max_actions: int = Field(default=5, ge=1, le=10)
    segment_comparison: ActionPlanSegmentRequest | None = None


class ActionPlanMetric(BaseModel):
    label: str
    value: str


class ReviewActionItem(BaseModel):
    action_id: str
    title: str
    priority: ActionPriority
    owner: Literal["product", "support", "engineering", "success"]
    effort: ActionEffort
    theme: str
    rationale: str
    expected_impact: str
    next_steps: list[str]
    evidence: list[ThemeSample]
    metrics: list[ActionPlanMetric]


class ActionPlanResponse(BaseModel):
    dataset_id: str
    generated_at: datetime
    audience: ActionPlanAudience
    filters: ThemeCompareFilters
    filtered_review_count: int
    average_rating: float | None
    negative_review_count: int
    top_themes: list[ThemeInsight]
    actions: list[ReviewActionItem]
    segment_drivers: list[str]
    limitations: list[str]
    markdown: str
