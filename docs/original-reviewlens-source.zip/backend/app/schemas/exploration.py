from datetime import date

from pydantic import BaseModel, Field


class ReviewListItem(BaseModel):
    id: str
    external_review_id: str | None
    review_text: str
    review_title: str | None
    rating: float | None
    review_date: date | None
    source: str | None
    product_name: str | None
    product_version: str | None
    region: str | None
    country: str | None
    customer_segment: str | None
    platform: str | None
    channel: str | None
    verified_purchase: bool | None
    row_number: int


class RatingBucket(BaseModel):
    rating: str
    count: int


class TrendPoint(BaseModel):
    date: date
    count: int


class FilterOptions(BaseModel):
    product_names: list[str] = Field(default_factory=list)
    product_versions: list[str] = Field(default_factory=list)
    sources: list[str] = Field(default_factory=list)
    regions: list[str] = Field(default_factory=list)
    countries: list[str] = Field(default_factory=list)
    customer_segments: list[str] = Field(default_factory=list)
    platforms: list[str] = Field(default_factory=list)
    channels: list[str] = Field(default_factory=list)


class ExploreMetrics(BaseModel):
    total_reviews: int
    filtered_reviews: int
    average_rating: float | None
    rated_reviews: int


class DatasetExploreResponse(BaseModel):
    dataset_id: str
    metrics: ExploreMetrics
    rating_distribution: list[RatingBucket]
    volume_trend: list[TrendPoint]
    filter_options: FilterOptions
    reviews: list[ReviewListItem]
    limit: int
    offset: int
