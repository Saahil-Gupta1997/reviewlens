from pydantic import BaseModel, Field


class FieldMapping(BaseModel):
    external_review_id: str | None = "review_id"
    review_text: str = "review_text"
    review_title: str | None = "review_title"
    rating: str | None = "rating"
    review_date: str | None = "review_date"
    source: str | None = "source"
    product_name: str | None = "product"
    product_version: str | None = "product_version"
    region: str | None = "region"
    country: str | None = "country"
    language: str | None = "language"
    customer_segment: str | None = "customer_segment"
    platform: str | None = "platform"
    channel: str | None = "channel"
    verified_purchase: str | None = "verified_status"


class ImportErrorPreview(BaseModel):
    row_number: int
    error_code: str
    message: str
    payload: dict[str, object | None] = Field(default_factory=dict)


class DatasetSummary(BaseModel):
    dataset_id: str
    ingestion_job_id: str
    name: str
    filename: str
    status: str
    total_rows: int
    accepted_rows: int
    rejected_rows: int
    duplicate_rows: int
    field_mapping: FieldMapping
    errors_preview: list[ImportErrorPreview] = Field(default_factory=list)


class DatasetListItem(BaseModel):
    dataset_id: str
    name: str
    filename: str
    status: str
    total_rows: int
    accepted_rows: int
    rejected_rows: int
    duplicate_rows: int
