from datetime import date
from typing import Literal

from pydantic import BaseModel, Field


class SentimentBucket(BaseModel):
    label: str
    count: int
    share: float


class ThemeSample(BaseModel):
    review_id: str
    row_number: int
    review_text: str
    rating: float | None
    review_date: date | None
    source: str | None
    product_name: str | None


class ThemeInsight(BaseModel):
    label: str
    count: int
    share: float
    average_rating: float | None
    negative_count: int
    positive_count: int
    risk_score: float
    keywords: list[str]
    samples: list[ThemeSample]


class ThemeComparisonItem(BaseModel):
    label: str
    current_count: int
    previous_count: int
    delta: int
    delta_share: float


class ThemeComparison(BaseModel):
    current_start: date
    current_end: date
    previous_start: date
    previous_end: date
    items: list[ThemeComparisonItem]


class DatasetThemesResponse(BaseModel):
    dataset_id: str
    total_reviews: int
    analyzed_reviews: int
    theme_coverage: float
    sentiment_distribution: list[SentimentBucket]
    themes: list[ThemeInsight]
    comparison: ThemeComparison | None
    limitations: list[str]


ThemeCompareDimension = Literal[
    "source",
    "region",
    "country",
    "product_name",
    "product_version",
    "platform",
    "customer_segment",
    "channel",
]


class ThemeCompareFilters(BaseModel):
    rating_min: float | None = Field(default=None, ge=0, le=5)
    rating_max: float | None = Field(default=None, ge=0, le=5)
    date_from: date | None = None
    date_to: date | None = None
    product_name: str | None = None
    product_version: str | None = None
    source: str | None = None
    region: str | None = None
    country: str | None = None
    language: str | None = None
    customer_segment: str | None = None
    platform: str | None = None
    channel: str | None = None
    verified_purchase: bool | None = None
    q: str | None = Field(default=None, max_length=250)


class ThemeCompareRequest(BaseModel):
    compare_by: ThemeCompareDimension
    left_value: str = Field(min_length=1, max_length=120)
    right_value: str = Field(min_length=1, max_length=120)
    filters: ThemeCompareFilters = Field(default_factory=ThemeCompareFilters)
    limit: int = Field(default=5, ge=1, le=25)
    min_count: int = Field(default=1, ge=1, le=100)


class SegmentThemeSummary(BaseModel):
    segment: str
    review_count: int
    average_rating: float | None
    negative_rate: float
    sentiment_distribution: list[SentimentBucket]
    top_themes: list[ThemeInsight]


class SegmentThemeDelta(BaseModel):
    label: str
    left_count: int
    right_count: int
    left_share: float
    right_share: float
    delta_share: float
    direction: Literal["left_higher", "right_higher", "similar"]
    summary: str


class SegmentThemeComparisonResponse(BaseModel):
    dataset_id: str
    compare_by: ThemeCompareDimension
    filtered_review_count: int
    left: SegmentThemeSummary
    right: SegmentThemeSummary
    deltas: list[SegmentThemeDelta]
    limitations: list[str]
