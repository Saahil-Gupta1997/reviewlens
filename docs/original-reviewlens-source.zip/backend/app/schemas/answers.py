from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, Field

AnswerMode = Literal["keyword", "semantic", "hybrid"]
AnswerStyle = Literal["summary", "issues", "sentiment", "root_cause"]
AnswerConfidence = Literal["none", "low", "medium", "high"]
AnswerFeedbackRating = Literal["useful", "incorrect", "unsupported"]
AnswerRoute = Literal["retrieval", "analytics", "retrieval_analytics"]
ComparisonType = Literal["version", "period", "segment"]


class AnswerFilters(BaseModel):
    rating_min: float | None = Field(default=None, ge=0, le=5)
    rating_max: float | None = Field(default=None, ge=0, le=5)
    date_from: date | None = None
    date_to: date | None = None
    product_name: str | None = None
    product_version: str | None = None
    source: str | None = None
    region: str | None = None
    country: str | None = None
    language: str | None = None
    customer_segment: str | None = None
    platform: str | None = None
    channel: str | None = None
    verified_purchase: bool | None = None


class AnswerRequest(BaseModel):
    question: str = Field(min_length=1, max_length=500)
    mode: AnswerMode = "hybrid"
    top_k: int = Field(default=8, ge=1, le=20)
    answer_style: AnswerStyle = "summary"
    filters: AnswerFilters = Field(default_factory=AnswerFilters)


class AnswerCitation(BaseModel):
    citation_id: int
    review_id: str
    row_number: int
    quote: str
    rating: float | None
    review_date: date | None
    source: str | None
    product_name: str | None
    product_version: str | None
    region: str | None
    country: str | None
    customer_segment: str | None
    semantic_score: float
    keyword_score: float
    hybrid_score: float


class AnswerTheme(BaseModel):
    label: str
    count: int
    score: float


class AnswerAnalytic(BaseModel):
    label: str
    value: str
    numerator: float | None = None
    denominator: float | None = None
    percentage: float | None = None
    details: str


class AnswerComparisonSegment(BaseModel):
    label: str
    review_count: int
    average_rating: float | None


class AnswerThemeMovement(BaseModel):
    label: str
    before_count: int
    before_share: float
    after_count: int
    after_share: float
    delta_share: float
    direction: Literal["increased", "decreased", "flat"]


class AnswerComparison(BaseModel):
    comparison_type: ComparisonType
    dimension: str
    before: AnswerComparisonSegment
    after: AnswerComparisonSegment
    rating_delta: float | None
    theme_movements: list[AnswerThemeMovement]
    summary: str


class AnswerResponse(BaseModel):
    answer_id: str = ""
    dataset_id: str
    question: str
    answer_style: AnswerStyle
    route: AnswerRoute = "retrieval"
    answer: str
    confidence: AnswerConfidence
    confidence_score: int
    index_status: str
    evidence_count: int
    filtered_review_count: int
    themes: list[AnswerTheme]
    analytics: list[AnswerAnalytic] = Field(default_factory=list)
    comparison: AnswerComparison | None = None
    citations: list[AnswerCitation]
    limitations: list[str]
    generation_model: str


class AnswerFeedbackRequest(BaseModel):
    rating: AnswerFeedbackRating
    notes: str | None = Field(default=None, max_length=1000)


class AnswerFeedbackResponse(BaseModel):
    feedback_id: str
    answer_id: str
    dataset_id: str
    rating: AnswerFeedbackRating
    notes: str | None


class AnswerRunSummary(BaseModel):
    answer_id: str
    dataset_id: str
    question: str
    answer_style: AnswerStyle
    confidence: AnswerConfidence
    confidence_score: int
    index_status: str
    evidence_count: int
    feedback_rating: str | None
    created_at: datetime


class AnswerRunDetail(AnswerResponse):
    mode: AnswerMode
    top_k: int
    filters: AnswerFilters
    latency_ms: float
    feedback_rating: str | None
    feedback_notes: str | None
    created_at: datetime


class CountBucket(BaseModel):
    label: str
    count: int


class ObservabilityMetricsResponse(BaseModel):
    dataset_id: str
    answer_count: int
    average_confidence_score: float | None
    average_latency_ms: float | None
    average_evidence_count: float | None
    no_evidence_rate: float
    partial_index_rate: float
    confidence_distribution: list[CountBucket]
    feedback_distribution: list[CountBucket]
    top_themes: list[CountBucket]
    top_limitations: list[CountBucket]
