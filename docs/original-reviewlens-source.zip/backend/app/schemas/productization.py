from pydantic import BaseModel


class ModelConfiguration(BaseModel):
    embedding_provider: str
    embedding_model: str
    embedding_dimensions: int
    answer_provider: str
    answer_model: str
    retrieval_auto_index: bool
    openai_configured: bool


class CostConfiguration(BaseModel):
    tracking_basis: str
    embedding_cost_per_1k_tokens_usd: float
    answer_input_cost_per_1k_tokens_usd: float
    answer_output_cost_per_1k_tokens_usd: float
    notes: list[str]


class ReleaseReadinessResponse(BaseModel):
    app_name: str
    app_version: str
    environment: str
    model_configuration: ModelConfiguration
    cost_configuration: CostConfiguration
    privacy: list[str]
    security: list[str]
    limits: list[str]
    limitations: list[str]
    release_checklist: list[str]
