from datetime import date

from pydantic import BaseModel


class RetrievalIndexResponse(BaseModel):
    dataset_id: str
    embedding_model: str
    dimensions: int
    indexed_reviews: int
    skipped_reviews: int


class RetrievalStatusResponse(BaseModel):
    dataset_id: str
    embedding_model: str
    dimensions: int
    total_reviews: int
    indexed_reviews: int
    pending_reviews: int
    status: str


class RetrievalEvidenceItem(BaseModel):
    review_id: str
    row_number: int
    review_text: str
    rating: float | None
    review_date: date | None
    source: str | None
    product_name: str | None
    product_version: str | None
    region: str | None
    country: str | None
    customer_segment: str | None
    semantic_score: float
    keyword_score: float
    hybrid_score: float


class RetrievalSearchResponse(BaseModel):
    dataset_id: str
    query: str
    mode: str
    top_k: int
    index_status: str
    results: list[RetrievalEvidenceItem]
