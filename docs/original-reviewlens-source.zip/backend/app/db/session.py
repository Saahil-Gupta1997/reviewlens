from collections.abc import AsyncGenerator
from functools import lru_cache

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.core.config import get_settings
from app.db.base import Base


@lru_cache
def get_engine() -> AsyncEngine:
    settings = get_settings()
    engine_kwargs = {"pool_pre_ping": True}

    if settings.database_url.startswith("sqlite+aiosqlite"):
        engine_kwargs = {"connect_args": {"check_same_thread": False}}

    return create_async_engine(settings.database_url, **engine_kwargs)


def create_engine() -> AsyncEngine:
    return get_engine()


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    session_factory = async_sessionmaker(get_engine(), expire_on_commit=False)
    async with session_factory() as session:
        yield session


async def create_database_schema() -> None:
    from app import models  # noqa: F401

    engine = get_engine()
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)


async def ping_database() -> bool:
    engine = get_engine()
    try:
        async with engine.connect() as connection:
            await connection.execute(text("SELECT 1"))
        return True
    except Exception:
        return False
