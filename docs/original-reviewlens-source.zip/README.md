# ReviewLens

ReviewLens is a customer-review intelligence workspace for product teams. It turns uploaded CSV/JSON review datasets into searchable evidence, deterministic analytics, before/after comparisons, AI-assisted themes, grounded answers with citations, and a reproducible evaluation scorecard.

## Quickstart

Prerequisites:

- Docker Desktop with Compose v2
- Node 22 and Python 3.12 only if running services outside Docker
- Optional OpenAI API key for real embeddings and LLM answers

Start locally:

```bash
copy .env.example .env
docker compose up --build
```

Open:

- Frontend: `http://localhost:5173`
- Backend health: `http://localhost:8000/api/healthz`
- Backend readiness: `http://localhost:8000/api/readyz`

Docker Compose is a local-development stack. It runs FastAPI with reload, Vite dev server, and Postgres with pgvector.

## Demo Flow

1. Open ReviewLens and stay on `Overview`.
2. Click `Load demo dataset`, or upload `sample_data/reviewlens_demo_reviews.csv`.
3. Open `Explore Reviews` to inspect filters, metrics, source reviews, themes, and segment comparison.
4. Open `Ask ReviewLens` and ask `Why did ratings decline after version 4.2?`.
5. Open cited reviews from the answer to inspect the exact evidence.
6. Open `Evaluation` and click `Run Evaluation`.
7. Review the scorecard, limitations, privacy notes, and optional portfolio exports.

## Primary Product Surface

- `Overview`: upload/demo data, dataset management, safe model configuration, privacy, security, limits, and known limitations.
- `Explore Reviews`: filters, rating distribution, trend, review table, source detail, theme discovery, and segment comparison.
- `Ask ReviewLens`: retrieval indexing/search plus routed, grounded Q&A.
- `Evaluation`: golden evaluation scorecard, answer history, feedback, quality metrics, and secondary export/action tools.

## Architecture

```mermaid
flowchart LR
  UI["React / Vite workspace"] --> API["FastAPI API"]
  API --> DB["Postgres + pgvector"]
  API --> INGEST["CSV / JSON ingestion"]
  API --> ROUTER["Question router"]
  ROUTER --> RAG["Semantic retrieval"]
  ROUTER --> CALC["Deterministic analytics"]
  ROUTER --> COMP["Comparison engine"]
  RAG --> LLM["Configured answer provider"]
  API --> THEMES["AI-assisted theme discovery"]
  API --> EVAL["Golden evaluation runner"]
  API --> OBS["Answer history, feedback, latency"]
  INGEST --> DB
  RAG --> DB
  THEMES --> DB
  OBS --> DB
```

More detail: `docs/architecture.md`.

## Configuration

The app defaults to deterministic local providers so it can run without external accounts:

```text
EMBEDDING_PROVIDER=local
EMBEDDING_MODEL=reviewlens-local-hash-v1
ANSWER_PROVIDER=local
ANSWER_MODEL=reviewlens-local-template-v1
```

For real RAG:

```text
EMBEDDING_PROVIDER=openai
ANSWER_PROVIDER=openai
OPENAI_API_KEY=...
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
OPENAI_ANSWER_MODEL=gpt-4.1-mini
```

Keep secrets only in `.env` or your deployment secret store. The frontend never receives `OPENAI_API_KEY`; `GET /api/productization/release-readiness` only returns a boolean `openai_configured`.

Optional cost tracking rates:

```text
EMBEDDING_COST_PER_1K_TOKENS_USD=0
ANSWER_INPUT_COST_PER_1K_TOKENS_USD=0
ANSWER_OUTPUT_COST_PER_1K_TOKENS_USD=0
```

Set these from current provider pricing before a paid-provider demo. Leave them at zero for local providers.

## API Highlights

- `POST /api/datasets`: upload CSV/JSON reviews.
- `GET /api/datasets`: list datasets.
- `DELETE /api/datasets/{dataset_id}`: delete a dataset and related artifacts.
- `GET /api/datasets/{dataset_id}/explore`: filtered metrics, facets, trends, and reviews.
- `POST /api/datasets/{dataset_id}/retrieval/index`: build embeddings.
- `GET /api/datasets/{dataset_id}/retrieval/search`: keyword, semantic, or hybrid evidence search.
- `POST /api/datasets/{dataset_id}/answers`: routed grounded answers.
- `GET /api/datasets/{dataset_id}/themes`: discovered themes and deterministic counts.
- `POST /api/datasets/{dataset_id}/themes/compare`: compare `source`, `region`, `country`, `product_name`, `product_version`, `platform`, `customer_segment`, or `channel`.
- `POST /api/evaluations/run`: run the golden evaluation scorecard.
- `GET /api/productization/release-readiness`: safe release metadata, model config, privacy, limits, cost settings, and checklist.

## Privacy, Retention, And Deletion

Uploaded reviews are stored in the configured backend database. If OpenAI providers are enabled, review text and questions used for embeddings/answers are sent to the configured OpenAI-compatible endpoint.

Dataset deletion removes reviews, embeddings, discovered themes and assignments, answer history, answer feedback, import errors, and ingestion jobs.

Current release limitation: the app does not include authentication, role-based access control, or PII redaction. Use it on local/demo datasets unless those controls are added for production.

## Evaluation

Run from the UI with `Evaluation` -> `Run Evaluation`, or from the API:

```bash
curl -X POST http://localhost:8000/api/evaluations/run
```

The scorecard reports retrieval relevance, citation support, abstention accuracy, calculation accuracy, filter correctness, robustness, average latency, and P95 latency. Details: `docs/evaluation-report.md`.

## Checks

Backend:

```bash
cd backend
python -m pip install -e ".[dev]"
python -m ruff check .
python -m pytest
```

Frontend:

```bash
cd frontend
pnpm install
pnpm run lint
pnpm test -- --run
pnpm run build
```

## Known Limitations

See `docs/limitations.md` for the release limitation register. The short version: local providers are demo-grade, auth/PII controls are not production-ready yet, and evaluation is synthetic rather than live production monitoring.
