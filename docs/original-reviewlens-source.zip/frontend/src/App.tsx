import {
  Activity,
  AlertCircle,
  BarChart3,
  Braces,
  Clipboard,
  Database,
  Download,
  FileUp,
  FileText,
  Layers3,
  MessageSquareText,
  PlayCircle,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2
} from "lucide-react";
import { type FormEvent, useEffect, useState } from "react";

import {
  askDatasetAnswer,
  deleteDataset,
  fetchAnswerDetail,
  fetchAnswerHistory,
  fetchDatasetExplore,
  fetchDatasetThemes,
  fetchDatasets,
  fetchObservabilityMetrics,
  fetchReleaseReadiness,
  fetchRetrievalStatus,
  fetchThemeComparison,
  generateActionPlan,
  generateInsightBrief,
  indexDatasetRetrieval,
  runEvaluation,
  searchDatasetRetrieval,
  submitAnswerFeedback,
  uploadDataset,
  type AnswerCitation,
  type AnswerResponse,
  type AnswerRunSummary,
  type AnswerStyle,
  type ActionPlanAudience,
  type ActionPlanResponse,
  type DatasetExploreResponse,
  type DatasetListItem,
  type DatasetSummary,
  type DatasetThemesResponse,
  type EvaluationRunResponse,
  type ExploreFilters,
  type InsightReportResponse,
  type SegmentThemeComparisonResponse,
  type ThemeCompareDimension,
  type RetrievalEvidenceItem,
  type ObservabilityMetricsResponse,
  type ReleaseReadinessResponse,
  type RetrievalSearchResponse,
  type RetrievalStatusResponse,
  type ReviewListItem
} from "./api/datasets";
import { fetchHealth, type HealthResponse } from "./api/health";

type HealthState =
  | { kind: "loading" }
  | { kind: "online"; data: HealthResponse }
  | { kind: "offline"; message: string };

type PrimarySection = "overview" | "explore" | "ask" | "evaluation";

const primarySections: { id: PrimarySection; label: string; icon: typeof Database }[] = [
  { id: "overview", label: "Overview", icon: Database },
  { id: "explore", label: "Explore Reviews", icon: Layers3 },
  { id: "ask", label: "Ask ReviewLens", icon: MessageSquareText },
  { id: "evaluation", label: "Evaluation", icon: ShieldCheck }
];

function App() {
  const [activeSection, setActiveSection] = useState<PrimarySection>("overview");
  const [health, setHealth] = useState<HealthState>({ kind: "loading" });
  const [datasets, setDatasets] = useState<DatasetListItem[]>([]);
  const [datasetListState, setDatasetListState] = useState<
    | { kind: "loading" }
    | { kind: "ready" }
    | { kind: "error"; message: string }
  >({ kind: "loading" });
  const [datasetName, setDatasetName] = useState("");
  const [mapping, setMapping] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedDatasetId, setSelectedDatasetId] = useState("");
  const [releaseReadiness, setReleaseReadiness] = useState<ReleaseReadinessResponse | null>(null);
  const [exploreFilters, setExploreFilters] = useState<ExploreFilters>({});
  const [selectedReview, setSelectedReview] = useState<ReviewListItem | null>(null);
  const [retrievalQuery, setRetrievalQuery] = useState("");
  const [retrievalMode, setRetrievalMode] = useState<"keyword" | "semantic" | "hybrid">("hybrid");
  const [answerQuestion, setAnswerQuestion] = useState("");
  const [answerStyle, setAnswerStyle] = useState<AnswerStyle>("summary");
  const [answerTopK, setAnswerTopK] = useState("8");
  const [feedbackNotes, setFeedbackNotes] = useState("");
  const [answerHistory, setAnswerHistory] = useState<AnswerRunSummary[]>([]);
  const [qualityMetrics, setQualityMetrics] = useState<ObservabilityMetricsResponse | null>(null);
  const [selectedThemeLabel, setSelectedThemeLabel] = useState("");
  const [compareBy, setCompareBy] = useState<ThemeCompareDimension>("region");
  const [leftSegment, setLeftSegment] = useState("");
  const [rightSegment, setRightSegment] = useState("");
  const [compareLimit, setCompareLimit] = useState("5");
  const [briefTitle, setBriefTitle] = useState("");
  const [includeSegmentBrief, setIncludeSegmentBrief] = useState(false);
  const [actionAudience, setActionAudience] = useState<ActionPlanAudience>("product");
  const [includeSegmentActions, setIncludeSegmentActions] = useState(false);
  const [maxActions, setMaxActions] = useState("5");
  const [retrievalStatus, setRetrievalStatus] = useState<RetrievalStatusResponse | null>(null);
  const [indexState, setIndexState] = useState<
    | { kind: "idle" }
    | { kind: "indexing" }
    | { kind: "success"; message: string }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [retrievalState, setRetrievalState] = useState<
    | { kind: "idle" }
    | { kind: "searching" }
    | { kind: "success"; data: RetrievalSearchResponse }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [answerState, setAnswerState] = useState<
    | { kind: "idle" }
    | { kind: "answering" }
    | { kind: "success"; data: AnswerResponse }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [feedbackState, setFeedbackState] = useState<
    | { kind: "idle" }
    | { kind: "saving" }
    | { kind: "success"; message: string }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [exploreState, setExploreState] = useState<
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: DatasetExploreResponse }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [themeState, setThemeState] = useState<
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: DatasetThemesResponse }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [segmentComparisonState, setSegmentComparisonState] = useState<
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: SegmentThemeComparisonResponse }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [briefState, setBriefState] = useState<
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: InsightReportResponse; copyState: "idle" | "copied" | "error" }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [actionPlanState, setActionPlanState] = useState<
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: ActionPlanResponse; copyState: "idle" | "copied" | "error" }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [uploadState, setUploadState] = useState<
    | { kind: "idle" }
    | { kind: "uploading" }
    | { kind: "success"; summary: DatasetSummary }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [deleteState, setDeleteState] = useState<
    | { kind: "idle" }
    | { kind: "deleting" }
    | { kind: "success"; message: string }
    | { kind: "error"; message: string }
  >({ kind: "idle" });
  const [evaluationState, setEvaluationState] = useState<
    | { kind: "idle" }
    | { kind: "running" }
    | { kind: "success"; data: EvaluationRunResponse }
    | { kind: "error"; message: string }
  >({ kind: "idle" });

  useEffect(() => {
    let mounted = true;

    fetchHealth()
      .then((data) => {
        if (mounted) {
          setHealth({ kind: "online", data });
        }
      })
      .catch((error: Error) => {
        if (mounted) {
          setHealth({ kind: "offline", message: error.message });
        }
      });

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    let mounted = true;

    setDatasetListState({ kind: "loading" });
    fetchDatasets()
      .then((data) => {
        if (mounted) {
          setDatasets(data);
          setDatasetListState({ kind: "ready" });
          if (data[0]) {
            setSelectedDatasetId(data[0].dataset_id);
          }
        }
      })
      .catch((error: Error) => {
        if (mounted) {
          setDatasets([]);
          setDatasetListState({ kind: "error", message: error.message });
        }
      });

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    let mounted = true;

    fetchReleaseReadiness()
      .then((data) => {
        if (mounted) {
          setReleaseReadiness(data);
        }
      })
      .catch(() => {
        if (mounted) {
          setReleaseReadiness(null);
        }
      });

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!selectedDatasetId) {
      setExploreState({ kind: "idle" });
      setThemeState({ kind: "idle" });
      setBriefState({ kind: "idle" });
      setActionPlanState({ kind: "idle" });
      setSelectedReview(null);
      return;
    }

    let mounted = true;
    setExploreState({ kind: "loading" });
    setBriefState({ kind: "idle" });
    setActionPlanState({ kind: "idle" });

    fetchDatasetExplore(selectedDatasetId, exploreFilters)
      .then((data) => {
        if (mounted) {
          setExploreState({ kind: "success", data });
          setSelectedReview(data.reviews[0] ?? null);
        }
      })
      .catch((error: Error) => {
        if (mounted) {
          setExploreState({ kind: "error", message: error.message });
          setSelectedReview(null);
        }
      });

    setThemeState({ kind: "loading" });
    fetchDatasetThemes(selectedDatasetId, exploreFilters)
      .then((data) => {
        if (mounted) {
          setThemeState({ kind: "success", data });
          setSelectedThemeLabel((current) => current || data.themes[0]?.label || "");
        }
      })
      .catch((error: Error) => {
        if (mounted) {
          setThemeState({ kind: "error", message: error.message });
          setSelectedThemeLabel("");
        }
      });

    return () => {
      mounted = false;
    };
  }, [selectedDatasetId, exploreFilters]);

  useEffect(() => {
    if (!selectedDatasetId) {
      setRetrievalStatus(null);
      setAnswerHistory([]);
      setQualityMetrics(null);
      return;
    }

    let mounted = true;
    fetchRetrievalStatus(selectedDatasetId)
      .then((status) => {
        if (mounted) {
          setRetrievalStatus(status);
        }
      })
      .catch(() => {
        if (mounted) {
          setRetrievalStatus(null);
        }
      });

    return () => {
      mounted = false;
    };
  }, [selectedDatasetId]);

  useEffect(() => {
    if (!selectedDatasetId) {
      return;
    }

    refreshTrustData(selectedDatasetId);
  }, [selectedDatasetId]);

  async function handleUpload(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedFile) {
      setUploadState({ kind: "error", message: "Select a CSV or JSON file." });
      return;
    }

    setUploadState({ kind: "uploading" });
    try {
      const summary = await uploadDataset({
        file: selectedFile,
        datasetName: datasetName.trim() || undefined,
        fieldMapping: mapping.trim() || undefined
      });
      setUploadState({ kind: "success", summary });
      setDatasets((current) => [
        {
          dataset_id: summary.dataset_id,
          name: summary.name,
          filename: summary.filename,
          status: summary.status,
          total_rows: summary.total_rows,
          accepted_rows: summary.accepted_rows,
          rejected_rows: summary.rejected_rows,
          duplicate_rows: summary.duplicate_rows
        },
        ...current.filter((dataset) => dataset.dataset_id !== summary.dataset_id)
      ]);
      setDatasetListState({ kind: "ready" });
      setSelectedDatasetId(summary.dataset_id);
      resetDatasetScopedState();
    } catch (error) {
      setUploadState({
        kind: "error",
        message: error instanceof Error ? error.message : "Upload failed."
      });
    }
  }

  function updateExploreFilter(key: keyof ExploreFilters, value: string) {
    setExploreFilters((current) => ({
      ...current,
      [key]: value || undefined
    }));
  }

  function refreshTrustData(datasetId: string) {
    fetchAnswerHistory(datasetId)
      .then(setAnswerHistory)
      .catch(() => setAnswerHistory([]));
    fetchObservabilityMetrics(datasetId)
      .then(setQualityMetrics)
      .catch(() => setQualityMetrics(null));
  }

  function resetDatasetScopedState() {
    setExploreFilters({});
    setSelectedReview(null);
    setRetrievalState({ kind: "idle" });
    setAnswerState({ kind: "idle" });
    setFeedbackState({ kind: "idle" });
    setFeedbackNotes("");
    setBriefState({ kind: "idle" });
    setActionPlanState({ kind: "idle" });
    setSegmentComparisonState({ kind: "idle" });
    setAnswerHistory([]);
    setQualityMetrics(null);
    setRetrievalStatus(null);
  }

  async function handleLoadDemoDataset() {
    setUploadState({ kind: "uploading" });
    try {
      const response = await fetch("/sample_data/reviewlens_demo_reviews.csv");
      if (!response.ok) {
        throw new Error("Demo dataset could not be loaded from the app bundle.");
      }
      const blob = await response.blob();
      const file = new File([blob], "reviewlens_demo_reviews.csv", { type: "text/csv" });
      const summary = await uploadDataset({
        file,
        datasetName: "ReviewLens demo dataset"
      });
      setUploadState({ kind: "success", summary });
      setDatasets((current) => [
        {
          dataset_id: summary.dataset_id,
          name: summary.name,
          filename: summary.filename,
          status: summary.status,
          total_rows: summary.total_rows,
          accepted_rows: summary.accepted_rows,
          rejected_rows: summary.rejected_rows,
          duplicate_rows: summary.duplicate_rows
        },
        ...current.filter((dataset) => dataset.dataset_id !== summary.dataset_id)
      ]);
      setDatasetListState({ kind: "ready" });
      setSelectedDatasetId(summary.dataset_id);
      resetDatasetScopedState();
    } catch (error) {
      setUploadState({
        kind: "error",
        message: error instanceof Error ? error.message : "Demo dataset failed to load."
      });
    }
  }

  async function handleDeleteSelectedDataset() {
    if (!selectedDatasetId) {
      setDeleteState({ kind: "error", message: "Select a dataset before deleting." });
      return;
    }
    const dataset = datasets.find((item) => item.dataset_id === selectedDatasetId);
    setDeleteState({ kind: "deleting" });
    try {
      await deleteDataset(selectedDatasetId);
      const remaining = datasets.filter((item) => item.dataset_id !== selectedDatasetId);
      setDatasets(remaining);
      setSelectedDatasetId(remaining[0]?.dataset_id ?? "");
      resetDatasetScopedState();
      setDeleteState({
        kind: "success",
        message: `${dataset?.name ?? "Dataset"} deleted with its reviews and AI artifacts.`
      });
    } catch (error) {
      setDeleteState({
        kind: "error",
        message: error instanceof Error ? error.message : "Dataset deletion failed."
      });
    }
  }

  async function handleRunEvaluation() {
    setEvaluationState({ kind: "running" });
    try {
      const data = await runEvaluation();
      setEvaluationState({ kind: "success", data });
    } catch (error) {
      setEvaluationState({
        kind: "error",
        message: error instanceof Error ? error.message : "Evaluation failed."
      });
    }
  }

  function handleCitationOpen(citation: AnswerCitation) {
    const visibleReview =
      exploreState.kind === "success"
        ? exploreState.data.reviews.find((review) => review.id === citation.review_id)
        : null;
    setSelectedReview(visibleReview ?? reviewFromCitation(citation));
    setActiveSection("explore");
    const explorer = document.querySelector<HTMLElement>('[aria-label="Review explorer"]');
    explorer?.scrollIntoView?.({ behavior: "smooth", block: "start" });
  }

  async function handleIndexDataset() {
    if (!selectedDatasetId) {
      setIndexState({ kind: "error", message: "Select a dataset before indexing." });
      return;
    }

    setIndexState({ kind: "indexing" });
    try {
      const result = await indexDatasetRetrieval(selectedDatasetId);
      setIndexState({
        kind: "success",
        message: `${result.indexed_reviews} indexed / ${result.skipped_reviews} skipped`
      });
      const status = await fetchRetrievalStatus(selectedDatasetId);
      setRetrievalStatus(status);
    } catch (error) {
      setIndexState({
        kind: "error",
        message: error instanceof Error ? error.message : "Indexing failed."
      });
    }
  }

  async function handleRetrievalSearch() {
    if (!selectedDatasetId) {
      setRetrievalState({ kind: "error", message: "Select a dataset before searching." });
      return;
    }
    if (!retrievalQuery.trim()) {
      setRetrievalState({ kind: "error", message: "Enter a retrieval query." });
      return;
    }

    setRetrievalState({ kind: "searching" });
    try {
      const data = await searchDatasetRetrieval({
        datasetId: selectedDatasetId,
        query: retrievalQuery.trim(),
        mode: retrievalMode,
        filters: exploreFilters,
        topK: 8
      });
      setRetrievalState({ kind: "success", data });
    } catch (error) {
      setRetrievalState({
        kind: "error",
        message: error instanceof Error ? error.message : "Retrieval search failed."
      });
    }
  }

  async function handleAskAnswer() {
    if (!selectedDatasetId) {
      setAnswerState({ kind: "error", message: "Select a dataset before asking." });
      return;
    }
    if (!answerQuestion.trim()) {
      setAnswerState({ kind: "error", message: "Enter a question." });
      return;
    }

    setAnswerState({ kind: "answering" });
    try {
      const data = await askDatasetAnswer({
        datasetId: selectedDatasetId,
        question: answerQuestion.trim(),
        mode: retrievalMode,
        answerStyle,
        filters: exploreFilters,
        topK: Number(answerTopK) || 8
      });
      setAnswerState({ kind: "success", data });
      setFeedbackState({ kind: "idle" });
      setFeedbackNotes("");
      refreshTrustData(selectedDatasetId);
    } catch (error) {
      setAnswerState({
        kind: "error",
        message: error instanceof Error ? error.message : "Answer generation failed."
      });
    }
  }

  async function handleFeedback(rating: "useful" | "incorrect" | "unsupported") {
    if (!selectedDatasetId || answerState.kind !== "success" || !answerState.data.answer_id) {
      setFeedbackState({ kind: "error", message: "Ask a question before submitting feedback." });
      return;
    }

    setFeedbackState({ kind: "saving" });
    try {
      await submitAnswerFeedback({
        datasetId: selectedDatasetId,
        answerId: answerState.data.answer_id,
        rating,
        notes: feedbackNotes.trim() || undefined
      });
      setFeedbackState({ kind: "success", message: "Feedback saved" });
      refreshTrustData(selectedDatasetId);
    } catch (error) {
      setFeedbackState({
        kind: "error",
        message: error instanceof Error ? error.message : "Feedback failed."
      });
    }
  }

  async function handleHistorySelect(answerId: string) {
    if (!selectedDatasetId) {
      return;
    }
    setAnswerState({ kind: "answering" });
    try {
      const detail = await fetchAnswerDetail({ datasetId: selectedDatasetId, answerId });
      setAnswerQuestion(detail.question);
      setAnswerStyle(detail.answer_style);
      setAnswerTopK(String(detail.top_k));
      setAnswerState({ kind: "success", data: detail });
      setFeedbackNotes(detail.feedback_notes ?? "");
      setFeedbackState(
        detail.feedback_rating
          ? { kind: "success", message: `Feedback saved: ${detail.feedback_rating}` }
          : { kind: "idle" }
      );
    } catch (error) {
      setAnswerState({
        kind: "error",
        message: error instanceof Error ? error.message : "Answer history failed."
      });
    }
  }

  async function handleSegmentCompare() {
    if (!selectedDatasetId) {
      setSegmentComparisonState({ kind: "error", message: "Select a dataset before comparing." });
      return;
    }
    if (!leftSegment.trim() || !rightSegment.trim()) {
      setSegmentComparisonState({
        kind: "error",
        message: "Choose both comparison segments."
      });
      return;
    }

    setSegmentComparisonState({ kind: "loading" });
    try {
      const data = await fetchThemeComparison({
        datasetId: selectedDatasetId,
        compareBy,
        leftValue: leftSegment.trim(),
        rightValue: rightSegment.trim(),
        filters: withoutComparisonFilter(exploreFilters, compareBy),
        limit: Number(compareLimit) || 5,
        minCount: 1
      });
      setSegmentComparisonState({ kind: "success", data });
    } catch (error) {
      setSegmentComparisonState({
        kind: "error",
        message: error instanceof Error ? error.message : "Theme comparison failed."
      });
    }
  }

  async function handleGenerateBrief() {
    if (!selectedDatasetId) {
      setBriefState({ kind: "error", message: "Select a dataset before generating a brief." });
      return;
    }

    setBriefState({ kind: "loading" });
    try {
      const data = await generateInsightBrief({
        datasetId: selectedDatasetId,
        title: briefTitle.trim() || undefined,
        filters: exploreFilters,
        themeLimit: 5,
        recentAnswersLimit: 3,
        segmentComparison:
          includeSegmentBrief && segmentComparisonState.kind === "success"
            ? {
                compareBy,
                leftValue: segmentComparisonState.data.left.segment,
                rightValue: segmentComparisonState.data.right.segment,
                limit: Number(compareLimit) || 5,
                minCount: 1
              }
            : undefined
      });
      setBriefState({ kind: "success", data, copyState: "idle" });
    } catch (error) {
      setBriefState({
        kind: "error",
        message: error instanceof Error ? error.message : "Insight brief failed."
      });
    }
  }

  async function handleCopyBrief() {
    if (briefState.kind !== "success") {
      return;
    }
    try {
      await navigator.clipboard.writeText(briefState.data.markdown);
      setBriefState({ ...briefState, copyState: "copied" });
    } catch {
      setBriefState({ ...briefState, copyState: "error" });
    }
  }

  function handleDownloadBrief() {
    if (briefState.kind !== "success") {
      return;
    }
    const blob = new Blob([briefState.data.markdown], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "reviewlens-insight-brief.md";
    link.click();
    URL.revokeObjectURL(url);
  }

  async function handleGenerateActionPlan() {
    if (!selectedDatasetId) {
      setActionPlanState({ kind: "error", message: "Select a dataset before generating actions." });
      return;
    }

    setActionPlanState({ kind: "loading" });
    try {
      const data = await generateActionPlan({
        datasetId: selectedDatasetId,
        audience: actionAudience,
        filters: exploreFilters,
        themeLimit: 6,
        maxActions: Number(maxActions) || 5,
        segmentComparison:
          includeSegmentActions && segmentComparisonState.kind === "success"
            ? {
                compareBy,
                leftValue: segmentComparisonState.data.left.segment,
                rightValue: segmentComparisonState.data.right.segment,
                limit: Number(compareLimit) || 5,
                minCount: 1
              }
            : undefined
      });
      setActionPlanState({ kind: "success", data, copyState: "idle" });
    } catch (error) {
      setActionPlanState({
        kind: "error",
        message: error instanceof Error ? error.message : "Action plan failed."
      });
    }
  }

  async function handleCopyActionPlan() {
    if (actionPlanState.kind !== "success") {
      return;
    }
    try {
      await navigator.clipboard.writeText(actionPlanState.data.markdown);
      setActionPlanState({ ...actionPlanState, copyState: "copied" });
    } catch {
      setActionPlanState({ ...actionPlanState, copyState: "error" });
    }
  }

  function handleDownloadActionPlan() {
    if (actionPlanState.kind !== "success") {
      return;
    }
    const blob = new Blob([actionPlanState.data.markdown], {
      type: "text/markdown;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "reviewlens-action-plan.md";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="app-shell">
      <nav className="topbar" aria-label="Primary">
        <div className="brand-lockup">
          <span className="brand-mark">RL</span>
          <div>
            <p className="eyebrow">ReviewLens</p>
            <h1>Customer Review Intelligence</h1>
          </div>
        </div>
        <div className="topbar-actions">
          <div className="primary-tabs" role="tablist" aria-label="ReviewLens sections">
            {primarySections.map(({ id, label, icon: Icon }) => (
              <button
                aria-selected={activeSection === id}
                className={activeSection === id ? "primary-tab primary-tab--active" : "primary-tab"}
                key={id}
                onClick={() => setActiveSection(id)}
                role="tab"
                type="button"
              >
                <Icon size={16} aria-hidden="true" />
                <span>{label}</span>
              </button>
            ))}
          </div>
          <div className={`service-pill service-pill--${health.kind}`}>
            <Activity size={16} aria-hidden="true" />
            <span>{statusLabel(health)}</span>
          </div>
        </div>
      </nav>

      {activeSection === "overview" ? (
        <OverviewPanel
          datasetListState={datasetListState}
          datasetName={datasetName}
          datasets={datasets}
          deleteState={deleteState}
          health={health}
          mapping={mapping}
          releaseReadiness={releaseReadiness}
          selectedDatasetId={selectedDatasetId}
          selectedFile={selectedFile}
          uploadState={uploadState}
          onDatasetChange={(datasetId) => {
            setSelectedDatasetId(datasetId);
            resetDatasetScopedState();
          }}
          onDatasetNameChange={setDatasetName}
          onDeleteDataset={handleDeleteSelectedDataset}
          onFileChange={setSelectedFile}
          onLoadDemoDataset={handleLoadDemoDataset}
          onMappingChange={setMapping}
          onUpload={handleUpload}
        />
      ) : null}

      {activeSection === "explore" ? (
        <>
          <ExplorerPanel
            datasets={datasets}
            exploreState={exploreState}
            filters={exploreFilters}
            selectedDatasetId={selectedDatasetId}
            selectedReview={selectedReview}
            onDatasetChange={(datasetId) => {
              setSelectedDatasetId(datasetId);
              resetDatasetScopedState();
            }}
            onFilterChange={updateExploreFilter}
            onReviewSelect={setSelectedReview}
          />
          <ThemeAnalyticsPanel
            compareBy={compareBy}
            compareLimit={compareLimit}
            comparisonState={segmentComparisonState}
            filterOptions={exploreState.kind === "success" ? exploreState.data.filter_options : null}
            leftSegment={leftSegment}
            rightSegment={rightSegment}
            selectedThemeLabel={selectedThemeLabel}
            themeState={themeState}
            onCompare={handleSegmentCompare}
            onCompareByChange={(dimension) => {
              setCompareBy(dimension);
              setLeftSegment("");
              setRightSegment("");
              setSegmentComparisonState({ kind: "idle" });
            }}
            onCompareLimitChange={setCompareLimit}
            onLeftSegmentChange={setLeftSegment}
            onRightSegmentChange={setRightSegment}
            onThemeSelect={setSelectedThemeLabel}
          />
        </>
      ) : null}

      {activeSection === "ask" ? (
        <>
          <RetrievalPanel
            indexState={indexState}
            mode={retrievalMode}
            query={retrievalQuery}
            retrievalState={retrievalState}
            status={retrievalStatus}
            onIndex={handleIndexDataset}
            onModeChange={setRetrievalMode}
            onQueryChange={setRetrievalQuery}
            onSearch={handleRetrievalSearch}
          />
          <AskAnswerPanel
            answerState={answerState}
            answerStyle={answerStyle}
            mode={retrievalMode}
            question={answerQuestion}
            status={retrievalStatus}
            topK={answerTopK}
            onAnswerStyleChange={setAnswerStyle}
            onAsk={handleAskAnswer}
            onCitationOpen={handleCitationOpen}
            onModeChange={setRetrievalMode}
            onQuestionChange={setAnswerQuestion}
            onTopKChange={setAnswerTopK}
          />
        </>
      ) : null}

      {activeSection === "evaluation" ? (
        <>
          <EvaluationPanel
            evaluationState={evaluationState}
            releaseReadiness={releaseReadiness}
            onRunEvaluation={handleRunEvaluation}
          />
          <TrustPanel
            answerState={answerState}
            feedbackNotes={feedbackNotes}
            feedbackState={feedbackState}
            history={answerHistory}
            metrics={qualityMetrics}
            onFeedback={handleFeedback}
            onFeedbackNotesChange={setFeedbackNotes}
            onHistorySelect={handleHistorySelect}
          />
          <details className="secondary-tools">
            <summary>Portfolio exports and action planning</summary>
            <InsightBriefPanel
              briefState={briefState}
              includeSegmentBrief={includeSegmentBrief}
              segmentComparisonReady={segmentComparisonState.kind === "success"}
              title={briefTitle}
              onCopy={handleCopyBrief}
              onDownload={handleDownloadBrief}
              onGenerate={handleGenerateBrief}
              onIncludeSegmentChange={setIncludeSegmentBrief}
              onTitleChange={setBriefTitle}
            />
            <ActionPlanPanel
              actionPlanState={actionPlanState}
              audience={actionAudience}
              includeSegmentActions={includeSegmentActions}
              maxActions={maxActions}
              segmentComparisonReady={segmentComparisonState.kind === "success"}
              onAudienceChange={setActionAudience}
              onCopy={handleCopyActionPlan}
              onDownload={handleDownloadActionPlan}
              onGenerate={handleGenerateActionPlan}
              onIncludeSegmentChange={setIncludeSegmentActions}
              onMaxActionsChange={setMaxActions}
            />
          </details>
        </>
      ) : null}

      {health.kind === "offline" ? <p className="connection-note">{health.message}</p> : null}
    </main>
  );
}

function OverviewPanel({
  datasetListState,
  datasetName,
  datasets,
  deleteState,
  health,
  mapping,
  releaseReadiness,
  selectedDatasetId,
  selectedFile,
  uploadState,
  onDatasetChange,
  onDatasetNameChange,
  onDeleteDataset,
  onFileChange,
  onLoadDemoDataset,
  onMappingChange,
  onUpload
}: {
  datasetListState:
    | { kind: "loading" }
    | { kind: "ready" }
    | { kind: "error"; message: string };
  datasetName: string;
  datasets: DatasetListItem[];
  deleteState:
    | { kind: "idle" }
    | { kind: "deleting" }
    | { kind: "success"; message: string }
    | { kind: "error"; message: string };
  health: HealthState;
  mapping: string;
  releaseReadiness: ReleaseReadinessResponse | null;
  selectedDatasetId: string;
  selectedFile: File | null;
  uploadState:
    | { kind: "idle" }
    | { kind: "uploading" }
    | { kind: "success"; summary: DatasetSummary }
    | { kind: "error"; message: string };
  onDatasetChange: (datasetId: string) => void;
  onDatasetNameChange: (value: string) => void;
  onDeleteDataset: () => void;
  onFileChange: (file: File | null) => void;
  onLoadDemoDataset: () => void;
  onMappingChange: (value: string) => void;
  onUpload: (event: FormEvent<HTMLFormElement>) => void;
}) {
  const selectedDataset = datasets.find((dataset) => dataset.dataset_id === selectedDatasetId);
  const modelConfig = releaseReadiness?.model_configuration;

  return (
    <>
      <section className="workspace-grid" aria-label="ReviewLens workspace">
        <form className="workspace-panel workspace-panel--wide" onSubmit={onUpload}>
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Data Onboarding</p>
              <h2>Upload Review Dataset</h2>
            </div>
            <FileUp size={20} aria-hidden="true" />
          </div>

          <div className="upload-grid">
            <label className="field-control">
              <span>Dataset name</span>
              <input
                value={datasetName}
                onChange={(event) => onDatasetNameChange(event.target.value)}
                placeholder="App store reviews"
              />
            </label>
            <label className="field-control">
              <span>CSV or JSON file</span>
              <input
                accept=".csv,.json,text/csv,application/json"
                onChange={(event) => onFileChange(event.target.files?.[0] ?? null)}
                type="file"
              />
            </label>
          </div>

          <label className="field-control field-control--full">
            <span>Field mapping JSON</span>
            <textarea
              value={mapping}
              onChange={(event) => onMappingChange(event.target.value)}
              placeholder='{"review_text":"comment","rating":"stars","review_date":"date"}'
              rows={3}
            />
          </label>

          <div className="action-row">
            <button className="primary-button" disabled={uploadState.kind === "uploading"} type="submit">
              <FileUp size={16} aria-hidden="true" />
              <span>{uploadState.kind === "uploading" ? "Uploading" : "Upload"}</span>
            </button>
            <button
              className="secondary-button"
              disabled={uploadState.kind === "uploading"}
              onClick={onLoadDemoDataset}
              type="button"
            >
              <PlayCircle size={16} aria-hidden="true" />
              <span>Load demo dataset</span>
            </button>
            <span className="file-note">{selectedFile ? selectedFile.name : "No file selected"}</span>
          </div>

          {uploadState.kind === "success" ? <UploadSummary summary={uploadState.summary} /> : null}
          {uploadState.kind === "error" ? (
            <p className="connection-note connection-note--inline">{uploadState.message}</p>
          ) : null}
        </form>

        <div className="workspace-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Service</p>
              <h2>Readiness</h2>
            </div>
          </div>
          <div className="compact-metrics">
            <StatusMetric label="Backend" value={health.kind === "online" ? "Connected" : "Pending"} />
            <StatusMetric
              label="Datasets"
              value={datasetListState.kind === "loading" ? "Loading" : String(datasets.length)}
            />
            <StatusMetric label="Answer model" value={modelConfig?.answer_model ?? "Loading"} />
          </div>
        </div>
      </section>

      <section className="workspace-grid workspace-grid--datasets" aria-label="Dataset status">
        <div className="workspace-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Datasets</p>
              <h2>Recent Uploads</h2>
            </div>
          </div>
          {datasetListState.kind === "error" ? (
            <p className="connection-note connection-note--inline">{datasetListState.message}</p>
          ) : null}
          <label className="field-control field-control--full">
            <span>Active dataset</span>
            <select
              disabled={!datasets.length}
              onChange={(event) => onDatasetChange(event.target.value)}
              value={selectedDatasetId}
            >
              {datasets.length ? (
                datasets.map((dataset) => (
                  <option key={dataset.dataset_id} value={dataset.dataset_id}>
                    {dataset.name}
                  </option>
                ))
              ) : (
                <option value="">No datasets loaded</option>
              )}
            </select>
          </label>
          <ul className="dataset-list">
            {datasets.length ? (
              datasets.slice(0, 5).map((dataset) => (
                <li key={dataset.dataset_id}>
                  <strong>{dataset.name}</strong>
                  <span>
                    {dataset.accepted_rows}/{dataset.total_rows} accepted / {dataset.duplicate_rows} duplicates
                  </span>
                </li>
              ))
            ) : (
              <li>
                <strong>No datasets</strong>
                <span>Upload history will appear here.</span>
              </li>
            )}
          </ul>
          <div className="action-row action-row--between">
            <button
              className="secondary-button secondary-button--danger"
              disabled={!selectedDatasetId || deleteState.kind === "deleting"}
              onClick={onDeleteDataset}
              type="button"
            >
              <Trash2 size={16} aria-hidden="true" />
              <span>{deleteState.kind === "deleting" ? "Deleting" : "Delete dataset"}</span>
            </button>
            <span className="file-note">{selectedDataset?.filename ?? "No active dataset"}</span>
          </div>
          {deleteState.kind === "success" || deleteState.kind === "error" ? (
            <p className="connection-note connection-note--inline">{deleteState.message}</p>
          ) : null}
        </div>

        <ReleaseReadinessPanel releaseReadiness={releaseReadiness} />
      </section>
    </>
  );
}

function ReleaseReadinessPanel({
  releaseReadiness
}: {
  releaseReadiness: ReleaseReadinessResponse | null;
}) {
  if (!releaseReadiness) {
    return (
      <section className="workspace-panel release-panel" aria-label="Release readiness">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">Release</p>
            <h2>Readiness</h2>
          </div>
          <ShieldCheck size={20} aria-hidden="true" />
        </div>
        <EmptyState title="Release metadata is loading." />
      </section>
    );
  }

  const config = releaseReadiness.model_configuration;
  const cost = releaseReadiness.cost_configuration;

  return (
    <section className="workspace-panel release-panel" aria-label="Release readiness">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Release</p>
          <h2>Models, Privacy, Cost</h2>
        </div>
        <ShieldCheck size={20} aria-hidden="true" />
      </div>
      <div className="compact-metrics compact-metrics--two">
        <StatusMetric label="Embedding" value={`${config.embedding_provider}: ${config.embedding_model}`} />
        <StatusMetric label="Answering" value={`${config.answer_provider}: ${config.answer_model}`} />
        <StatusMetric label="OpenAI key" value={config.openai_configured ? "Configured" : "Not configured"} />
        <StatusMetric label="Cost rates" value={cost.answer_output_cost_per_1k_tokens_usd ? "Configured" : "Local / zero"} />
      </div>
      <Checklist title="Privacy" items={releaseReadiness.privacy} />
      <Checklist title="Security" items={releaseReadiness.security} />
      <Checklist title="Limits" items={releaseReadiness.limits} />
      <Checklist title="Known Limitations" items={releaseReadiness.limitations} />
    </section>
  );
}

function EvaluationPanel({
  evaluationState,
  releaseReadiness,
  onRunEvaluation
}: {
  evaluationState:
    | { kind: "idle" }
    | { kind: "running" }
    | { kind: "success"; data: EvaluationRunResponse }
    | { kind: "error"; message: string };
  releaseReadiness: ReleaseReadinessResponse | null;
  onRunEvaluation: () => void;
}) {
  const report = evaluationState.kind === "success" ? evaluationState.data : null;

  return (
    <section className="workspace-panel evaluation-panel" aria-label="Evaluation">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Evaluation</p>
          <h2>Golden Scorecard</h2>
        </div>
        <button
          className="primary-button"
          disabled={evaluationState.kind === "running"}
          onClick={onRunEvaluation}
          type="button"
        >
          <PlayCircle size={16} aria-hidden="true" />
          <span>{evaluationState.kind === "running" ? "Running" : "Run Evaluation"}</span>
        </button>
      </div>

      {evaluationState.kind === "error" ? (
        <p className="connection-note connection-note--inline">{evaluationState.message}</p>
      ) : null}

      {report ? (
        <div className="evaluation-result">
          <div className="compact-metrics compact-metrics--four">
            <StatusMetric label="Run" value={report.version} />
            <StatusMetric label="Questions" value={String(report.total_questions)} />
            <StatusMetric label="Overall" value={`${Math.round(report.overall_score * 100)}%`} />
            <StatusMetric label="P95 latency" value={`${report.p95_latency_ms.toFixed(1)} ms`} />
          </div>
          <ul className="metric-bucket-grid" aria-label="Evaluation metrics">
            {report.metrics.map((metric) => (
              <li key={metric.name}>
                <strong>{metric.name}</strong>
                <span>
                  {metric.passed}/{metric.total} passed - {Math.round(metric.score * 100)}%
                </span>
              </li>
            ))}
          </ul>
          <Checklist
            title="Release Checklist"
            items={releaseReadiness?.release_checklist ?? ["Release metadata is loading."]}
          />
        </div>
      ) : (
        <div className="evaluation-result">
          <EmptyState title="Run the golden evaluation to produce a reproducible scorecard." />
          <Checklist
            title="Release Checklist"
            items={releaseReadiness?.release_checklist ?? ["Release metadata is loading."]}
          />
        </div>
      )}
    </section>
  );
}

function Checklist({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="checklist-block">
      <h3>{title}</h3>
      <ul className="limitations-list">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

function StatusMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="status-metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function UploadSummary({ summary }: { summary: DatasetSummary }) {
  return (
    <section className="upload-summary" aria-label="Upload summary">
      <div className="status-board status-board--compact">
        <StatusMetric label="Accepted" value={String(summary.accepted_rows)} />
        <StatusMetric label="Rejected" value={String(summary.rejected_rows)} />
        <StatusMetric label="Duplicates" value={String(summary.duplicate_rows)} />
      </div>

      {summary.errors_preview.length ? (
        <div className="error-preview">
          <div className="panel-heading panel-heading--tight">
            <h3>Rejected Rows</h3>
            <AlertCircle size={18} aria-hidden="true" />
          </div>
          <ul>
            {summary.errors_preview.map((error) => (
              <li key={`${error.row_number}-${error.error_code}`}>
                <span>Row {error.row_number}</span>
                <strong>{error.message}</strong>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </section>
  );
}

function ExplorerPanel({
  datasets,
  exploreState,
  filters,
  selectedDatasetId,
  selectedReview,
  onDatasetChange,
  onFilterChange,
  onReviewSelect
}: {
  datasets: DatasetListItem[];
  exploreState:
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: DatasetExploreResponse }
    | { kind: "error"; message: string };
  filters: ExploreFilters;
  selectedDatasetId: string;
  selectedReview: ReviewListItem | null;
  onDatasetChange: (datasetId: string) => void;
  onFilterChange: (key: keyof ExploreFilters, value: string) => void;
  onReviewSelect: (review: ReviewListItem) => void;
}) {
  const data = exploreState.kind === "success" ? exploreState.data : null;
  const options = data?.filter_options;

  return (
    <section className="workspace-panel explorer-panel" aria-label="Review explorer">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Explore Reviews</p>
          <h2>Dataset Investigation</h2>
        </div>
        <BarChart3 size={20} aria-hidden="true" />
      </div>

      <div className="explorer-controls">
        <label className="field-control">
          <span>Dataset</span>
          <select
            value={selectedDatasetId}
            onChange={(event) => onDatasetChange(event.target.value)}
          >
            <option value="">Select dataset</option>
            {datasets.map((dataset) => (
              <option key={dataset.dataset_id} value={dataset.dataset_id}>
                {dataset.name}
              </option>
            ))}
          </select>
        </label>
        <label className="field-control">
          <span>Search text</span>
          <div className="input-with-icon">
            <Search size={15} aria-hidden="true" />
            <input
              value={filters.query ?? ""}
              onChange={(event) => onFilterChange("query", event.target.value)}
              placeholder="login, export, crash"
            />
          </div>
        </label>
        <label className="field-control">
          <span>Rating min</span>
          <input
            min="0"
            max="5"
            step="1"
            type="number"
            value={filters.ratingMin ?? ""}
            onChange={(event) => onFilterChange("ratingMin", event.target.value)}
          />
        </label>
        <label className="field-control">
          <span>Rating max</span>
          <input
            min="0"
            max="5"
            step="1"
            type="number"
            value={filters.ratingMax ?? ""}
            onChange={(event) => onFilterChange("ratingMax", event.target.value)}
          />
        </label>
        <label className="field-control">
          <span>Date from</span>
          <input
            type="date"
            value={filters.dateFrom ?? ""}
            onChange={(event) => onFilterChange("dateFrom", event.target.value)}
          />
        </label>
        <label className="field-control">
          <span>Date to</span>
          <input
            type="date"
            value={filters.dateTo ?? ""}
            onChange={(event) => onFilterChange("dateTo", event.target.value)}
          />
        </label>
        <FilterSelect
          label="Product"
          options={options?.product_names ?? []}
          value={filters.productName ?? ""}
          onChange={(value) => onFilterChange("productName", value)}
        />
        <FilterSelect
          label="Source"
          options={options?.sources ?? []}
          value={filters.source ?? ""}
          onChange={(value) => onFilterChange("source", value)}
        />
        <FilterSelect
          label="Region"
          options={options?.regions ?? []}
          value={filters.region ?? ""}
          onChange={(value) => onFilterChange("region", value)}
        />
        <FilterSelect
          label="Segment"
          options={options?.customer_segments ?? []}
          value={filters.customerSegment ?? ""}
          onChange={(value) => onFilterChange("customerSegment", value)}
        />
      </div>

      {exploreState.kind === "idle" ? <EmptyState title="Upload or select a dataset." /> : null}
      {exploreState.kind === "loading" ? <EmptyState title="Loading review explorer." /> : null}
      {exploreState.kind === "error" ? <EmptyState title={exploreState.message} /> : null}
      {data ? (
        <div className="explorer-content">
          <div className="status-board status-board--compact">
            <StatusMetric label="Filtered" value={String(data.metrics.filtered_reviews)} />
            <StatusMetric
              label="Avg rating"
              value={data.metrics.average_rating === null ? "N/A" : String(data.metrics.average_rating)}
            />
            <StatusMetric label="Rated" value={String(data.metrics.rated_reviews)} />
          </div>

          <div className="explorer-analytics">
            <RatingDistribution buckets={data.rating_distribution} />
            <VolumeTrend points={data.volume_trend} />
          </div>

          <div className="review-workspace">
            <ReviewTable
              reviews={data.reviews}
              selectedReviewId={selectedReview?.id ?? ""}
              onReviewSelect={onReviewSelect}
            />
            <ReviewDetail review={selectedReview} />
          </div>
        </div>
      ) : null}
    </section>
  );
}

function AskAnswerPanel({
  answerState,
  answerStyle,
  mode,
  question,
  status,
  topK,
  onAnswerStyleChange,
  onAsk,
  onCitationOpen,
  onModeChange,
  onQuestionChange,
  onTopKChange
}: {
  answerState:
    | { kind: "idle" }
    | { kind: "answering" }
    | { kind: "success"; data: AnswerResponse }
    | { kind: "error"; message: string };
  answerStyle: AnswerStyle;
  mode: "keyword" | "semantic" | "hybrid";
  question: string;
  status: RetrievalStatusResponse | null;
  topK: string;
  onAnswerStyleChange: (style: AnswerStyle) => void;
  onAsk: () => void;
  onCitationOpen: (citation: AnswerCitation) => void;
  onModeChange: (mode: "keyword" | "semantic" | "hybrid") => void;
  onQuestionChange: (question: string) => void;
  onTopKChange: (topK: string) => void;
}) {
  const answer = answerState.kind === "success" ? answerState.data : null;

  return (
    <section className="workspace-panel ask-panel" aria-label="Ask ReviewLens">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Grounded Q&A</p>
          <h2>Ask ReviewLens</h2>
        </div>
        <Sparkles size={20} aria-hidden="true" />
      </div>

      <form
        className="ask-form"
        onSubmit={(event) => {
          event.preventDefault();
          onAsk();
        }}
      >
        <label className="field-control field-control--full">
          <span>Question</span>
          <textarea
            value={question}
            onChange={(event) => onQuestionChange(event.target.value)}
            placeholder="Why are customers complaining about login?"
            rows={3}
          />
        </label>
        <div className="ask-controls">
          <label className="field-control">
            <span>Answer style</span>
            <select
              value={answerStyle}
              onChange={(event) => onAnswerStyleChange(event.target.value as AnswerStyle)}
            >
              <option value="summary">Executive summary</option>
              <option value="issues">Product issues</option>
              <option value="sentiment">Customer sentiment</option>
              <option value="root_cause">Root-cause hints</option>
            </select>
          </label>
          <label className="field-control">
            <span>Retrieval mode</span>
            <select
              value={mode}
              onChange={(event) =>
                onModeChange(event.target.value as "keyword" | "semantic" | "hybrid")
              }
            >
              <option value="hybrid">Hybrid</option>
              <option value="semantic">Semantic</option>
              <option value="keyword">Keyword</option>
            </select>
          </label>
          <label className="field-control">
            <span>Evidence count</span>
            <select value={topK} onChange={(event) => onTopKChange(event.target.value)}>
              <option value="5">5</option>
              <option value="8">8</option>
              <option value="12">12</option>
            </select>
          </label>
          <button className="primary-button ask-button" disabled={answerState.kind === "answering"} type="submit">
            <Sparkles size={16} aria-hidden="true" />
            <span>{answerState.kind === "answering" ? "Answering" : "Ask"}</span>
          </button>
        </div>
      </form>

      {status && status.status !== "indexed" ? (
        <p className="muted-copy">Index status is {status.status}; answers may rely on fallback evidence.</p>
      ) : null}

      {answerState.kind === "idle" ? (
        <EmptyState title="Ask a question about the selected dataset." />
      ) : null}
      {answerState.kind === "answering" ? <EmptyState title="Answering with cited evidence." /> : null}
      {answerState.kind === "error" ? <EmptyState title={answerState.message} /> : null}
      {answer ? (
        <div className="answer-result">
          <div className="answer-header">
            <div>
              <span className={`confidence-badge confidence-badge--${answer.confidence}`}>
                {answer.confidence} / {answer.confidence_score}
              </span>
              <span className="muted-copy">
                {answer.evidence_count} citations / {answer.filtered_review_count} filtered reviews
              </span>
            </div>
            <span className="muted-copy">index {answer.index_status}</span>
          </div>

          <div className="route-summary">
            <span>{routeLabel(answer.route)}</span>
            {answer.analytics.map((analytic) => (
              <strong key={analytic.label}>
                {analytic.label}: {analytic.value}
              </strong>
            ))}
          </div>

          <p className="answer-body">{answer.answer}</p>

          {answer.analytics.length ? (
            <ul className="analytics-list" aria-label="Deterministic analytics">
              {answer.analytics.map((analytic) => (
                <li key={analytic.label}>
                  <strong>{analytic.label}</strong>
                  <span>{analytic.details}</span>
                </li>
              ))}
            </ul>
          ) : null}

          {answer.comparison ? <ComparisonSummary comparison={answer.comparison} /> : null}

          {answer.themes.length ? (
            <ul className="theme-list" aria-label="Answer themes">
              {answer.themes.map((theme) => (
                <li key={theme.label}>
                  <strong>{theme.label}</strong>
                  <span>{theme.count}</span>
                </li>
              ))}
            </ul>
          ) : null}

          {answer.limitations.length ? (
            <ul className="limitations-list" aria-label="Answer limitations">
              {answer.limitations.map((limitation) => (
                <li key={limitation}>{limitation}</li>
              ))}
            </ul>
          ) : null}

          <div className="citation-list">
            {answer.citations.length ? (
              answer.citations.map((citation) => (
                <CitationCard
                  citation={citation}
                  key={citation.citation_id}
                  onOpenSource={onCitationOpen}
                />
              ))
            ) : answer.route === "analytics" ? null : (
              <EmptyState title="No cited source reviews for this answer." />
            )}
          </div>
        </div>
      ) : null}
    </section>
  );
}

function TrustPanel({
  answerState,
  feedbackNotes,
  feedbackState,
  history,
  metrics,
  onFeedback,
  onFeedbackNotesChange,
  onHistorySelect
}: {
  answerState:
    | { kind: "idle" }
    | { kind: "answering" }
    | { kind: "success"; data: AnswerResponse }
    | { kind: "error"; message: string };
  feedbackNotes: string;
  feedbackState:
    | { kind: "idle" }
    | { kind: "saving" }
    | { kind: "success"; message: string }
    | { kind: "error"; message: string };
  history: AnswerRunSummary[];
  metrics: ObservabilityMetricsResponse | null;
  onFeedback: (rating: "useful" | "incorrect" | "unsupported") => void;
  onFeedbackNotesChange: (notes: string) => void;
  onHistorySelect: (answerId: string) => void;
}) {
  const activeAnswer = answerState.kind === "success" ? answerState.data : null;

  return (
    <section className="workspace-grid trust-grid" aria-label="Trust and evaluation">
      <div className="workspace-panel trust-panel">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">Trust & Evaluation</p>
            <h2>Answer Feedback</h2>
          </div>
          <ShieldCheck size={20} aria-hidden="true" />
        </div>

        {activeAnswer ? (
          <div className="feedback-box">
            <div className="quality-inline">
              <StatusMetric label="Confidence" value={`${activeAnswer.confidence_score}`} />
              <StatusMetric label="Citations" value={String(activeAnswer.evidence_count)} />
              <StatusMetric label="Limitations" value={String(activeAnswer.limitations.length)} />
            </div>
            <div className="feedback-actions">
              <button
                className="secondary-button"
                disabled={feedbackState.kind === "saving"}
                onClick={() => onFeedback("useful")}
                type="button"
              >
                Useful
              </button>
              <button
                className="secondary-button"
                disabled={feedbackState.kind === "saving"}
                onClick={() => onFeedback("incorrect")}
                type="button"
              >
                Incorrect
              </button>
              <button
                className="secondary-button"
                disabled={feedbackState.kind === "saving"}
                onClick={() => onFeedback("unsupported")}
                type="button"
              >
                Unsupported
              </button>
            </div>
            <label className="field-control field-control--full">
              <span>Feedback notes</span>
              <textarea
                value={feedbackNotes}
                onChange={(event) => onFeedbackNotesChange(event.target.value)}
                placeholder="Optional note"
                rows={2}
              />
            </label>
            {feedbackState.kind === "success" ? (
              <p className="muted-copy">{feedbackState.message}</p>
            ) : null}
            {feedbackState.kind === "error" ? (
              <p className="connection-note connection-note--inline">{feedbackState.message}</p>
            ) : null}
          </div>
        ) : (
          <EmptyState title="Generate an answer to record feedback." />
        )}
      </div>

      <div className="workspace-panel trust-panel">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">Quality Metrics</p>
            <h2>Grounding Snapshot</h2>
          </div>
        </div>
        {metrics ? <QualityMetrics metrics={metrics} /> : <EmptyState title="No metrics loaded." />}
      </div>

      <div className="workspace-panel trust-panel trust-panel--wide">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">History</p>
            <h2>Recent Answers</h2>
          </div>
        </div>
        {history.length ? (
          <ol className="answer-history">
            {history.map((item) => (
              <li key={item.answer_id}>
                <button onClick={() => onHistorySelect(item.answer_id)} type="button">
                  <strong>{item.question}</strong>
                  <span>
                    {item.confidence} / {item.confidence_score} / {item.evidence_count} citations
                  </span>
                  <small>{item.feedback_rating ?? "No feedback"}</small>
                </button>
              </li>
            ))}
          </ol>
        ) : (
          <EmptyState title="Answer history will appear here." />
        )}
      </div>
    </section>
  );
}

function ThemeAnalyticsPanel({
  compareBy,
  compareLimit,
  comparisonState,
  filterOptions,
  leftSegment,
  rightSegment,
  selectedThemeLabel,
  themeState,
  onCompare,
  onCompareByChange,
  onCompareLimitChange,
  onLeftSegmentChange,
  onRightSegmentChange,
  onThemeSelect
}: {
  compareBy: ThemeCompareDimension;
  compareLimit: string;
  comparisonState:
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: SegmentThemeComparisonResponse }
    | { kind: "error"; message: string };
  filterOptions: DatasetExploreResponse["filter_options"] | null;
  leftSegment: string;
  rightSegment: string;
  selectedThemeLabel: string;
  themeState:
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: DatasetThemesResponse }
    | { kind: "error"; message: string };
  onCompare: () => void;
  onCompareByChange: (dimension: ThemeCompareDimension) => void;
  onCompareLimitChange: (limit: string) => void;
  onLeftSegmentChange: (value: string) => void;
  onRightSegmentChange: (value: string) => void;
  onThemeSelect: (label: string) => void;
}) {
  const data = themeState.kind === "success" ? themeState.data : null;
  const selectedTheme =
    data?.themes.find((theme) => theme.label === selectedThemeLabel) ?? data?.themes[0] ?? null;

  return (
    <section className="workspace-panel themes-panel" aria-label="Theme analytics">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Theme Analytics</p>
          <h2>Recurring Drivers</h2>
        </div>
        <BarChart3 size={20} aria-hidden="true" />
      </div>

      {themeState.kind === "idle" ? <EmptyState title="Select a dataset to analyze themes." /> : null}
      {themeState.kind === "loading" ? <EmptyState title="Analyzing review themes." /> : null}
      {themeState.kind === "error" ? <EmptyState title={themeState.message} /> : null}
      {data ? (
        <div className="themes-layout">
          <div className="theme-summary">
            <div className="quality-inline">
              <StatusMetric label="Analyzed" value={String(data.analyzed_reviews)} />
              <StatusMetric label="Coverage" value={`${Math.round(data.theme_coverage * 100)}%`} />
              <StatusMetric label="Themes" value={String(data.themes.length)} />
            </div>
            <SentimentStrip buckets={data.sentiment_distribution} />
            <ThemeLeaderboard
              selectedLabel={selectedTheme?.label ?? ""}
              themes={data.themes}
              onThemeSelect={onThemeSelect}
            />
          </div>

          <div className="theme-detail-panel">
            {selectedTheme ? (
              <ThemeDetail theme={selectedTheme} />
            ) : (
              <EmptyState title="No configured theme matched this filtered review set." />
            )}
          </div>

          <div className="theme-comparison-panel">
            <h3>Period Comparison</h3>
            {data.comparison ? (
              <div>
                <p className="muted-copy">
                  {data.comparison.previous_start} to {data.comparison.previous_end} vs{" "}
                  {data.comparison.current_start} to {data.comparison.current_end}
                </p>
                <ol className="comparison-list">
                  {data.comparison.items.map((item) => (
                    <li key={item.label}>
                      <strong>{item.label}</strong>
                      <span>
                        {item.previous_count} to {item.current_count} / delta{" "}
                        {Math.round(item.delta_share * 100)}%
                      </span>
                    </li>
                  ))}
                </ol>
              </div>
            ) : (
              <p className="muted-copy">Select Date from and Date to to compare with the prior period.</p>
            )}
          </div>

          <SegmentComparisonPanel
            compareBy={compareBy}
            compareLimit={compareLimit}
            comparisonState={comparisonState}
            filterOptions={filterOptions}
            leftSegment={leftSegment}
            rightSegment={rightSegment}
            onCompare={onCompare}
            onCompareByChange={onCompareByChange}
            onCompareLimitChange={onCompareLimitChange}
            onLeftSegmentChange={onLeftSegmentChange}
            onRightSegmentChange={onRightSegmentChange}
          />

          {data.limitations.length ? (
            <ul className="limitations-list themes-limitations" aria-label="Theme limitations">
              {data.limitations.map((limitation) => (
                <li key={limitation}>{limitation}</li>
              ))}
            </ul>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function SentimentStrip({ buckets }: { buckets: { label: string; count: number; share: number }[] }) {
  if (!buckets.length) {
    return <p className="muted-copy">No rated sentiment buckets in this filtered set.</p>;
  }

  return (
    <ul className="sentiment-strip" aria-label="Sentiment distribution">
      {buckets.map((bucket) => (
        <li key={bucket.label}>
          <strong>{bucket.label}</strong>
          <span>
            {bucket.count} / {Math.round(bucket.share * 100)}%
          </span>
        </li>
      ))}
    </ul>
  );
}

function SegmentComparisonPanel({
  compareBy,
  compareLimit,
  comparisonState,
  filterOptions,
  leftSegment,
  rightSegment,
  onCompare,
  onCompareByChange,
  onCompareLimitChange,
  onLeftSegmentChange,
  onRightSegmentChange
}: {
  compareBy: ThemeCompareDimension;
  compareLimit: string;
  comparisonState:
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: SegmentThemeComparisonResponse }
    | { kind: "error"; message: string };
  filterOptions: DatasetExploreResponse["filter_options"] | null;
  leftSegment: string;
  rightSegment: string;
  onCompare: () => void;
  onCompareByChange: (dimension: ThemeCompareDimension) => void;
  onCompareLimitChange: (limit: string) => void;
  onLeftSegmentChange: (value: string) => void;
  onRightSegmentChange: (value: string) => void;
}) {
  const options = segmentOptions(compareBy, filterOptions);

  return (
    <div className="segment-comparison-panel">
      <div className="panel-heading panel-heading--tight">
        <h3>Segment Comparison</h3>
        <span className="muted-copy">Using current explorer filters</span>
      </div>
      <div className="segment-controls">
        <label className="field-control">
          <span>Compare by</span>
          <select
            value={compareBy}
            onChange={(event) => onCompareByChange(event.target.value as ThemeCompareDimension)}
          >
            <option value="region">Region</option>
            <option value="country">Country</option>
            <option value="source">Source</option>
            <option value="product_name">Product</option>
            <option value="product_version">Product version</option>
            <option value="platform">Platform</option>
            <option value="customer_segment">Customer segment</option>
            <option value="channel">Channel</option>
          </select>
        </label>
        <SegmentValueControl
          label="Left segment"
          options={options}
          value={leftSegment}
          onChange={onLeftSegmentChange}
        />
        <SegmentValueControl
          label="Right segment"
          options={options}
          value={rightSegment}
          onChange={onRightSegmentChange}
        />
        <label className="field-control">
          <span>Theme limit</span>
          <select value={compareLimit} onChange={(event) => onCompareLimitChange(event.target.value)}>
            <option value="3">3</option>
            <option value="5">5</option>
            <option value="8">8</option>
            <option value="10">10</option>
          </select>
        </label>
        <button className="primary-button" onClick={onCompare} type="button">
          Compare
        </button>
      </div>

      {comparisonState.kind === "idle" ? <EmptyState title="Choose two segments to compare." /> : null}
      {comparisonState.kind === "loading" ? <EmptyState title="Comparing theme drivers." /> : null}
      {comparisonState.kind === "error" ? <EmptyState title={comparisonState.message} /> : null}
      {comparisonState.kind === "success" ? (
        <SegmentComparisonResult data={comparisonState.data} />
      ) : null}
    </div>
  );
}

function SegmentValueControl({
  label,
  options,
  value,
  onChange
}: {
  label: string;
  options: string[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="field-control">
      <span>{label}</span>
      {options.length ? (
        <select value={value} onChange={(event) => onChange(event.target.value)}>
          <option value="">Select</option>
          {options.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
          <option value="Unknown">Unknown</option>
        </select>
      ) : (
        <input value={value} onChange={(event) => onChange(event.target.value)} placeholder="Value" />
      )}
    </label>
  );
}

function SegmentComparisonResult({ data }: { data: SegmentThemeComparisonResponse }) {
  return (
    <div className="segment-result">
      <SegmentSummaryCard segment={data.left} />
      <SegmentSummaryCard segment={data.right} />
      <div className="segment-deltas">
        <h3>Deltas</h3>
        {data.deltas.length ? (
          <ol className="comparison-list">
            {data.deltas.map((delta) => (
              <li key={delta.label}>
                <strong>{delta.label}</strong>
                <span>
                  {Math.round(delta.left_share * 100)}% vs {Math.round(delta.right_share * 100)}%
                </span>
                <small className={`delta-badge delta-badge--${delta.direction}`}>
                  {delta.direction.replace("_", " ")}
                </small>
                <p className="muted-copy">{delta.summary}</p>
              </li>
            ))}
          </ol>
        ) : (
          <EmptyState title="No theme deltas found for these segments." />
        )}
      </div>
      {data.limitations.length ? (
        <ul className="limitations-list segment-limitations" aria-label="Segment limitations">
          {data.limitations.map((limitation) => (
            <li key={limitation}>{limitation}</li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

function SegmentSummaryCard({ segment }: { segment: SegmentThemeComparisonResponse["left"] }) {
  return (
    <article className="segment-card">
      <h3>{segment.segment}</h3>
      <div className="quality-inline">
        <StatusMetric label="Reviews" value={String(segment.review_count)} />
        <StatusMetric
          label="Avg rating"
          value={segment.average_rating === null ? "N/A" : String(segment.average_rating)}
        />
        <StatusMetric label="Negative" value={`${Math.round(segment.negative_rate * 100)}%`} />
      </div>
      <SentimentStrip buckets={segment.sentiment_distribution} />
      <ol className="segment-theme-list">
        {segment.top_themes.map((theme) => (
          <li key={theme.label}>
            <strong>{theme.label}</strong>
            <span>
              {theme.count} reviews / {Math.round(theme.share * 100)}%
            </span>
          </li>
        ))}
      </ol>
    </article>
  );
}

function segmentOptions(
  compareBy: ThemeCompareDimension,
  filterOptions: DatasetExploreResponse["filter_options"] | null
) {
  if (!filterOptions) {
    return [];
  }
  const optionMap: Record<ThemeCompareDimension, string[]> = {
    source: filterOptions.sources,
    region: filterOptions.regions,
    country: filterOptions.countries,
    product_name: filterOptions.product_names,
    product_version: filterOptions.product_versions,
    platform: filterOptions.platforms,
    customer_segment: filterOptions.customer_segments,
    channel: filterOptions.channels
  };
  return optionMap[compareBy] ?? [];
}

function withoutComparisonFilter(filters: ExploreFilters, compareBy: ThemeCompareDimension) {
  const next = { ...filters };
  const filterKeys: Record<ThemeCompareDimension, keyof ExploreFilters> = {
    source: "source",
    region: "region",
    country: "country",
    product_name: "productName",
    product_version: "productVersion",
    platform: "platform",
    customer_segment: "customerSegment",
    channel: "channel"
  };
  delete next[filterKeys[compareBy]];
  return next;
}

function ThemeLeaderboard({
  selectedLabel,
  themes,
  onThemeSelect
}: {
  selectedLabel: string;
  themes: DatasetThemesResponse["themes"];
  onThemeSelect: (label: string) => void;
}) {
  if (!themes.length) {
    return <EmptyState title="No themes to rank." />;
  }

  const maxRisk = Math.max(...themes.map((theme) => theme.risk_score), 1);
  return (
    <ol className="theme-leaderboard">
      {themes.map((theme) => (
        <li key={theme.label}>
          <button
            className={theme.label === selectedLabel ? "theme-row theme-row--selected" : "theme-row"}
            onClick={() => onThemeSelect(theme.label)}
            type="button"
          >
            <span>
              <strong>{theme.label}</strong>
              <small>
                {theme.count} reviews / avg {theme.average_rating ?? "N/A"} / risk{" "}
                {theme.risk_score.toFixed(1)}
              </small>
            </span>
            <i style={{ width: `${(theme.risk_score / maxRisk) * 100}%` }} />
          </button>
        </li>
      ))}
    </ol>
  );
}

function ThemeDetail({ theme }: { theme: DatasetThemesResponse["themes"][number] }) {
  return (
    <article className="theme-detail">
      <div className="answer-header">
        <div>
          <span className="confidence-badge confidence-badge--medium">
            risk {theme.risk_score.toFixed(1)}
          </span>
          <span className="muted-copy">
            {Math.round(theme.share * 100)}% of filtered reviews
          </span>
        </div>
        <span className="muted-copy">{theme.negative_count} negative</span>
      </div>
      <h3>{theme.label}</h3>
      <p className="muted-copy">Keywords: {theme.keywords.slice(0, 6).join(", ")}</p>
      <div className="theme-samples">
        {theme.samples.map((sample) => (
          <article className="citation-card" key={sample.review_id}>
            <div className="citation-index">
              <strong>{sample.row_number}</strong>
              <span>{sample.rating ?? "N/A"}</span>
            </div>
            <div>
              <p>{sample.review_text}</p>
              <dl>
                <div>
                  <dt>Date</dt>
                  <dd>{sample.review_date ?? "N/A"}</dd>
                </div>
                <div>
                  <dt>Source</dt>
                  <dd>{sample.source ?? "N/A"}</dd>
                </div>
                <div>
                  <dt>Product</dt>
                  <dd>{sample.product_name ?? "N/A"}</dd>
                </div>
              </dl>
            </div>
          </article>
        ))}
      </div>
    </article>
  );
}

function QualityMetrics({ metrics }: { metrics: ObservabilityMetricsResponse }) {
  return (
    <div className="quality-panel">
      <div className="quality-inline">
        <StatusMetric label="Answers" value={String(metrics.answer_count)} />
        <StatusMetric
          label="Avg conf"
          value={metrics.average_confidence_score === null ? "N/A" : String(metrics.average_confidence_score)}
        />
        <StatusMetric
          label="No evidence"
          value={`${Math.round(metrics.no_evidence_rate * 100)}%`}
        />
      </div>
      <MetricBucketList title="Confidence" buckets={metrics.confidence_distribution} />
      <MetricBucketList title="Feedback" buckets={metrics.feedback_distribution} />
      <MetricBucketList title="Top themes" buckets={metrics.top_themes} />
    </div>
  );
}

function InsightBriefPanel({
  briefState,
  includeSegmentBrief,
  segmentComparisonReady,
  title,
  onCopy,
  onDownload,
  onGenerate,
  onIncludeSegmentChange,
  onTitleChange
}: {
  briefState:
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: InsightReportResponse; copyState: "idle" | "copied" | "error" }
    | { kind: "error"; message: string };
  includeSegmentBrief: boolean;
  segmentComparisonReady: boolean;
  title: string;
  onCopy: () => void;
  onDownload: () => void;
  onGenerate: () => void;
  onIncludeSegmentChange: (checked: boolean) => void;
  onTitleChange: (title: string) => void;
}) {
  return (
    <section className="workspace-panel brief-panel" aria-label="Insight brief export">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Export</p>
          <h2>Insight Brief</h2>
        </div>
        <FileText size={20} aria-hidden="true" />
      </div>

      <div className="brief-controls">
        <label className="field-control brief-title-control">
          <span>Brief title</span>
          <input
            onChange={(event) => onTitleChange(event.target.value)}
            placeholder="Weekly ReviewLens Brief"
            value={title}
          />
        </label>
        <label className="toggle-control">
          <input
            checked={includeSegmentBrief}
            disabled={!segmentComparisonReady}
            onChange={(event) => onIncludeSegmentChange(event.target.checked)}
            type="checkbox"
          />
          <span>Include segment comparison</span>
        </label>
        <button
          className="primary-button"
          disabled={briefState.kind === "loading"}
          onClick={onGenerate}
          type="button"
        >
          <FileText size={16} aria-hidden="true" />
          <span>{briefState.kind === "loading" ? "Generating" : "Generate brief"}</span>
        </button>
      </div>

      {briefState.kind === "idle" ? (
        <EmptyState title="Generate a shareable brief from the current investigation." />
      ) : null}
      {briefState.kind === "loading" ? <EmptyState title="Preparing insight brief." /> : null}
      {briefState.kind === "error" ? <EmptyState title={briefState.message} /> : null}
      {briefState.kind === "success" ? (
        <article className="brief-result">
          <div className="brief-result-header">
            <div>
              <p className="eyebrow">Generated Brief</p>
              <h3>{briefState.data.title}</h3>
              <span className="muted-copy">
                {briefState.data.metrics.filtered_reviews} filtered reviews /{" "}
                {briefState.data.top_themes.length} themes / {briefState.data.recent_answers.length} answers
              </span>
            </div>
            <div className="brief-actions">
              <button className="secondary-button" onClick={onCopy} type="button">
                <Clipboard size={16} aria-hidden="true" />
                <span>
                  {briefState.copyState === "copied"
                    ? "Copied"
                    : briefState.copyState === "error"
                      ? "Copy failed"
                      : "Copy"}
                </span>
              </button>
              <button className="secondary-button" onClick={onDownload} type="button">
                <Download size={16} aria-hidden="true" />
                <span>Download .md</span>
              </button>
            </div>
          </div>

          <ul className="brief-summary-list">
            {briefState.data.sections.slice(0, 3).map((section) => (
              <li key={section.title}>
                <strong>{section.title}</strong>
                <span>{section.summary}</span>
              </li>
            ))}
          </ul>

          {briefState.data.limitations.length ? (
            <ul className="limitations-list" aria-label="Brief limitations">
              {briefState.data.limitations.map((limitation) => (
                <li key={limitation}>{limitation}</li>
              ))}
            </ul>
          ) : null}

          <pre className="brief-preview">{briefState.data.markdown}</pre>
        </article>
      ) : null}
    </section>
  );
}

function ActionPlanPanel({
  actionPlanState,
  audience,
  includeSegmentActions,
  maxActions,
  segmentComparisonReady,
  onAudienceChange,
  onCopy,
  onDownload,
  onGenerate,
  onIncludeSegmentChange,
  onMaxActionsChange
}: {
  actionPlanState:
    | { kind: "idle" }
    | { kind: "loading" }
    | { kind: "success"; data: ActionPlanResponse; copyState: "idle" | "copied" | "error" }
    | { kind: "error"; message: string };
  audience: ActionPlanAudience;
  includeSegmentActions: boolean;
  maxActions: string;
  segmentComparisonReady: boolean;
  onAudienceChange: (audience: ActionPlanAudience) => void;
  onCopy: () => void;
  onDownload: () => void;
  onGenerate: () => void;
  onIncludeSegmentChange: (checked: boolean) => void;
  onMaxActionsChange: (value: string) => void;
}) {
  return (
    <section className="workspace-panel action-plan-panel" aria-label="Action plan">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Prioritization</p>
          <h2>Action Plan</h2>
        </div>
        <Sparkles size={20} aria-hidden="true" />
      </div>

      <div className="action-plan-controls">
        <label className="field-control">
          <span>Audience</span>
          <select
            value={audience}
            onChange={(event) => onAudienceChange(event.target.value as ActionPlanAudience)}
          >
            <option value="product">Product</option>
            <option value="support">Support</option>
            <option value="leadership">Leadership</option>
          </select>
        </label>
        <label className="field-control">
          <span>Max actions</span>
          <input
            min="1"
            max="10"
            onChange={(event) => onMaxActionsChange(event.target.value)}
            type="number"
            value={maxActions}
          />
        </label>
        <label className="toggle-control">
          <input
            checked={includeSegmentActions}
            disabled={!segmentComparisonReady}
            onChange={(event) => onIncludeSegmentChange(event.target.checked)}
            type="checkbox"
          />
          <span>Use segment comparison</span>
        </label>
        <button
          className="primary-button"
          disabled={actionPlanState.kind === "loading"}
          onClick={onGenerate}
          type="button"
        >
          <Sparkles size={16} aria-hidden="true" />
          <span>{actionPlanState.kind === "loading" ? "Generating" : "Generate actions"}</span>
        </button>
      </div>

      {actionPlanState.kind === "idle" ? (
        <EmptyState title="Generate prioritized product and support actions from current review signals." />
      ) : null}
      {actionPlanState.kind === "loading" ? <EmptyState title="Prioritizing actions." /> : null}
      {actionPlanState.kind === "error" ? <EmptyState title={actionPlanState.message} /> : null}
      {actionPlanState.kind === "success" ? (
        <article className="action-plan-result">
          <div className="brief-result-header">
            <div>
              <p className="eyebrow">Generated Plan</p>
              <h3>{actionPlanState.data.actions.length} Recommended Actions</h3>
              <span className="muted-copy">
                {actionPlanState.data.filtered_review_count} filtered reviews /{" "}
                {actionPlanState.data.negative_review_count} negative / audience{" "}
                {actionPlanState.data.audience}
              </span>
            </div>
            <div className="brief-actions">
              <button className="secondary-button" onClick={onCopy} type="button">
                <Clipboard size={16} aria-hidden="true" />
                <span>
                  {actionPlanState.copyState === "copied"
                    ? "Copied"
                    : actionPlanState.copyState === "error"
                      ? "Copy failed"
                      : "Copy"}
                </span>
              </button>
              <button className="secondary-button" onClick={onDownload} type="button">
                <Download size={16} aria-hidden="true" />
                <span>Download plan</span>
              </button>
            </div>
          </div>

          <div className="status-board status-board--compact">
            <StatusMetric label="Avg rating" value={String(actionPlanState.data.average_rating ?? "N/A")} />
            <StatusMetric label="Themes" value={String(actionPlanState.data.top_themes.length)} />
            <StatusMetric label="Actions" value={String(actionPlanState.data.actions.length)} />
          </div>

          {actionPlanState.data.actions.length ? (
            <ol className="action-item-list">
              {actionPlanState.data.actions.map((action) => (
                <li key={action.action_id}>
                  <article className="action-item">
                    <div className="action-item-header">
                      <span className={`priority-badge priority-badge--${action.priority}`}>
                        {action.priority}
                      </span>
                      <strong>{action.title}</strong>
                      <small>
                        {action.owner} / {action.effort}
                      </small>
                    </div>
                    <p>{action.rationale}</p>
                    <p className="muted-copy">{action.expected_impact}</p>
                    <ul>
                      {action.next_steps.map((step) => (
                        <li key={step}>{step}</li>
                      ))}
                    </ul>
                  </article>
                </li>
              ))}
            </ol>
          ) : (
            <EmptyState title="No actions were generated for the current filters." />
          )}

          {actionPlanState.data.segment_drivers.length ? (
            <ul className="segment-limitations" aria-label="Action segment drivers">
              {actionPlanState.data.segment_drivers.map((driver) => (
                <li key={driver}>{driver}</li>
              ))}
            </ul>
          ) : null}

          {actionPlanState.data.limitations.length ? (
            <ul className="limitations-list" aria-label="Action plan limitations">
              {actionPlanState.data.limitations.map((limitation) => (
                <li key={limitation}>{limitation}</li>
              ))}
            </ul>
          ) : null}

          <pre className="brief-preview">{actionPlanState.data.markdown}</pre>
        </article>
      ) : null}
    </section>
  );
}

function MetricBucketList({ title, buckets }: { title: string; buckets: { label: string; count: number }[] }) {
  return (
    <div className="metric-buckets">
      <h3>{title}</h3>
      {buckets.length ? (
        <ul>
          {buckets.map((bucket) => (
            <li key={bucket.label}>
              <span>{bucket.label}</span>
              <strong>{bucket.count}</strong>
            </li>
          ))}
        </ul>
      ) : (
        <p className="muted-copy">No records yet.</p>
      )}
    </div>
  );
}

function RetrievalPanel({
  indexState,
  mode,
  query,
  retrievalState,
  status,
  onIndex,
  onModeChange,
  onQueryChange,
  onSearch
}: {
  indexState:
    | { kind: "idle" }
    | { kind: "indexing" }
    | { kind: "success"; message: string }
    | { kind: "error"; message: string };
  mode: "keyword" | "semantic" | "hybrid";
  query: string;
  retrievalState:
    | { kind: "idle" }
    | { kind: "searching" }
    | { kind: "success"; data: RetrievalSearchResponse }
    | { kind: "error"; message: string };
  status: RetrievalStatusResponse | null;
  onIndex: () => void;
  onModeChange: (mode: "keyword" | "semantic" | "hybrid") => void;
  onQueryChange: (query: string) => void;
  onSearch: () => void;
}) {
  const results = retrievalState.kind === "success" ? retrievalState.data.results : [];

  return (
    <section className="workspace-panel retrieval-panel" aria-label="Search and retrieval">
      <div className="panel-heading">
        <div>
          <p className="eyebrow">Search & Retrieval</p>
          <h2>Evidence Search</h2>
        </div>
        <Braces size={20} aria-hidden="true" />
      </div>

      <div className="retrieval-toolbar">
        <div className="retrieval-status">
          <span>Index status</span>
          <strong>{status?.status ?? "unknown"}</strong>
          <small>
            {status ? `${status.indexed_reviews}/${status.total_reviews} reviews indexed` : "No dataset selected"}
          </small>
        </div>
        <button
          className="secondary-button"
          disabled={indexState.kind === "indexing"}
          onClick={onIndex}
          type="button"
        >
          <RefreshCw size={16} aria-hidden="true" />
          <span>{indexState.kind === "indexing" ? "Indexing" : "Index"}</span>
        </button>
      </div>

      {indexState.kind === "success" ? <p className="muted-copy">{indexState.message}</p> : null}
      {indexState.kind === "error" ? (
        <p className="connection-note connection-note--inline">{indexState.message}</p>
      ) : null}

      <div className="retrieval-search-row">
        <label className="field-control retrieval-query">
          <span>Query</span>
          <div className="input-with-icon">
            <Search size={15} aria-hidden="true" />
            <input
              value={query}
              onChange={(event) => onQueryChange(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  onSearch();
                }
              }}
              placeholder="login failures after release"
            />
          </div>
        </label>
        <label className="field-control">
          <span>Mode</span>
          <select
            value={mode}
            onChange={(event) =>
              onModeChange(event.target.value as "keyword" | "semantic" | "hybrid")
            }
          >
            <option value="hybrid">Hybrid</option>
            <option value="semantic">Semantic</option>
            <option value="keyword">Keyword</option>
          </select>
        </label>
        <button
          className="primary-button retrieval-search-button"
          disabled={retrievalState.kind === "searching"}
          onClick={onSearch}
          type="button"
        >
          <Search size={16} aria-hidden="true" />
          <span>{retrievalState.kind === "searching" ? "Searching" : "Search"}</span>
        </button>
      </div>

      {retrievalState.kind === "idle" ? (
        <EmptyState title="Index a dataset, then search for supporting evidence." />
      ) : null}
      {retrievalState.kind === "searching" ? <EmptyState title="Searching evidence." /> : null}
      {retrievalState.kind === "error" ? <EmptyState title={retrievalState.message} /> : null}
      {retrievalState.kind === "success" ? (
        <div className="evidence-list">
          <p className="muted-copy">
            {results.length} evidence results / index {retrievalState.data.index_status}
          </p>
          {results.length ? (
            results.map((item) => <EvidenceCard item={item} key={item.review_id} />)
          ) : (
            <EmptyState title="No evidence matched this query and filter set." />
          )}
        </div>
      ) : null}
    </section>
  );
}

function EvidenceCard({ item }: { item: RetrievalEvidenceItem }) {
  return (
    <article className="evidence-card">
      <div className="evidence-score">
        <strong>{item.hybrid_score.toFixed(2)}</strong>
        <span>hybrid</span>
      </div>
      <div>
        <p>{item.review_text}</p>
        <dl>
          <div>
            <dt>Row</dt>
            <dd>{item.row_number}</dd>
          </div>
          <div>
            <dt>Rating</dt>
            <dd>{item.rating ?? "N/A"}</dd>
          </div>
          <div>
            <dt>Date</dt>
            <dd>{item.review_date ?? "N/A"}</dd>
          </div>
          <div>
            <dt>Source</dt>
            <dd>{item.source ?? "N/A"}</dd>
          </div>
          <div>
            <dt>Product</dt>
            <dd>{[item.product_name, item.product_version].filter(Boolean).join(" / ") || "N/A"}</dd>
          </div>
        </dl>
        <span className="score-breakdown">
          semantic {item.semantic_score.toFixed(2)} / keyword {item.keyword_score.toFixed(2)}
        </span>
      </div>
    </article>
  );
}

function CitationCard({
  citation,
  onOpenSource
}: {
  citation: AnswerCitation;
  onOpenSource: (citation: AnswerCitation) => void;
}) {
  return (
    <article className="citation-card">
      <div className="citation-index">
        <strong>[{citation.citation_id}]</strong>
        <span>{citation.hybrid_score.toFixed(2)}</span>
      </div>
      <div>
        <div className="citation-card__header">
          <button
            className="secondary-button citation-source-button"
            onClick={() => onOpenSource(citation)}
            type="button"
          >
            <FileText size={14} aria-hidden="true" />
            <span>Open source</span>
          </button>
        </div>
        <p>{citation.quote}</p>
        <dl>
          <div>
            <dt>Row</dt>
            <dd>{citation.row_number}</dd>
          </div>
          <div>
            <dt>Rating</dt>
            <dd>{citation.rating ?? "N/A"}</dd>
          </div>
          <div>
            <dt>Date</dt>
            <dd>{citation.review_date ?? "N/A"}</dd>
          </div>
          <div>
            <dt>Source</dt>
            <dd>{citation.source ?? "N/A"}</dd>
          </div>
          <div>
            <dt>Product</dt>
            <dd>
              {[citation.product_name, citation.product_version].filter(Boolean).join(" / ") ||
                "N/A"}
            </dd>
          </div>
          <div>
            <dt>Market</dt>
            <dd>{[citation.region, citation.country].filter(Boolean).join(" / ") || "N/A"}</dd>
          </div>
        </dl>
        <span className="score-breakdown">
          semantic {citation.semantic_score.toFixed(2)} / keyword {citation.keyword_score.toFixed(2)}
        </span>
      </div>
    </article>
  );
}

function ComparisonSummary({ comparison }: { comparison: AnswerResponse["comparison"] }) {
  if (!comparison) {
    return null;
  }

  return (
    <div className="comparison-summary" aria-label="Comparison analysis">
      <div className="comparison-kpis">
        <ComparisonKpi segment={comparison.before} title="Before" />
        <ComparisonKpi segment={comparison.after} title="After" />
        <div>
          <span>Rating delta</span>
          <strong>{comparison.rating_delta === null ? "N/A" : comparison.rating_delta.toFixed(2)}</strong>
        </div>
      </div>
      <p>{comparison.summary}</p>
      {comparison.theme_movements.length ? (
        <table>
          <thead>
            <tr>
              <th>Theme</th>
              <th>Before</th>
              <th>After</th>
              <th>Change</th>
            </tr>
          </thead>
          <tbody>
            {comparison.theme_movements.map((movement) => (
              <tr key={movement.label}>
                <td>{movement.label}</td>
                <td>{movement.before_share.toFixed(1)}%</td>
                <td>{movement.after_share.toFixed(1)}%</td>
                <td>{movement.delta_share > 0 ? "+" : ""}{movement.delta_share.toFixed(1)} pts</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : null}
    </div>
  );
}

function ComparisonKpi({
  segment,
  title
}: {
  segment: NonNullable<AnswerResponse["comparison"]>["before"];
  title: string;
}) {
  return (
    <div>
      <span>{title}</span>
      <strong>{segment.average_rating === null ? "N/A" : segment.average_rating.toFixed(2)}</strong>
      <small>{segment.review_count} reviews</small>
      <small>{segment.label}</small>
    </div>
  );
}

function FilterSelect({
  label,
  options,
  value,
  onChange
}: {
  label: string;
  options: string[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="field-control">
      <span>{label}</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        <option value="">All</option>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </label>
  );
}

function RatingDistribution({ buckets }: { buckets: { rating: string; count: number }[] }) {
  const max = Math.max(...buckets.map((bucket) => bucket.count), 1);

  return (
    <section className="chart-panel" aria-label="Rating distribution">
      <h3>Rating Distribution</h3>
      <div className="bar-list">
        {buckets.map((bucket) => (
          <div className="bar-row" key={bucket.rating}>
            <span>{bucket.rating}</span>
            <div className="bar-track">
              <div className="bar-fill" style={{ width: `${(bucket.count / max) * 100}%` }} />
            </div>
            <strong>{bucket.count}</strong>
          </div>
        ))}
      </div>
    </section>
  );
}

function VolumeTrend({ points }: { points: { date: string; count: number }[] }) {
  return (
    <section className="chart-panel" aria-label="Review volume trend">
      <h3>Volume Trend</h3>
      {points.length ? (
        <ol className="trend-list">
          {points.slice(-6).map((point) => (
            <li key={point.date}>
              <span>{point.date}</span>
              <strong>{point.count}</strong>
            </li>
          ))}
        </ol>
      ) : (
        <p className="muted-copy">No dated reviews in this filtered set.</p>
      )}
    </section>
  );
}

function ReviewTable({
  reviews,
  selectedReviewId,
  onReviewSelect
}: {
  reviews: ReviewListItem[];
  selectedReviewId: string;
  onReviewSelect: (review: ReviewListItem) => void;
}) {
  if (!reviews.length) {
    return <EmptyState title="No matching reviews." />;
  }

  return (
    <div className="review-table" role="table" aria-label="Filtered reviews">
      <div className="review-row review-row--header" role="row">
        <span>Rating</span>
        <span>Date</span>
        <span>Source</span>
        <span>Review</span>
      </div>
      {reviews.map((review) => (
        <button
          className={`review-row ${review.id === selectedReviewId ? "review-row--selected" : ""}`}
          key={review.id}
          onClick={() => onReviewSelect(review)}
          type="button"
        >
          <span>{review.rating ?? "N/A"}</span>
          <span>{review.review_date ?? "N/A"}</span>
          <span>{review.source ?? "N/A"}</span>
          <strong>{review.review_text}</strong>
        </button>
      ))}
    </div>
  );
}

function ReviewDetail({ review }: { review: ReviewListItem | null }) {
  if (!review) {
    return <EmptyState title="Select a review to inspect source evidence." />;
  }

  return (
    <aside className="review-detail" aria-label="Source review detail">
      <p className="eyebrow">Source Review</p>
      <h3>{review.review_title ?? `Row ${review.row_number}`}</h3>
      <p>{review.review_text}</p>
      <dl>
        <div>
          <dt>Product</dt>
          <dd>{[review.product_name, review.product_version].filter(Boolean).join(" / ") || "N/A"}</dd>
        </div>
        <div>
          <dt>Market</dt>
          <dd>{[review.region, review.country].filter(Boolean).join(" / ") || "N/A"}</dd>
        </div>
        <div>
          <dt>Segment</dt>
          <dd>{[review.customer_segment, review.platform, review.channel].filter(Boolean).join(" / ") || "N/A"}</dd>
        </div>
      </dl>
    </aside>
  );
}

function reviewFromCitation(citation: AnswerCitation): ReviewListItem {
  return {
    id: citation.review_id,
    external_review_id: null,
    review_text: citation.quote,
    review_title: `Row ${citation.row_number}`,
    rating: citation.rating,
    review_date: citation.review_date,
    source: citation.source,
    product_name: citation.product_name,
    product_version: citation.product_version,
    region: citation.region,
    country: citation.country,
    customer_segment: citation.customer_segment,
    platform: null,
    channel: null,
    verified_purchase: null,
    row_number: citation.row_number
  };
}

function routeLabel(route: AnswerResponse["route"]) {
  if (route === "analytics") {
    return "Analytics";
  }
  if (route === "retrieval_analytics") {
    return "Retrieval + analytics";
  }
  return "Retrieval";
}

function EmptyState({ title }: { title: string }) {
  return <p className="empty-state">{title}</p>;
}

function statusLabel(health: HealthState) {
  if (health.kind === "online") {
    return "API online";
  }
  if (health.kind === "offline") {
    return "API offline";
  }
  return "Checking API";
}

export default App;
