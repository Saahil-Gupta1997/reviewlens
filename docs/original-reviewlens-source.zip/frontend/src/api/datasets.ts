export type FieldMapping = {
  external_review_id?: string | null;
  review_text: string;
  review_title?: string | null;
  rating?: string | null;
  review_date?: string | null;
  source?: string | null;
  product_name?: string | null;
  product_version?: string | null;
  region?: string | null;
  country?: string | null;
  language?: string | null;
  customer_segment?: string | null;
  platform?: string | null;
  channel?: string | null;
  verified_purchase?: string | null;
};

export type ImportErrorPreview = {
  row_number: number;
  error_code: string;
  message: string;
  payload: Record<string, string | number | boolean | null>;
};

export type DatasetSummary = {
  dataset_id: string;
  ingestion_job_id: string;
  name: string;
  filename: string;
  status: string;
  total_rows: number;
  accepted_rows: number;
  rejected_rows: number;
  duplicate_rows: number;
  field_mapping: FieldMapping;
  errors_preview: ImportErrorPreview[];
};

export type DatasetListItem = Omit<
  DatasetSummary,
  "ingestion_job_id" | "field_mapping" | "errors_preview"
>;

export type ReviewListItem = {
  id: string;
  external_review_id: string | null;
  review_text: string;
  review_title: string | null;
  rating: number | null;
  review_date: string | null;
  source: string | null;
  product_name: string | null;
  product_version: string | null;
  region: string | null;
  country: string | null;
  customer_segment: string | null;
  platform: string | null;
  channel: string | null;
  verified_purchase: boolean | null;
  row_number: number;
};

export type RatingBucket = {
  rating: string;
  count: number;
};

export type TrendPoint = {
  date: string;
  count: number;
};

export type FilterOptions = {
  product_names: string[];
  product_versions: string[];
  sources: string[];
  regions: string[];
  countries: string[];
  customer_segments: string[];
  platforms: string[];
  channels: string[];
};

export type DatasetExploreResponse = {
  dataset_id: string;
  metrics: {
    total_reviews: number;
    filtered_reviews: number;
    average_rating: number | null;
    rated_reviews: number;
  };
  rating_distribution: RatingBucket[];
  volume_trend: TrendPoint[];
  filter_options: FilterOptions;
  reviews: ReviewListItem[];
  limit: number;
  offset: number;
};

export type ExploreFilters = {
  ratingMin?: string;
  ratingMax?: string;
  dateFrom?: string;
  dateTo?: string;
  productName?: string;
  productVersion?: string;
  source?: string;
  region?: string;
  country?: string;
  customerSegment?: string;
  platform?: string;
  channel?: string;
  query?: string;
};

export type RetrievalStatusResponse = {
  dataset_id: string;
  embedding_model: string;
  dimensions: number;
  total_reviews: number;
  indexed_reviews: number;
  pending_reviews: number;
  status: string;
};

export type RetrievalIndexResponse = {
  dataset_id: string;
  embedding_model: string;
  dimensions: number;
  indexed_reviews: number;
  skipped_reviews: number;
};

export type RetrievalEvidenceItem = {
  review_id: string;
  row_number: number;
  review_text: string;
  rating: number | null;
  review_date: string | null;
  source: string | null;
  product_name: string | null;
  product_version: string | null;
  region: string | null;
  country: string | null;
  customer_segment: string | null;
  semantic_score: number;
  keyword_score: number;
  hybrid_score: number;
};

export type RetrievalSearchResponse = {
  dataset_id: string;
  query: string;
  mode: "keyword" | "semantic" | "hybrid";
  top_k: number;
  index_status: string;
  results: RetrievalEvidenceItem[];
};

export type AnswerStyle = "summary" | "issues" | "sentiment" | "root_cause";

export type AnswerTheme = {
  label: string;
  count: number;
  score: number;
};

export type AnswerRoute = "retrieval" | "analytics" | "retrieval_analytics";

export type AnswerAnalytic = {
  label: string;
  value: string;
  numerator: number | null;
  denominator: number | null;
  percentage: number | null;
  details: string;
};

export type AnswerComparisonSegment = {
  label: string;
  review_count: number;
  average_rating: number | null;
};

export type AnswerThemeMovement = {
  label: string;
  before_count: number;
  before_share: number;
  after_count: number;
  after_share: number;
  delta_share: number;
  direction: "increased" | "decreased" | "flat";
};

export type AnswerComparison = {
  comparison_type: "version" | "period" | "segment";
  dimension: string;
  before: AnswerComparisonSegment;
  after: AnswerComparisonSegment;
  rating_delta: number | null;
  theme_movements: AnswerThemeMovement[];
  summary: string;
};

export type AnswerCitation = {
  citation_id: number;
  review_id: string;
  row_number: number;
  quote: string;
  rating: number | null;
  review_date: string | null;
  source: string | null;
  product_name: string | null;
  product_version: string | null;
  region: string | null;
  country: string | null;
  customer_segment: string | null;
  semantic_score: number;
  keyword_score: number;
  hybrid_score: number;
};

export type AnswerResponse = {
  answer_id: string;
  dataset_id: string;
  question: string;
  answer_style: AnswerStyle;
  route: AnswerRoute;
  answer: string;
  confidence: "none" | "low" | "medium" | "high";
  confidence_score: number;
  index_status: string;
  evidence_count: number;
  filtered_review_count: number;
  themes: AnswerTheme[];
  analytics: AnswerAnalytic[];
  comparison: AnswerComparison | null;
  citations: AnswerCitation[];
  limitations: string[];
  generation_model: string;
};

export type AnswerFeedbackResponse = {
  feedback_id: string;
  answer_id: string;
  dataset_id: string;
  rating: "useful" | "incorrect" | "unsupported";
  notes: string | null;
};

export type AnswerRunSummary = {
  answer_id: string;
  dataset_id: string;
  question: string;
  answer_style: AnswerStyle;
  confidence: "none" | "low" | "medium" | "high";
  confidence_score: number;
  index_status: string;
  evidence_count: number;
  feedback_rating: string | null;
  created_at: string;
};

export type AnswerRunDetail = AnswerResponse & {
  mode: "keyword" | "semantic" | "hybrid";
  top_k: number;
  filters: Record<string, string | number | boolean | null>;
  latency_ms: number;
  feedback_rating: string | null;
  feedback_notes: string | null;
  created_at: string;
};

export type CountBucket = {
  label: string;
  count: number;
};

export type ObservabilityMetricsResponse = {
  dataset_id: string;
  answer_count: number;
  average_confidence_score: number | null;
  average_latency_ms: number | null;
  average_evidence_count: number | null;
  no_evidence_rate: number;
  partial_index_rate: number;
  confidence_distribution: CountBucket[];
  feedback_distribution: CountBucket[];
  top_themes: CountBucket[];
  top_limitations: CountBucket[];
};

export type SentimentBucket = {
  label: string;
  count: number;
  share: number;
};

export type ThemeSample = {
  review_id: string;
  row_number: number;
  review_text: string;
  rating: number | null;
  review_date: string | null;
  source: string | null;
  product_name: string | null;
};

export type ThemeInsight = {
  label: string;
  count: number;
  share: number;
  average_rating: number | null;
  negative_count: number;
  positive_count: number;
  risk_score: number;
  keywords: string[];
  samples: ThemeSample[];
};

export type ThemeComparisonItem = {
  label: string;
  current_count: number;
  previous_count: number;
  delta: number;
  delta_share: number;
};

export type ThemeComparison = {
  current_start: string;
  current_end: string;
  previous_start: string;
  previous_end: string;
  items: ThemeComparisonItem[];
};

export type DatasetThemesResponse = {
  dataset_id: string;
  total_reviews: number;
  analyzed_reviews: number;
  theme_coverage: number;
  sentiment_distribution: SentimentBucket[];
  themes: ThemeInsight[];
  comparison: ThemeComparison | null;
  limitations: string[];
};

export type ThemeCompareDimension =
  | "source"
  | "region"
  | "country"
  | "product_name"
  | "product_version"
  | "platform"
  | "customer_segment"
  | "channel";

export type SegmentThemeSummary = {
  segment: string;
  review_count: number;
  average_rating: number | null;
  negative_rate: number;
  sentiment_distribution: SentimentBucket[];
  top_themes: ThemeInsight[];
};

export type SegmentThemeDelta = {
  label: string;
  left_count: number;
  right_count: number;
  left_share: number;
  right_share: number;
  delta_share: number;
  direction: "left_higher" | "right_higher" | "similar";
  summary: string;
};

export type SegmentThemeComparisonResponse = {
  dataset_id: string;
  compare_by: ThemeCompareDimension;
  filtered_review_count: number;
  left: SegmentThemeSummary;
  right: SegmentThemeSummary;
  deltas: SegmentThemeDelta[];
  limitations: string[];
};

export type InsightReportSection = {
  title: string;
  summary: string;
  bullets: string[];
};

export type InsightReportResponse = {
  dataset_id: string;
  title: string;
  generated_at: string;
  filters: Record<string, string | number | boolean | null>;
  metrics: DatasetExploreResponse["metrics"];
  rating_distribution: RatingBucket[];
  volume_trend: TrendPoint[];
  retrieval_status: RetrievalStatusResponse;
  quality_metrics: ObservabilityMetricsResponse;
  top_themes: ThemeInsight[];
  segment_comparison: SegmentThemeComparisonResponse | null;
  recent_answers: AnswerRunDetail[];
  sections: InsightReportSection[];
  markdown: string;
  limitations: string[];
};

export type ActionPlanAudience = "product" | "support" | "leadership";

export type ActionPlanMetric = {
  label: string;
  value: string;
};

export type ReviewActionItem = {
  action_id: string;
  title: string;
  priority: "critical" | "high" | "medium" | "low";
  owner: "product" | "support" | "engineering" | "success";
  effort: "small" | "medium" | "large";
  theme: string;
  rationale: string;
  expected_impact: string;
  next_steps: string[];
  evidence: ThemeSample[];
  metrics: ActionPlanMetric[];
};

export type ActionPlanResponse = {
  dataset_id: string;
  generated_at: string;
  audience: ActionPlanAudience;
  filters: Record<string, string | number | boolean | null>;
  filtered_review_count: number;
  average_rating: number | null;
  negative_review_count: number;
  top_themes: ThemeInsight[];
  actions: ReviewActionItem[];
  segment_drivers: string[];
  limitations: string[];
  markdown: string;
};

export type EvaluationMetric = {
  name: string;
  score: number;
  passed: number;
  total: number;
  details: string;
};

export type EvaluationCategorySummary = {
  category: "factual" | "theme" | "quantitative" | "filter" | "comparison" | "impossible";
  passed: number;
  total: number;
  score: number;
};

export type EvaluationCaseResult = {
  case_id: string;
  category: EvaluationCategorySummary["category"];
  question: string;
  passed: boolean;
  latency_ms: number;
  confidence: string;
  evidence_count: number;
  expected: string;
  observed: string;
  failures: string[];
};

export type EvaluationRunResponse = {
  run_id: string;
  version: string;
  dataset_id: string;
  generated_at: string;
  total_questions: number;
  passed_questions: number;
  overall_score: number;
  average_latency_ms: number;
  p95_latency_ms: number;
  metrics: EvaluationMetric[];
  category_breakdown: EvaluationCategorySummary[];
  cases: EvaluationCaseResult[];
};

export type ReleaseReadinessResponse = {
  app_name: string;
  app_version: string;
  environment: string;
  model_configuration: {
    embedding_provider: string;
    embedding_model: string;
    embedding_dimensions: number;
    answer_provider: string;
    answer_model: string;
    retrieval_auto_index: boolean;
    openai_configured: boolean;
  };
  cost_configuration: {
    tracking_basis: string;
    embedding_cost_per_1k_tokens_usd: number;
    answer_input_cost_per_1k_tokens_usd: number;
    answer_output_cost_per_1k_tokens_usd: number;
    notes: string[];
  };
  privacy: string[];
  security: string[];
  limits: string[];
  limitations: string[];
  release_checklist: string[];
};

const apiBaseUrl = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

async function errorFromResponse(response: Response, fallback: string) {
  const payload = (await response.json().catch(() => null)) as { detail?: string } | null;
  return new Error(payload?.detail ?? fallback);
}

export async function uploadDataset(input: {
  file: File;
  datasetName?: string;
  fieldMapping?: string;
}): Promise<DatasetSummary> {
  const form = new FormData();
  form.append("file", input.file);
  if (input.datasetName) {
    form.append("dataset_name", input.datasetName);
  }
  if (input.fieldMapping) {
    form.append("field_mapping", input.fieldMapping);
  }

  const response = await fetch(`${apiBaseUrl}/api/datasets`, {
    method: "POST",
    body: form
  });

  if (!response.ok) {
    throw await errorFromResponse(response, `Upload failed with ${response.status}`);
  }

  return response.json() as Promise<DatasetSummary>;
}

export async function fetchDatasets(): Promise<DatasetListItem[]> {
  const response = await fetch(`${apiBaseUrl}/api/datasets`);

  if (!response.ok) {
    throw await errorFromResponse(response, `Dataset list failed with ${response.status}`);
  }

  return response.json() as Promise<DatasetListItem[]>;
}

export async function deleteDataset(datasetId: string): Promise<void> {
  const response = await fetch(`${apiBaseUrl}/api/datasets/${datasetId}`, {
    method: "DELETE"
  });

  if (!response.ok) {
    throw await errorFromResponse(response, `Dataset deletion failed with ${response.status}`);
  }
}

export async function fetchReleaseReadiness(): Promise<ReleaseReadinessResponse> {
  const response = await fetch(`${apiBaseUrl}/api/productization/release-readiness`);

  if (!response.ok) {
    throw await errorFromResponse(response, `Release readiness failed with ${response.status}`);
  }

  return response.json() as Promise<ReleaseReadinessResponse>;
}

export async function runEvaluation(): Promise<EvaluationRunResponse> {
  const response = await fetch(`${apiBaseUrl}/api/evaluations/run`, {
    method: "POST"
  });

  if (!response.ok) {
    throw await errorFromResponse(response, `Evaluation failed with ${response.status}`);
  }

  return response.json() as Promise<EvaluationRunResponse>;
}

export async function fetchDatasetExplore(
  datasetId: string,
  filters: ExploreFilters = {}
): Promise<DatasetExploreResponse> {
  const params = new URLSearchParams();
  appendParam(params, "rating_min", filters.ratingMin);
  appendParam(params, "rating_max", filters.ratingMax);
  appendParam(params, "date_from", filters.dateFrom);
  appendParam(params, "date_to", filters.dateTo);
  appendParam(params, "product_name", filters.productName);
  appendParam(params, "product_version", filters.productVersion);
  appendParam(params, "source", filters.source);
  appendParam(params, "region", filters.region);
  appendParam(params, "country", filters.country);
  appendParam(params, "customer_segment", filters.customerSegment);
  appendParam(params, "platform", filters.platform);
  appendParam(params, "channel", filters.channel);
  appendParam(params, "q", filters.query);

  const query = params.toString();
  const response = await fetch(
    `${apiBaseUrl}/api/datasets/${datasetId}/explore${query ? `?${query}` : ""}`
  );

  if (!response.ok) {
    throw await errorFromResponse(response, `Dataset exploration failed with ${response.status}`);
  }

  return response.json() as Promise<DatasetExploreResponse>;
}

export async function fetchRetrievalStatus(datasetId: string): Promise<RetrievalStatusResponse> {
  const response = await fetch(`${apiBaseUrl}/api/datasets/${datasetId}/retrieval/status`);

  if (!response.ok) {
    throw await errorFromResponse(response, `Retrieval status failed with ${response.status}`);
  }

  return response.json() as Promise<RetrievalStatusResponse>;
}

export async function indexDatasetRetrieval(datasetId: string): Promise<RetrievalIndexResponse> {
  const response = await fetch(`${apiBaseUrl}/api/datasets/${datasetId}/retrieval/index`, {
    method: "POST"
  });

  if (!response.ok) {
    throw await errorFromResponse(response, `Retrieval indexing failed with ${response.status}`);
  }

  return response.json() as Promise<RetrievalIndexResponse>;
}

export async function searchDatasetRetrieval(input: {
  datasetId: string;
  query: string;
  mode: "keyword" | "semantic" | "hybrid";
  filters?: ExploreFilters;
  topK?: number;
}): Promise<RetrievalSearchResponse> {
  const params = new URLSearchParams();
  params.set("q", input.query);
  params.set("mode", input.mode);
  params.set("top_k", String(input.topK ?? 10));
  appendParam(params, "rating_min", input.filters?.ratingMin);
  appendParam(params, "rating_max", input.filters?.ratingMax);
  appendParam(params, "date_from", input.filters?.dateFrom);
  appendParam(params, "date_to", input.filters?.dateTo);
  appendParam(params, "product_name", input.filters?.productName);
  appendParam(params, "product_version", input.filters?.productVersion);
  appendParam(params, "source", input.filters?.source);
  appendParam(params, "region", input.filters?.region);
  appendParam(params, "country", input.filters?.country);
  appendParam(params, "customer_segment", input.filters?.customerSegment);
  appendParam(params, "platform", input.filters?.platform);
  appendParam(params, "channel", input.filters?.channel);

  const response = await fetch(
    `${apiBaseUrl}/api/datasets/${input.datasetId}/retrieval/search?${params.toString()}`
  );

  if (!response.ok) {
    throw await errorFromResponse(response, `Retrieval search failed with ${response.status}`);
  }

  return response.json() as Promise<RetrievalSearchResponse>;
}

export async function askDatasetAnswer(input: {
  datasetId: string;
  question: string;
  mode: "keyword" | "semantic" | "hybrid";
  answerStyle: AnswerStyle;
  filters?: ExploreFilters;
  topK?: number;
}): Promise<AnswerResponse> {
  const response = await fetch(`${apiBaseUrl}/api/datasets/${input.datasetId}/answers`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      question: input.question,
      mode: input.mode,
      answer_style: input.answerStyle,
      top_k: input.topK ?? 8,
      filters: toAnswerFilters(input.filters)
    })
  });

  if (!response.ok) {
    throw await errorFromResponse(response, `Answer generation failed with ${response.status}`);
  }

  return response.json() as Promise<AnswerResponse>;
}

export async function fetchAnswerHistory(datasetId: string): Promise<AnswerRunSummary[]> {
  const response = await fetch(`${apiBaseUrl}/api/datasets/${datasetId}/answers`);

  if (!response.ok) {
    throw await errorFromResponse(response, `Answer history failed with ${response.status}`);
  }

  return response.json() as Promise<AnswerRunSummary[]>;
}

export async function fetchAnswerDetail(input: {
  datasetId: string;
  answerId: string;
}): Promise<AnswerRunDetail> {
  const response = await fetch(
    `${apiBaseUrl}/api/datasets/${input.datasetId}/answers/${input.answerId}`
  );

  if (!response.ok) {
    throw await errorFromResponse(response, `Answer detail failed with ${response.status}`);
  }

  return response.json() as Promise<AnswerRunDetail>;
}

export async function submitAnswerFeedback(input: {
  datasetId: string;
  answerId: string;
  rating: "useful" | "incorrect" | "unsupported";
  notes?: string;
}): Promise<AnswerFeedbackResponse> {
  const response = await fetch(
    `${apiBaseUrl}/api/datasets/${input.datasetId}/answers/${input.answerId}/feedback`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        rating: input.rating,
        notes: input.notes || undefined
      })
    }
  );

  if (!response.ok) {
    throw await errorFromResponse(response, `Answer feedback failed with ${response.status}`);
  }

  return response.json() as Promise<AnswerFeedbackResponse>;
}

export async function fetchObservabilityMetrics(
  datasetId: string
): Promise<ObservabilityMetricsResponse> {
  const response = await fetch(`${apiBaseUrl}/api/datasets/${datasetId}/observability/metrics`);

  if (!response.ok) {
    throw await errorFromResponse(response, `Quality metrics failed with ${response.status}`);
  }

  return response.json() as Promise<ObservabilityMetricsResponse>;
}

export async function fetchDatasetThemes(
  datasetId: string,
  filters: ExploreFilters = {}
): Promise<DatasetThemesResponse> {
  const params = new URLSearchParams();
  appendParam(params, "rating_min", filters.ratingMin);
  appendParam(params, "rating_max", filters.ratingMax);
  appendParam(params, "date_from", filters.dateFrom);
  appendParam(params, "date_to", filters.dateTo);
  appendParam(params, "product_name", filters.productName);
  appendParam(params, "product_version", filters.productVersion);
  appendParam(params, "source", filters.source);
  appendParam(params, "region", filters.region);
  appendParam(params, "country", filters.country);
  appendParam(params, "customer_segment", filters.customerSegment);
  appendParam(params, "platform", filters.platform);
  appendParam(params, "channel", filters.channel);
  appendParam(params, "q", filters.query);

  const query = params.toString();
  const response = await fetch(
    `${apiBaseUrl}/api/datasets/${datasetId}/themes${query ? `?${query}` : ""}`
  );

  if (!response.ok) {
    throw await errorFromResponse(response, `Theme analytics failed with ${response.status}`);
  }

  return response.json() as Promise<DatasetThemesResponse>;
}

export async function fetchThemeComparison(input: {
  datasetId: string;
  compareBy: ThemeCompareDimension;
  leftValue: string;
  rightValue: string;
  filters?: ExploreFilters;
  limit?: number;
  minCount?: number;
}): Promise<SegmentThemeComparisonResponse> {
  const response = await fetch(`${apiBaseUrl}/api/datasets/${input.datasetId}/themes/compare`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      compare_by: input.compareBy,
      left_value: input.leftValue,
      right_value: input.rightValue,
      filters: toThemeFilters(input.filters),
      limit: input.limit ?? 5,
      min_count: input.minCount ?? 1
    })
  });

  if (!response.ok) {
    throw await errorFromResponse(response, `Theme comparison failed with ${response.status}`);
  }

  return response.json() as Promise<SegmentThemeComparisonResponse>;
}

export async function generateInsightBrief(input: {
  datasetId: string;
  title?: string;
  filters?: ExploreFilters;
  themeLimit?: number;
  recentAnswersLimit?: number;
  segmentComparison?: {
    compareBy: ThemeCompareDimension;
    leftValue: string;
    rightValue: string;
    limit?: number;
    minCount?: number;
  };
}): Promise<InsightReportResponse> {
  const response = await fetch(
    `${apiBaseUrl}/api/datasets/${input.datasetId}/reports/insight-brief`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        title: input.title || undefined,
        filters: toThemeFilters(input.filters),
        theme_limit: input.themeLimit ?? 5,
        recent_answers_limit: input.recentAnswersLimit ?? 3,
        segment_comparison: input.segmentComparison
          ? {
              compare_by: input.segmentComparison.compareBy,
              left_value: input.segmentComparison.leftValue,
              right_value: input.segmentComparison.rightValue,
              limit: input.segmentComparison.limit ?? 5,
              min_count: input.segmentComparison.minCount ?? 1
            }
          : undefined
      })
    }
  );

  if (!response.ok) {
    throw await errorFromResponse(response, `Insight brief failed with ${response.status}`);
  }

  return response.json() as Promise<InsightReportResponse>;
}

export async function generateActionPlan(input: {
  datasetId: string;
  audience?: ActionPlanAudience;
  filters?: ExploreFilters;
  themeLimit?: number;
  maxActions?: number;
  segmentComparison?: {
    compareBy: ThemeCompareDimension;
    leftValue: string;
    rightValue: string;
    limit?: number;
    minCount?: number;
  };
}): Promise<ActionPlanResponse> {
  const response = await fetch(`${apiBaseUrl}/api/datasets/${input.datasetId}/actions/plan`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      audience: input.audience ?? "product",
      filters: toThemeFilters(input.filters),
      theme_limit: input.themeLimit ?? 6,
      max_actions: input.maxActions ?? 5,
      segment_comparison: input.segmentComparison
        ? {
            compare_by: input.segmentComparison.compareBy,
            left_value: input.segmentComparison.leftValue,
            right_value: input.segmentComparison.rightValue,
            limit: input.segmentComparison.limit ?? 5,
            min_count: input.segmentComparison.minCount ?? 1
          }
        : undefined
    })
  });

  if (!response.ok) {
    throw await errorFromResponse(response, `Action plan failed with ${response.status}`);
  }

  return response.json() as Promise<ActionPlanResponse>;
}

function appendParam(params: URLSearchParams, key: string, value?: string) {
  if (value) {
    params.set(key, value);
  }
}

function toAnswerFilters(filters: ExploreFilters = {}) {
  return {
    rating_min: numericFilter(filters.ratingMin),
    rating_max: numericFilter(filters.ratingMax),
    date_from: filters.dateFrom || undefined,
    date_to: filters.dateTo || undefined,
    product_name: filters.productName || undefined,
    product_version: filters.productVersion || undefined,
    source: filters.source || undefined,
    region: filters.region || undefined,
    country: filters.country || undefined,
    customer_segment: filters.customerSegment || undefined,
    platform: filters.platform || undefined,
    channel: filters.channel || undefined
  };
}

function toThemeFilters(filters: ExploreFilters = {}) {
  return {
    ...toAnswerFilters(filters),
    q: filters.query || undefined
  };
}

function numericFilter(value?: string) {
  if (!value) {
    return undefined;
  }
  return Number(value);
}
