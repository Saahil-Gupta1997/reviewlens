import "@testing-library/jest-dom/vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

import App from "./App";
import {
  askDatasetAnswer,
  deleteDataset,
  fetchAnswerDetail,
  fetchAnswerHistory,
  fetchDatasetExplore,
  fetchDatasetThemes,
  fetchThemeComparison,
  fetchReleaseReadiness,
  generateActionPlan,
  generateInsightBrief,
  indexDatasetRetrieval,
  fetchObservabilityMetrics,
  runEvaluation,
  searchDatasetRetrieval,
  submitAnswerFeedback,
  uploadDataset
} from "./api/datasets";

vi.mock("./api/health", () => ({
  fetchHealth: vi.fn().mockResolvedValue({
    status: "ok",
    service: "ReviewLens API",
    version: "0.1.0",
    environment: "test"
  })
}));

vi.mock("./api/datasets", () => ({
  fetchDatasets: vi.fn().mockResolvedValue([
    {
      dataset_id: "dataset-1",
      name: "App reviews",
      filename: "reviews.csv",
      status: "ready",
      total_rows: 2,
      accepted_rows: 2,
      rejected_rows: 0,
      duplicate_rows: 0
    }
  ]),
  fetchDatasetExplore: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    metrics: {
      total_reviews: 2,
      filtered_reviews: 2,
      average_rating: 4.5,
      rated_reviews: 2
    },
    rating_distribution: [
      { rating: "0", count: 0 },
      { rating: "1", count: 0 },
      { rating: "2", count: 0 },
      { rating: "3", count: 0 },
      { rating: "4", count: 1 },
      { rating: "5", count: 1 }
    ],
    volume_trend: [
      { date: "2026-08-01", count: 1 },
      { date: "2026-08-02", count: 1 }
    ],
    filter_options: {
      product_names: ["Mobile App"],
      product_versions: ["4.2"],
      sources: ["app_store"],
      regions: ["EU", "NA"],
      countries: ["US"],
      customer_segments: ["enterprise"],
      platforms: ["ios"],
      channels: ["mobile"]
    },
    reviews: [
      {
        id: "review-1",
        external_review_id: "r1",
        review_text: "Login is much faster",
        review_title: null,
        rating: 5,
        review_date: "2026-08-01",
        source: "app_store",
        product_name: "Mobile App",
        product_version: "4.2",
        region: "NA",
        country: "US",
        customer_segment: "enterprise",
        platform: "ios",
        channel: "mobile",
        verified_purchase: true,
        row_number: 2
      },
      {
        id: "review-2",
        external_review_id: "r2",
        review_text: "Checkout crashes sometimes",
        review_title: null,
        rating: 4,
        review_date: "2026-08-02",
        source: "app_store",
        product_name: "Mobile App",
        product_version: "4.2",
        region: "NA",
        country: "US",
        customer_segment: "enterprise",
        platform: "ios",
        channel: "mobile",
        verified_purchase: true,
        row_number: 3
      }
    ],
    limit: 50,
    offset: 0
  }),
  fetchDatasetThemes: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    total_reviews: 2,
    analyzed_reviews: 2,
    theme_coverage: 1,
    sentiment_distribution: [
      { label: "negative", count: 1, share: 0.5 },
      { label: "positive", count: 1, share: 0.5 }
    ],
    themes: [
      {
        label: "Login / Authentication",
        count: 1,
        share: 0.5,
        average_rating: 5,
        negative_count: 0,
        positive_count: 1,
        risk_score: 30,
        keywords: ["login", "password"],
        samples: [
          {
            review_id: "review-1",
            row_number: 2,
            review_text: "Login is much faster",
            rating: 5,
            review_date: "2026-08-01",
            source: "app_store",
            product_name: "Mobile App"
          }
        ]
      },
      {
        label: "Reliability",
        count: 1,
        share: 0.5,
        average_rating: 4,
        negative_count: 0,
        positive_count: 1,
        risk_score: 30,
        keywords: ["crash"],
        samples: [
          {
            review_id: "review-2",
            row_number: 3,
            review_text: "Checkout crashes sometimes",
            rating: 4,
            review_date: "2026-08-02",
            source: "app_store",
            product_name: "Mobile App"
          }
        ]
      }
    ],
    comparison: {
      current_start: "2026-08-01",
      current_end: "2026-08-02",
      previous_start: "2026-07-30",
      previous_end: "2026-07-31",
      items: [
        {
          label: "Login / Authentication",
          current_count: 1,
          previous_count: 0,
          delta: 1,
          delta_share: 0.5
        }
      ]
    },
    limitations: ["Theme analysis uses deterministic keyword groups, not an LLM classifier."]
  }),
  fetchThemeComparison: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    compare_by: "region",
    filtered_review_count: 3,
    left: {
      segment: "EU",
      review_count: 2,
      average_rating: 1.5,
      negative_rate: 1,
      sentiment_distribution: [{ label: "negative", count: 2, share: 1 }],
      top_themes: [
        {
          label: "Login / Authentication",
          count: 2,
          share: 1,
          average_rating: 1.5,
          negative_count: 2,
          positive_count: 0,
          risk_score: 100,
          keywords: ["login"],
          samples: []
        }
      ]
    },
    right: {
      segment: "NA",
      review_count: 1,
      average_rating: 5,
      negative_rate: 0,
      sentiment_distribution: [{ label: "positive", count: 1, share: 1 }],
      top_themes: [
        {
          label: "Checkout / Billing",
          count: 1,
          share: 1,
          average_rating: 5,
          negative_count: 0,
          positive_count: 1,
          risk_score: 60,
          keywords: ["checkout"],
          samples: []
        }
      ]
    },
    deltas: [
      {
        label: "Login / Authentication",
        left_count: 2,
        right_count: 0,
        left_share: 1,
        right_share: 0,
        delta_share: 1,
        direction: "left_higher",
        summary: "Login / Authentication appears more often in EU than NA."
      }
    ],
    limitations: ["Segment comparison is based on a small sample."]
  }),
  fetchRetrievalStatus: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    embedding_model: "reviewlens-local-hash-v1",
    dimensions: 64,
    total_reviews: 2,
    indexed_reviews: 0,
    pending_reviews: 2,
    status: "pending"
  }),
  indexDatasetRetrieval: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    embedding_model: "reviewlens-local-hash-v1",
    dimensions: 64,
    indexed_reviews: 2,
    skipped_reviews: 0
  }),
  searchDatasetRetrieval: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    query: "login",
    mode: "hybrid",
    top_k: 8,
    index_status: "ready",
    results: [
      {
        review_id: "review-1",
        row_number: 2,
        review_text: "Login is much faster",
        rating: 5,
        review_date: "2026-08-01",
        source: "app_store",
        product_name: "Mobile App",
        product_version: "4.2",
        region: "NA",
        country: "US",
        customer_segment: "enterprise",
        semantic_score: 0.82,
        keyword_score: 1,
        hybrid_score: 0.88
      }
    ]
  }),
  askDatasetAnswer: vi.fn().mockResolvedValue({
    answer_id: "answer-1",
    dataset_id: "dataset-1",
    question: "Why is login painful?",
    answer_style: "issues",
    route: "retrieval",
    answer:
      "The main product issue in the evidence is Login / Authentication, supported by [1].",
    confidence: "medium",
    confidence_score: 68,
    index_status: "ready",
    evidence_count: 1,
    filtered_review_count: 1,
    themes: [{ label: "Login / Authentication", count: 1, score: 0.88 }],
    analytics: [],
    comparison: null,
    citations: [
      {
        citation_id: 1,
        review_id: "review-1",
        row_number: 2,
        quote: "Login is much faster",
        rating: 5,
        review_date: "2026-08-01",
        source: "app_store",
        product_name: "Mobile App",
        product_version: "4.2",
        region: "NA",
        country: "US",
        customer_segment: "enterprise",
        semantic_score: 0.82,
        keyword_score: 1,
        hybrid_score: 0.88
      }
    ],
    limitations: ["Answer synthesis is using reviewlens-local-template-v1."],
    generation_model: "reviewlens-local-template-v1"
  }),
  fetchAnswerHistory: vi.fn().mockResolvedValue([
    {
      answer_id: "answer-1",
      dataset_id: "dataset-1",
      question: "Why is login painful?",
      answer_style: "issues",
      confidence: "medium",
      confidence_score: 68,
      index_status: "ready",
      evidence_count: 1,
      feedback_rating: null,
      created_at: "2026-08-03T12:00:00Z"
    }
  ]),
  fetchAnswerDetail: vi.fn().mockResolvedValue({
    answer_id: "answer-1",
    dataset_id: "dataset-1",
    question: "Why is login painful?",
    answer_style: "issues",
    route: "retrieval",
    answer:
      "The main product issue in the evidence is Login / Authentication, supported by [1].",
    confidence: "medium",
    confidence_score: 68,
    index_status: "ready",
    evidence_count: 1,
    filtered_review_count: 1,
    themes: [{ label: "Login / Authentication", count: 1, score: 0.88 }],
    analytics: [],
    comparison: null,
    citations: [
      {
        citation_id: 1,
        review_id: "review-1",
        row_number: 2,
        quote: "Login is much faster",
        rating: 5,
        review_date: "2026-08-01",
        source: "app_store",
        product_name: "Mobile App",
        product_version: "4.2",
        region: "NA",
        country: "US",
        customer_segment: "enterprise",
        semantic_score: 0.82,
        keyword_score: 1,
        hybrid_score: 0.88
      }
    ],
    limitations: ["Answer synthesis is using reviewlens-local-template-v1."],
    generation_model: "reviewlens-local-template-v1",
    mode: "hybrid",
    top_k: 5,
    filters: { rating_max: 2 },
    latency_ms: 12.4,
    feedback_rating: "useful",
    feedback_notes: "Helpful",
    created_at: "2026-08-03T12:00:00Z"
  }),
  submitAnswerFeedback: vi.fn().mockResolvedValue({
    feedback_id: "feedback-1",
    answer_id: "answer-1",
    dataset_id: "dataset-1",
    rating: "useful",
    notes: "Helpful"
  }),
  fetchObservabilityMetrics: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    answer_count: 1,
    average_confidence_score: 68,
    average_latency_ms: 12.4,
    average_evidence_count: 1,
    no_evidence_rate: 0,
    partial_index_rate: 0,
    confidence_distribution: [{ label: "medium", count: 1 }],
    feedback_distribution: [{ label: "useful", count: 1 }],
    top_themes: [{ label: "Login / Authentication", count: 1 }],
    top_limitations: [{ label: "Answer synthesis is using reviewlens-local-template-v1.", count: 1 }]
  }),
  fetchReleaseReadiness: vi.fn().mockResolvedValue({
    app_name: "ReviewLens API",
    app_version: "0.1.0",
    environment: "test",
    model_configuration: {
      embedding_provider: "local",
      embedding_model: "reviewlens-local-hash-v1",
      embedding_dimensions: 64,
      answer_provider: "local",
      answer_model: "reviewlens-local-template-v1",
      retrieval_auto_index: true,
      openai_configured: false
    },
    cost_configuration: {
      tracking_basis: "Configured model rates plus stored answer latency/model records.",
      embedding_cost_per_1k_tokens_usd: 0,
      answer_input_cost_per_1k_tokens_usd: 0,
      answer_output_cost_per_1k_tokens_usd: 0,
      notes: ["Local providers have zero external API cost."]
    },
    privacy: [
      "Dataset deletion removes reviews, embeddings, themes, answers, feedback, and import errors."
    ],
    security: ["Review text is treated as untrusted data in RAG prompts."],
    limits: ["Maximum upload size is 10 MB."],
    limitations: [
      "Local embeddings are deterministic and intended for demos/tests, not production recall."
    ],
    release_checklist: ["Load sample_data/reviewlens_demo_reviews.csv."]
  }),
  runEvaluation: vi.fn().mockResolvedValue({
    run_id: "eval-1",
    version: "v1.3",
    dataset_id: "eval-dataset",
    generated_at: "2026-08-04T12:00:00Z",
    total_questions: 100,
    passed_questions: 94,
    overall_score: 0.94,
    average_latency_ms: 12.3,
    p95_latency_ms: 21.8,
    metrics: [
      {
        name: "Retrieval relevance",
        score: 0.91,
        passed: 91,
        total: 100,
        details: "Correct evidence retrieved."
      },
      {
        name: "Citation support",
        score: 0.95,
        passed: 95,
        total: 100,
        details: "Citations support claims."
      }
    ],
    category_breakdown: [],
    cases: []
  }),
  deleteDataset: vi.fn().mockResolvedValue(undefined),
  generateInsightBrief: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    title: "Weekly ReviewLens Brief",
    generated_at: "2026-08-04T12:00:00Z",
    filters: { rating_max: 2 },
    metrics: {
      total_reviews: 2,
      filtered_reviews: 1,
      average_rating: 2,
      rated_reviews: 1
    },
    rating_distribution: [{ rating: "2", count: 1 }],
    volume_trend: [{ date: "2026-08-02", count: 1 }],
    retrieval_status: {
      dataset_id: "dataset-1",
      embedding_model: "reviewlens-local-hash-v1",
      dimensions: 64,
      total_reviews: 2,
      indexed_reviews: 2,
      pending_reviews: 0,
      status: "indexed"
    },
    quality_metrics: {
      dataset_id: "dataset-1",
      answer_count: 1,
      average_confidence_score: 68,
      average_latency_ms: 12.4,
      average_evidence_count: 1,
      no_evidence_rate: 0,
      partial_index_rate: 0,
      confidence_distribution: [{ label: "medium", count: 1 }],
      feedback_distribution: [{ label: "useful", count: 1 }],
      top_themes: [{ label: "Login / Authentication", count: 1 }],
      top_limitations: []
    },
    top_themes: [
      {
        label: "Login / Authentication",
        count: 1,
        share: 1,
        average_rating: 2,
        negative_count: 1,
        positive_count: 0,
        risk_score: 100,
        keywords: ["login"],
        samples: []
      }
    ],
    segment_comparison: null,
    recent_answers: [],
    sections: [
      {
        title: "Snapshot",
        summary: "App reviews has 1 matching review out of 2 total.",
        bullets: ["1 matching review includes a rating."]
      },
      {
        title: "Top Themes",
        summary: "Login / Authentication is the leading theme.",
        bullets: ["Login / Authentication: 1 review."]
      }
    ],
    markdown: "# Weekly ReviewLens Brief\n\n## Snapshot\nApp reviews has 1 matching review out of 2 total.\n",
    limitations: ["Insight briefs are deterministic exports from the current ReviewLens data."]
  }),
  generateActionPlan: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    generated_at: "2026-08-04T12:00:00Z",
    audience: "support",
    filters: { rating_max: 2 },
    filtered_review_count: 1,
    average_rating: 2,
    negative_review_count: 1,
    top_themes: [
      {
        label: "Login / Authentication",
        count: 1,
        share: 1,
        average_rating: 2,
        negative_count: 1,
        positive_count: 0,
        risk_score: 100,
        keywords: ["login"],
        samples: []
      }
    ],
    actions: [
      {
        action_id: "A01",
        title: "Prepare response playbook for login / authentication",
        priority: "high",
        owner: "support",
        effort: "medium",
        theme: "Login / Authentication",
        rationale: "Login / Authentication appears in 1 filtered review with risk score 100.",
        expected_impact: "Faster customer response and fewer repeated escalations.",
        next_steps: ["Draft macros for the top login complaints."],
        evidence: [],
        metrics: [{ label: "Filtered share", value: "100%" }]
      }
    ],
    segment_drivers: [],
    limitations: ["Action plans are deterministic recommendations from filtered ReviewLens data."],
    markdown: "# App reviews Action Plan\n\n## Recommended Actions\n"
  }),
  uploadDataset: vi.fn().mockResolvedValue({
    dataset_id: "dataset-1",
    ingestion_job_id: "job-1",
    name: "App reviews",
    filename: "reviews.csv",
    status: "completed_with_errors",
    total_rows: 3,
    accepted_rows: 2,
    rejected_rows: 1,
    duplicate_rows: 0,
    field_mapping: {
      review_text: "review_text"
    },
    errors_preview: [
      {
        row_number: 4,
        error_code: "missing_review_text",
        message: "Missing required review_text.",
        payload: {}
      }
    ]
  })
}));

async function openSection(name: string) {
  fireEvent.click(await screen.findByRole("tab", { name }));
}

beforeEach(() => {
  vi.clearAllMocks();
});

test("renders the ReviewLens workspace shell", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  expect(screen.getByText("ReviewLens")).toBeInTheDocument();
  expect(screen.getByText("Customer Review Intelligence")).toBeInTheDocument();
  expect(await screen.findByText("Connected")).toBeInTheDocument();
  expect(await screen.findByText("Models, Privacy, Cost")).toBeInTheDocument();
  expect(fetchReleaseReadiness).toHaveBeenCalled();
});

test("uploads a review dataset and renders validation summary", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  fireEvent.change(screen.getByLabelText("Dataset name"), {
    target: { value: "App reviews" }
  });
  fireEvent.change(screen.getByLabelText("CSV or JSON file"), {
    target: {
      files: [new File(["review_text,rating\nGreat,5"], "reviews.csv", { type: "text/csv" })]
    }
  });
  fireEvent.submit(screen.getByRole("button", { name: "Upload" }).closest("form")!);

  await waitFor(() => expect(uploadDataset).toHaveBeenCalled());
  expect(await screen.findByText("Accepted")).toBeInTheDocument();
  expect(screen.getByText("Missing required review_text.")).toBeInTheDocument();
  expect(screen.getAllByText("App reviews").length).toBeGreaterThan(0);
});

test("deletes the active dataset from overview", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await screen.findByText("Recent Uploads");
  fireEvent.click(screen.getByRole("button", { name: "Delete dataset" }));

  await waitFor(() => expect(deleteDataset).toHaveBeenCalledWith("dataset-1"));
  expect(await screen.findByText(/deleted with its reviews and AI artifacts/i)).toBeInTheDocument();
});

test("applies review explorer filters and opens source detail", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Explore Reviews");
  expect(await screen.findByText("Avg rating")).toBeInTheDocument();
  fireEvent.change(screen.getByPlaceholderText("login, export, crash"), {
    target: { value: "checkout" }
  });

  await waitFor(() =>
    expect(fetchDatasetExplore).toHaveBeenLastCalledWith("dataset-1", { query: "checkout" })
  );

  fireEvent.click(await screen.findByText("Checkout crashes sometimes"));
  expect(screen.getByLabelText("Source review detail")).toHaveTextContent(
    "Checkout crashes sometimes"
  );
});

test("indexes and searches retrieval evidence", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Ask ReviewLens");
  expect(await screen.findByText("Index status")).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "Index" }));
  await waitFor(() => expect(indexDatasetRetrieval).toHaveBeenCalledWith("dataset-1"));

  fireEvent.change(screen.getByPlaceholderText("login failures after release"), {
    target: { value: "login" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Search" }));

  await waitFor(() =>
    expect(searchDatasetRetrieval).toHaveBeenCalledWith({
      datasetId: "dataset-1",
      query: "login",
      mode: "hybrid",
      filters: {},
      topK: 8
    })
  );
  expect(await screen.findByText("0.88")).toBeInTheDocument();
});

test("asks for a grounded answer with current filters", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Explore Reviews");
  fireEvent.change(await screen.findByLabelText("Rating max"), {
    target: { value: "2" }
  });
  await openSection("Ask ReviewLens");
  expect(await screen.findByRole("heading", { name: "Ask ReviewLens" })).toBeInTheDocument();
  fireEvent.change(screen.getByLabelText("Question"), {
    target: { value: "Why is login painful?" }
  });
  fireEvent.change(screen.getByLabelText("Answer style"), {
    target: { value: "issues" }
  });
  fireEvent.change(screen.getByLabelText("Evidence count"), {
    target: { value: "5" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Ask" }));

  await waitFor(() =>
    expect(askDatasetAnswer).toHaveBeenCalledWith({
      datasetId: "dataset-1",
      question: "Why is login painful?",
      mode: "hybrid",
      answerStyle: "issues",
      filters: { ratingMax: "2" },
      topK: 5
    })
  );
  expect(await screen.findByText(/main product issue/i)).toBeInTheDocument();
  expect(screen.getAllByText("Login / Authentication").length).toBeGreaterThan(0);
  expect(screen.getByText("[1]")).toBeInTheDocument();
  expect(screen.getByText("medium / 68")).toBeInTheDocument();
  fireEvent.click(screen.getByRole("button", { name: "Open source" }));
  expect(screen.getByRole("heading", { name: "Row 2" })).toBeInTheDocument();
});

test("renders routed comparison answers with quantified theme movement", async () => {
  vi.mocked(askDatasetAnswer).mockResolvedValueOnce({
    answer_id: "answer-2",
    dataset_id: "dataset-1",
    question: "Why did ratings decline after version 4.2?",
    answer_style: "summary",
    route: "retrieval_analytics",
    answer:
      "Ratings declined by 0.80 points after version 4.2. Login complaints rose from 5.0% to 20.0% [1].",
    confidence: "high",
    confidence_score: 91,
    index_status: "ready",
    evidence_count: 1,
    filtered_review_count: 4030,
    themes: [{ label: "Login / Authentication", count: 1, score: 0.91 }],
    analytics: [
      {
        label: "Rating comparison",
        value: "-0.80",
        numerator: 3.5,
        denominator: 4.3,
        percentage: null,
        details:
          "Before version 4.2: 1880 reviews, average rating 4.30. After version 4.2: 2150 reviews, average rating 3.50."
      }
    ],
    comparison: {
      comparison_type: "version",
      dimension: "product_version",
      before: {
        label: "Version 4.2 and earlier",
        review_count: 1880,
        average_rating: 4.3
      },
      after: {
        label: "After version 4.2",
        review_count: 2150,
        average_rating: 3.5
      },
      rating_delta: -0.8,
      theme_movements: [
        {
          label: "Login / Authentication",
          before_count: 94,
          before_share: 5,
          after_count: 430,
          after_share: 20,
          delta_share: 15,
          direction: "increased"
        }
      ],
      summary:
        "Version 4.2 and earlier: 1880 reviews, average rating 4.30. After version 4.2: 2150 reviews, average rating 3.50."
    },
    citations: [
      {
        citation_id: 1,
        review_id: "review-1",
        row_number: 2,
        quote: "Login is much faster",
        rating: 2,
        review_date: "2026-08-01",
        source: "app_store",
        product_name: "Mobile App",
        product_version: "4.3",
        region: "NA",
        country: "US",
        customer_segment: "enterprise",
        semantic_score: 0.91,
        keyword_score: 0.5,
        hybrid_score: 0.91
      }
    ],
    limitations: ["Question router selected retrieval + analytics."],
    generation_model: "reviewlens-local-template-v1"
  });

  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Ask ReviewLens");
  expect(await screen.findByRole("heading", { name: "Ask ReviewLens" })).toBeInTheDocument();
  fireEvent.change(screen.getByLabelText("Question"), {
    target: { value: "Why did ratings decline after version 4.2?" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Ask" }));

  expect(await screen.findByText("Retrieval + analytics")).toBeInTheDocument();
  expect(screen.getByText("Rating comparison: -0.80")).toBeInTheDocument();
  expect(screen.getByText("Version 4.2 and earlier")).toBeInTheDocument();
  expect(screen.getByText("After version 4.2")).toBeInTheDocument();
  expect(screen.getAllByText("Login / Authentication").length).toBeGreaterThan(0);
  expect(screen.getByText("+15.0 pts")).toBeInTheDocument();
  expect(screen.getByText("1 citations / 4030 filtered reviews")).toBeInTheDocument();
});

test("submits answer feedback and restores answer history", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Ask ReviewLens");

  fireEvent.change(screen.getByLabelText("Question"), {
    target: { value: "Why is login painful?" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Ask" }));
  expect(await screen.findByText(/main product issue/i)).toBeInTheDocument();

  await openSection("Evaluation");
  expect(await screen.findByText("Grounding Snapshot")).toBeInTheDocument();
  expect(screen.getByText("Answers")).toBeInTheDocument();

  fireEvent.change(screen.getByLabelText("Feedback notes"), {
    target: { value: "Helpful" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Useful" }));

  await waitFor(() =>
    expect(submitAnswerFeedback).toHaveBeenCalledWith({
      datasetId: "dataset-1",
      answerId: "answer-1",
      rating: "useful",
      notes: "Helpful"
    })
  );
  expect(await screen.findByText("Feedback saved")).toBeInTheDocument();

  fireEvent.click(screen.getByRole("button", { name: /Why is login painful/i }));
  await waitFor(() =>
    expect(fetchAnswerDetail).toHaveBeenCalledWith({
      datasetId: "dataset-1",
      answerId: "answer-1"
    })
  );
  expect(fetchAnswerHistory).toHaveBeenCalledWith("dataset-1");
  expect(fetchObservabilityMetrics).toHaveBeenCalledWith("dataset-1");
});

test("runs the golden evaluation scorecard", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Evaluation");
  fireEvent.click(await screen.findByRole("button", { name: "Run Evaluation" }));

  await waitFor(() => expect(runEvaluation).toHaveBeenCalled());
  expect(await screen.findByText("v1.3")).toBeInTheDocument();
  expect(screen.getByText("94%")).toBeInTheDocument();
  expect(screen.getByText("Retrieval relevance")).toBeInTheDocument();
  expect(screen.getByText("Citation support")).toBeInTheDocument();
});

test("renders theme analytics and propagates explorer filters", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Explore Reviews");
  expect(await screen.findByText("Recurring Drivers")).toBeInTheDocument();
  expect(screen.getAllByText("Login / Authentication").length).toBeGreaterThan(0);
  expect(screen.getByText("Period Comparison")).toBeInTheDocument();
  expect(screen.getByText(/2026-07-30 to 2026-07-31/)).toBeInTheDocument();

  fireEvent.change(screen.getByLabelText("Date from"), {
    target: { value: "2026-08-01" }
  });
  fireEvent.change(screen.getByLabelText("Date to"), {
    target: { value: "2026-08-02" }
  });

  await waitFor(() =>
    expect(fetchDatasetThemes).toHaveBeenLastCalledWith("dataset-1", {
      dateFrom: "2026-08-01",
      dateTo: "2026-08-02"
    })
  );

  fireEvent.click(screen.getByRole("button", { name: /Reliability/i }));
  expect(screen.getAllByText("Checkout crashes sometimes").length).toBeGreaterThan(0);
});

test("compares theme drivers across two selected segments", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Explore Reviews");
  expect(await screen.findByText("Segment Comparison")).toBeInTheDocument();
  fireEvent.change(screen.getByLabelText("Rating max"), {
    target: { value: "2" }
  });
  fireEvent.change(await screen.findByLabelText("Compare by"), {
    target: { value: "region" }
  });
  fireEvent.change(screen.getByLabelText("Left segment"), {
    target: { value: "EU" }
  });
  fireEvent.change(screen.getByLabelText("Right segment"), {
    target: { value: "NA" }
  });
  fireEvent.change(screen.getByLabelText("Theme limit"), {
    target: { value: "3" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Compare" }));

  await waitFor(() =>
    expect(fetchThemeComparison).toHaveBeenCalledWith({
      datasetId: "dataset-1",
      compareBy: "region",
      leftValue: "EU",
      rightValue: "NA",
      filters: { ratingMax: "2" },
      limit: 3,
      minCount: 1
    })
  );
  expect(await screen.findByText("Login / Authentication appears more often in EU than NA.")).toBeInTheDocument();
  expect(screen.getByText("left higher")).toBeInTheDocument();
  expect(screen.getByText("Segment comparison is based on a small sample.")).toBeInTheDocument();
});

test("generates an insight brief from current filters", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Explore Reviews");
  fireEvent.change(await screen.findByLabelText("Rating max"), {
    target: { value: "2" }
  });
  await openSection("Evaluation");
  fireEvent.click(await screen.findByText("Portfolio exports and action planning"));
  await screen.findByText("Insight Brief");
  fireEvent.change(screen.getByLabelText("Brief title"), {
    target: { value: "Weekly ReviewLens Brief" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Generate brief" }));

  await waitFor(() =>
    expect(generateInsightBrief).toHaveBeenCalledWith({
      datasetId: "dataset-1",
      title: "Weekly ReviewLens Brief",
      filters: { ratingMax: "2" },
      themeLimit: 5,
      recentAnswersLimit: 3,
      segmentComparison: undefined
    })
  );
  expect(await screen.findByText("Generated Brief")).toBeInTheDocument();
  expect(screen.getByText("App reviews has 1 matching review out of 2 total.")).toBeInTheDocument();
  expect(screen.getByText("Download .md")).toBeInTheDocument();
  expect(screen.getByText("Insight briefs are deterministic exports from the current ReviewLens data.")).toBeInTheDocument();
});

test("generates an action plan from current filters", async () => {
  render(
    <MemoryRouter>
      <App />
    </MemoryRouter>
  );

  await openSection("Explore Reviews");
  fireEvent.change(await screen.findByLabelText("Rating max"), {
    target: { value: "2" }
  });
  await openSection("Evaluation");
  fireEvent.click(await screen.findByText("Portfolio exports and action planning"));
  await screen.findByText("Action Plan");
  fireEvent.change(screen.getByLabelText("Audience"), {
    target: { value: "support" }
  });
  fireEvent.change(screen.getByLabelText("Max actions"), {
    target: { value: "4" }
  });
  fireEvent.click(screen.getByRole("button", { name: "Generate actions" }));

  await waitFor(() =>
    expect(generateActionPlan).toHaveBeenCalledWith({
      datasetId: "dataset-1",
      audience: "support",
      filters: { ratingMax: "2" },
      themeLimit: 6,
      maxActions: 4,
      segmentComparison: undefined
    })
  );
  expect(await screen.findByText("1 Recommended Actions")).toBeInTheDocument();
  expect(screen.getByText("Prepare response playbook for login / authentication")).toBeInTheDocument();
  expect(screen.getByText("high")).toBeInTheDocument();
  expect(screen.getByText("support / medium")).toBeInTheDocument();
  expect(screen.getByText("Draft macros for the top login complaints.")).toBeInTheDocument();
  expect(
    screen.getByText("Action plans are deterministic recommendations from filtered ReviewLens data.")
  ).toBeInTheDocument();
});
