# Evaluation Report

The current golden evaluation is available at:

```text
POST /api/evaluations/run
```

It builds a deterministic synthetic dataset and runs 100 questions:

- 20 factual questions
- 20 theme questions
- 20 quantitative questions
- 15 filter questions
- 15 comparison questions
- 10 impossible/unanswerable questions

The report returns retrieval relevance, citation support, abstention accuracy, calculation accuracy, filter correctness, robustness, average latency, P95 latency, per-category pass rates, and failed case details.

Portfolio pass target: at least 90% overall, 100% deterministic calculation accuracy, 100% filter correctness, and no confident answers for impossible questions.

The benchmark is intentionally reproducible. It is not a replacement for production monitoring against real customer datasets.
