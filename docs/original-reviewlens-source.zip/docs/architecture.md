# ReviewLens Architecture

```mermaid
flowchart TD
  Browser["React frontend"] --> API["FastAPI backend"]
  API --> Upload["Dataset ingestion"]
  API --> Explore["Explore metrics"]
  API --> Ask["Ask ReviewLens"]
  API --> Eval["Evaluation runner"]
  Upload --> DB["Postgres + pgvector"]
  Explore --> DB
  Ask --> Router["Question router"]
  Router --> Retrieval["Semantic / hybrid retrieval"]
  Router --> Analytics["Deterministic analytics"]
  Router --> Comparison["Before / after comparison"]
  Retrieval --> DB
  Retrieval --> Embeddings["Embedding provider"]
  Ask --> AnswerProvider["Answer provider"]
  Ask --> History["Answer observability"]
  History --> DB
  Eval --> Golden["Synthetic golden dataset"]
  Golden --> Ask
```

## Core Services

- `backend/app/services/ingestion.py`: parses CSV/JSON, validates rows, normalizes text, deduplicates reviews, and bounds upload risk.
- `backend/app/services/retrieval.py`: embeds review text, stores vectors, and returns keyword, semantic, or hybrid evidence.
- `backend/app/services/answers.py`: classifies questions into retrieval, analytics, or both; gates insufficient evidence; builds citations; calls the answer provider.
- `backend/app/services/theme_discovery.py`: discovers dataset-specific themes and stores deterministic assignments.
- `backend/app/services/evaluations.py`: runs the reproducible golden benchmark.
- `backend/app/services/observability.py`: records answer history, feedback, confidence, evidence counts, models, and latency.

## Trust Boundaries

Review text is customer-authored data. The answer prompt explicitly marks retrieved reviews as untrusted evidence and JSON-quotes review text before it reaches the LLM. API keys stay in backend environment variables and are not returned to the browser.
