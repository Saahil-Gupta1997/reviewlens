# Limitations

## Demo-Grade Defaults

The default local embedding and answer providers are deterministic and useful for demos/tests. They are not a substitute for production semantic recall or production LLM synthesis.

## Security

The app has prompt-injection hardening for retrieved reviews and bounded uploads, but it does not yet include authentication, authorization, tenant isolation, audit-log export, or automated PII redaction.

## Privacy

Data is stored in the configured backend database. With OpenAI providers enabled, selected review text and questions are sent to the configured OpenAI-compatible endpoint for embeddings or answer generation.

## Cost

Cost-rate settings are configurable, and answer history stores model and latency records. Token-level billing reconciliation is not implemented.

## Evaluation

The golden evaluation is synthetic. It is strong regression coverage for product behavior, but real production readiness would need domain-specific evals, live monitoring, and human review of failed cases.
